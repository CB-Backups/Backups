# BackupBrew

let us backup some things!

**NOTE: This project is just a idea atm - the first version will come asap.**

## features *(planned)*

- fast and low perfomance needed
- multiple source-hosts
- multiple schedules
- exclude files / exclude patterns
- only *nix/Mac OS X support
- everything with config files!

## backup plans

*(?)*

## tools

|Sevice|Tool|Notice
|---|---|---
|Files|`rsync`, `lftp`, `ftp`, `scp` (?)| *has to be available on the source-server*
|MySQL|`mysqldump`| *maybe pure PHP/PDO tool, also?*
|Compression|`zip`, `gzip`| *any suggestions what else?*

## integrations/notifications

- E-Mail (pure php *or* with Mandrill)
- Pushover
- Slack Chat
- Log files of cause! :bowtie:
- ?


## backup destinations

- local file system path
- sftp
- ftp
- dropbox

**maybe - if I'm in the mood for that**

- google drive
- amazon s3
- webdav
- owncloud ( even possible? )
