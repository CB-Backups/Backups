prefix = 'user-';
input  = document.querySelectorAll('input.foo')[0];

input.setAttribute('value', prefix);
input.addEventListener('keyup', function() {
    if     (this.value.substr(0, prefix.length) != prefix) {
        this.value = prefix + this.value.substr(prefix.length + 1, this.value.length);
    }
});
