<?php
$page = new Page();
$settings = new Settings();
?>
<script>
    Mousetrap.bind("n", function() { $("#message").focus() });
    Mousetrap.bind("c", function() { $("#close").trigger('click'); });
    Mousetrap.bind("o", function() { $("#open").trigger('click'); });
</script>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Galerie schließen</h1>
        <p>
            Du kannst die Galerie sperren, somit sind die Bilder nicht mehr sichtbar.<br>
            Optional kannst Du auch eine Nachricht angeben, die beim Aufrufen der gesperrten Galerie angegeben wird.<br>
            Nach dem Öffnen/Schließen wird die Änderung nicht sofort sichtbar, daher solltest Du die Seite neu laden!
        </p>
        <?php
        if (isset($_POST['close'])) {
            echo '<span class="message"><i class="icon-info"></i>' . $settings->closeGallery($_POST['message']) . "</span>";
            ;
        } if (isset($_POST['open'])) {
            echo '<span class="message"><i class="icon-info"></i>' . $settings->openGallery() . "</span>";
            ;
        }
        ?>
        <br>
        <br>
        <form action="admin.php?s=close" method="post">
            <?php if ($settings->getGalleryStatus() == "0"): ?>
                <input type="text" name="message" id="message" placeholder="Nachricht (optional)">
                <input type="submit" name="close" id="close" value="Galerie schließen">
            <?php elseif ($settings->getGalleryStatus() == "1"): ?>
                <input type="submit" name="open" id="open" value="Galerie öffnen">
            <?php endif; ?>
        </form>
    </div>
</div>
