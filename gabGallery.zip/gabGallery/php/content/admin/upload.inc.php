<?php
$page = new Page();
$upload = new Upload();

if (isset($_POST['go'])) {
    echo $upload->uploadPictures($_FILES);
}
?>
<script>
    Mousetrap.bind("f", function() { $("#file").trigger('click'); });
    Mousetrap.bind("u", function() { $("#upload").trigger('click'); });
</script>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Bilder hochladen</h1>
        <p>
            <ul>                
                <li>Es können JPG/JPEG und PNG Dateien hochgeladen werden. PNG's mit einer Transparenz verursachen Fehler.</li>
                <li><b>Tipp:</b> Mit gehaltener [SHIFT]-Taste kannst du mehrere Bilder auswählen und aufeinmal hochladen. (max. 15)</li>
            </ul>
            Max. Dateigröße: <b><?=$upload->getMaxFileSize()?>MB</b>
        </p>
        <form action="admin.php?s=upload" method="post" enctype="multipart/form-data">
            <div class="fake">Dateien auswählen</div>
            <input id="file" name="uploads[]" type="file" accept="image/*" multiple>
            <br><br>
            <input type="submit" name="go" id="upload" value="Hochladen">
        </form>
    </div>
</div>