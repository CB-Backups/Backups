<?php $page = new Page(); ?>        
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Über gabGallery</h1>  
        <p>
            Dieses System ist im Rahmen eines Unterrichtsprojekts entstanden. Ziel war es eine Fotogalerie in PHP objektorientiert zu programmieren.
            gabGallery ist OpenSource. Das System ist steht unter MIT-License, der Lizenztext ist unten angehängt.<br>Im Footer ist ein Link der zur GitHub-Repository führt.
        </p>              
        <h2>Updates</h2>
        <p>
            gabGallery wird ständig erweitert und verbessert. Da es kein richtiges Update-System gibt, kann man gabGallery in der Regel über GIT updaten.
            Alternativ kann man die neuste Version auch hier herunterladen und einfach installieren. Aktuellste Version 
            <a href="https://github.com/GabrielWanzek/gabGallery/zipball/master">hier</a> herunterladen.
        </p>
        
        <h2>Credits</h2>
        <p>
            Dieses System verwendet klasse OpenSource-Skripte, welche durch ihre Lizenzen namentlich erwähnt gehören.<br>
            Alle Autoren von verwendeten Schriftarten, Icons und jQuery-Plugins findet man hier: <a href="https://github.com/GabrielWanzek/gabGallery/blob/master/CREDITS.md">CREDITS.md</a>
        </p>
        <h2>Fehler melden</h2>
        <p>
            Einen Fehler gefunden? Verbesserungsvorschläge? Melde eine Issue: <a href="https://github.com/GabrielWanzek/gabGallery/issues">gabGallery Issues</a>
        </p>
        <h2 id="license">Lizenz</h2>
        <div class="licensetext">
            <b>MIT License</b><br>
            <br>
            Copyright &copy; 2013 Gabriel Wanzek (<a href="http://git.io/XGsV6Q">http://git.io/XGsV6Q</a>)
            <br><br>
            Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
            <br><br>
            The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
            <br><br>
            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
        </div>
    </div>
</div>