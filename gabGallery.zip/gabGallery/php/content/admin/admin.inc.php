<?php
$main = new Main();
$media = new Media();
$page = new Page();

/* DEBUG FUNKTIONEN ANFANG */
$thumbs = glob('upload/thumbs/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);
$pictures = glob('upload/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);

if (isset($_POST['delthumbs'])) {
    foreach ($thumbs as $file) {
        unlink($file);
    }
}
/* DEBUG FUNKTIONEN ENDE */
?>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <?php echo (isset($_GET['login'])) ? '<p class="message"><i class="icon-info"></i>Hallo, '.ucfirst($_SESSION['username']).'! Du wurdest erfolgreich eingeloggt.</p>' : '' ;?>
        <h1>Admin-Übersicht</h1>
        <?php echo $main->checkVersion(); ?>
        <p>
            Willkommen im Backend von gabGallery.<br>Hier kannst Du deine Bilder verwalten und neue Bilder hochladen.<br> 
            Zusätzlich kannst Du die Galerie schließen oder die Stilfarben der Galerie verändern, sowie Galeriedaten ändern.
        </p>
        <div class="adminfo">
            <span>Bilder in der Galerie:</span><b><?= $media->getUploadedPicturesNum() ?></b> Bilder<br>
            <span>Die Bilder belegen zurzeit:</span><b><?= $media->getSizeofUploadDir() ?> MB</b><br>
            <span>Deine gabGallery-Version:</span><b><?= $main->getVersion() ?></b><br>
            <span>PHP-Version:</span><b><?= PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION.".".PHP_RELEASE_VERSION ?></b><br>
            <span>GD-Lib-Version:</span><b><?= GD_MAJOR_VERSION.".".GD_MINOR_VERSION.".".GD_RELEASE_VERSION ?></b><br>
        </div>
        <div class="clearfix"></div>
        <h2>Debug-Funktionen</h2>
        <form action="admin.php?s=admin" method="post">
            <input type="submit" name="delthumbs" value="Alle Thumbnails löschen">
        </form>
    </div>
</div>

