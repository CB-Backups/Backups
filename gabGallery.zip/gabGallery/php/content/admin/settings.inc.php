<?php
$page = new Page();
$sett = new Settings();
$l = $sett->checkLicenseRadios();
$meta = $sett->getGalleryMeta();
?>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Galerie-Einstellungen</h1>
        <?php
        if (isset($_POST['go']))
            echo '<br><span class="message"><i class="icon-info"></i>' . $sett->setGalleryData($_POST['title'], $_POST['slogan'], $_POST['author'], $_POST['desc'], $_POST['keywords'], $_POST['license']) . "</span><br><br>";
        ?>
        <div class="clearfix"><br></div>
        <form action="admin.php?s=settings" method="post">
            <div class="half-box">
                <h2>Galerie</h2>
                <input type="text" name="title" id="title" placeholder="Galerietitel" value="<?= $sett->getGalleryTitle() ?>">
                <input type="text" name="slogan" id="slogan" placeholder="Galerieslogan" value="<?= $sett->getGallerySlogan() ?>">
                <br>
                <h2>Meta-Tags</h2>
                <input type="text" name="author" id="author" placeholder="Autor" value="<?= $meta['author'] ?>">
                <input type="text" name="desc" id="desc" placeholder="Beschreibung" value="<?= $meta['desc'] ?>">
                <input type="text" name="keywords" id="keywords" placeholder="Schlüsselwörter" value="<?= $meta['keywords'] ?>">
                <p><b>Achtung:</b> Sonderzeichen werden entfernt.<br>Umlaute und 'ß' können genutzt werden.</p>
            </div>
            <div class="half-box lastbox">
                <h2>Lizenz der Bilder</h2>
                <p>Unter welcher Lizenz willst du deine Bilder online bereitstellen?</p>
                <label><input type="radio" name="license" value="0" <?= $l[0] ?>>keine (Alle Rechte vorbehalten)<br></label>
                <label><input type="radio" name="license" value="1" <?= $l[1] ?>>Creative Commons BY 3.0 <a title="Namensnennung 3.0" href="http://creativecommons.org/licenses/by/3.0/de/" target="_blank"> <i class="icon-help"></i></a> <br></label>
                <label><input type="radio" name="license" value="2" <?= $l[2] ?>>Creative Commons BY-ND 3.0 <a title="Namensnennung-Keine Bearbeitung 3.0" href="http://creativecommons.org/licenses/by-nd/3.0/de/" target="_blank"> <i class="icon-help"></i></a><br></label>
                <label><input type="radio" name="license" value="3" <?= $l[3] ?>>Creative Commons BY-NC 3.0 <a title="Namensnennung-Nicht-kommerziell 3.0" href="http://creativecommons.org/licenses/by-nc/3.0/de/" target="_blank"> <i class="icon-help"></i></a><br></label>
                <label><input type="radio" name="license" value="4" <?= $l[4] ?>>Creative Commons BY-NC-ND 3.0 <a title="Namensnennung-NichtKommerziell-KeineBearbeitung" href="http://creativecommons.org/licenses/by-nc-nd/3.0/de/" target="_blank"> <i class="icon-help"></i></a><br></label>
                <label><input type="radio" name="license" value="5" <?= $l[5] ?>>Creative Commons BY-NC-SA 3.0 <a title="Namensnennung - Nicht-kommerziell - Weitergabe unter gleichen Bedingungen 3.0" href="http://creativecommons.org/licenses/by-nc-sa/3.0/de/" target="_blank"> <i class="icon-help"></i></a><br></label>
                <label><input type="radio" name="license" value="6" <?= $l[6] ?>>Creative Commons BY-SA 3.0 <a title="Namensnennung - Weitergabe unter gleichen Bedingungen 3.0" href="http://creativecommons.org/licenses/by-sa/3.0/de/" target="_blank"> <i class="icon-help"></i></a><br></label>
            </div>
            <input type="submit" name="go" value="Einstellungen speichern" >
        </form>
    </div>
</div>
