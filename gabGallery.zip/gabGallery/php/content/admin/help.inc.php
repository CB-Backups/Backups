<?php $page = new Page(); ?>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Hilfe</h1>
        <h2>Upload von Bildern</h2>
        <ul>
            <li>Nutzen Sie das Upload-Modul um ihre Bilder hochzuladen. Beachten Sie hierbei, dass der Dateiname der Bildtitel ist.</li>
            <li>Alternativ laden Sie die Dateien per bspw. FTP/SFTP in den upload-Verzeichnis hoch.<br>Damit die gabGallery dies verarbeiten kann sind einige Dinge zu beachten:
                <ul>
                    <li>Es können  <code>.jpg </code> sowie <code>.png </code> Dateien verarbeitet werden.</li>
                    <li>PNG-Bilder mit einer Transparenz verursachen meistens Fehler.</li>
                    <li>Bilder müssen Dateirechte haben, damit Sie verarbeitet werden können. Am einfachsten gibt man den Bildern 'chmod 777'</li>
                    <li>Bitte beachten Sie dass Leerzeichen und Sonderzeichen im Dateinamen Fehler verursachen können. Nutzen Sie statt Leerzeichen "_".</li>
                </ul>   
            </li>
            <li>Wenn ein Dateiname bereits existiert, wird an diesen <code>"_&lt;zahl&gt;"</code> angehängt. Dabei wird diese Zahl erhöht sollte dieser Dateiname ebenfalls existieren.</li>
            <li>Die Bilder werden nun automatisch eingebunden. Sollte ein Bild kein Vorschaubild (thumb) besitzen, wird dieses erstellt.</li>
            <li>Der Dateiname ist der Titel des Bildes. Dabei werden die "_"-Striche durch Leerzeichen ersetzt.</li>
            <li>Die Bilder sind nach Dateiänderungsdatum sortiert, welches normalerweise das Uploaddatum ist. (Neueste Zuerst)</li>
            <li>Es wird versucht EXIF-Daten aus dem Bild zu lesen. Diese werden in der Lightbox beim Überfahren mit der Maus angezeigt.</li>
        </ul>
        <h2>Tastatur-Kürzel</h2>
        <p>
            gabGallery bietet seit v2.89 Tastatur-Kürzel. Im Backend kann man mittels den Zahlen '1-8' zwischen den einzelnen Seiten navigieren.<br>
            Um zum Hochladen-Modul zu gelanden kann man hier bspw. die <code class="keyboard">2</code> drücken.<br>
        </p>
        <h3>Weitere Tastenbelegungen</h3>
        <div class="half-box">
            <b>Startseite</b><br>
            <ul>
                <li><code class="keyboard">h</code> Hilfe anzeigen</li>
                <li><code class="keyboard">l</code> <i>oder</i> <code class="keyboard">a</code> Einloggen/zum Backend</li>
            </ul>
        </div>
        <div class="half-box lastbox">
        <b>Gesamtes Backend:</b><br>
            <ul>
                <li><code class="keyboard">g</code> Zur Startseite</li>
                <li><code class="keyboard">l</code> + <code class="keyboard">o</code> Ausloggen</li>
                <li><code class="keyboard">?</code> Kurzhilfe anzeigen</li>
            </ul>
        </div>
        <div class="clearfix"></div>
        <div class="half-box">
            <b>Bilder hochladen:</b><br>
            <ul>
                <li><code class="keyboard">f</code> &rarr; Dialog öffnen um Bilder auszuwählen</li>
                <li><code class="keyboard">u</code> &rarr; ausgewählte Bilder hochladen</li>
            </ul>
            <b>Bilder löschen:</b><br>
            <ul>
                <li><code class="keyboard">l</code> &rarr; ausgewählte Bilder löschen</li>
            </ul>
        </div>
        <div class="half-box lastbox">
            <b>Galerie schließen:</b><br>
            <ul>
                <li><code class="keyboard">n</code> &rarr; in das Nachricht-Feld springen</li>
                <li><code class="keyboard">c</code> &rarr; Galerie schließen</li>
                <li><code class="keyboard">o</code> &rarr; Galerie öffnen</li>
            </ul>
        </div>
        <div class="clearfix"></div>
        <i>Weitere Shortcuts folgen...</i>
    </div>
</div>