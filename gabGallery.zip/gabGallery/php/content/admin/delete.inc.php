<?php
$page = new Page();
$media = new Media();

if (isset($_POST['go'])) {
    unset($_POST['go']);
    $media->deleteFiles($_POST);
}
?>
<script>
    Mousetrap.bind("l", function() { $("#delete").trigger('click'); });
</script>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">        
        <h1>Bilder löschen</h1>
        <p>Fahren mit dem Mauszeiger über den Dateinamen um das Bild zu sehen.<br>Makiere die Bilder, die du löschen möchtest und klicke dann auf den entsprechenden Button.</p>
        <form action="admin.php?s=delete" method="post">
            <div class="delete">
            <?php
            if ($media->getUploadedPicturesNum() !== 0) {
                foreach ($media->showUploadedFiles() as $key => $value) {
                    $exp = explode("/", $value);
                    $thumb = str_replace("/", "/thumbs/", $value);
                    $file = end($exp);
                    echo '<p><input type="checkbox" name="' . $value . '">&nbsp;&nbsp;<a href="#" class="tooltip">' . str_replace("upload/", "",$value) . "<span><img src='" . $thumb . "' alt='Thumbnail konnte nicht geladen werden'></span></a></p>\n";
                }
            echo '</div><input type="submit" id="delete" name="go" value="Ausgewählte Bilder löschen">';
            } else {
                echo '</div><p class="err"><i class="icon-info"></i>Keine Bilder vorhanden.</p>';
            }
            ?>                
        </form>        
    </div>
</div>