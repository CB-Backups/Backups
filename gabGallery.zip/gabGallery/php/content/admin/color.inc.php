<?php
$page = new Page();
$settings = new Settings();
$themes = array('black' => '#000', 'white' => '#fefefe');
?>
<script type="text/javascript">
   $(document).ready(function() {
     $('#colorpicker').farbtastic('#color');
   });
 </script>
<div id="content">
    <div id="sidebar">
        <?php $page->loadBackendSidebar(); ?>
    </div>
    <div id="admin">
        <h1>Stilfarben ändern</h1>
        <?php
        if (isset($_POST['go'])) {
            echo '<span class="message"><i class="icon-info"></i>' . $settings->setGalleryColor($_POST['theme'], $_POST['color']) . "</span>";
        }
        ?>
        <p>
            gabGallery bietet die Funktion um die Farbkombination ihrer Galerie zu verändern.<br>
            Somit stehen dir mehr als 33 Millionen verschiedene Farbkombinationen zur Verfügung.<br>
            Nutze die dynamische Farbenauswahl um eine hexadezimale Farbdefinition auszuwählen.<br>
        </p>
        <p>
            <b>Wähle deine Farbenkombination:</b>
        </p>
        <form action="admin.php?s=color" method="post">
            <div class="quarter-box">
                <h2>Template-Farbe</h2>
                <table class="colorchooser">
                    <tr>
                        <?php
                        foreach ($themes as $color => $theme) {
                            echo "<td title='" . $color . "' style='background-color:" . $theme . ";'> </td>" . "\n";
                        }
                        ?>
                    </tr>
                    <tr>
                        <?php
                        foreach ($themes as $name => $theme) {
                            $tchkd = ($settings->getGalleryTheme() == $name) ? ' checked' : 'b';
                            echo '<td><input type="radio" name="theme" id="" required value="' . $name . '"' . $tchkd . '></td>' . "\n";
                        }
                        ?>
                    </tr>
                </table>
            </div>
            <div class="quarter-box">
                <h2>Akzent-Farbe</h2>
            <input type="text" id="color" name="color" value="#<?=$settings->getGalleryColor();?>" style="width: 70px;">
            </div>
            <div class="quarter-box">
                <div id="colorpicker"></div>
            </div>
            
            <div class="clearfix"></div>
            <input type="submit" name="go" value="Farbenkombination speichern">
        </form>
    </div>
</div>