<div id="content">
    <div id="admin">
        <h1>Login</h1>
        <p>Um gabGallery zu Verwalten, logge dich mit deinen Benutzerdaten ein.</p>
        <form action="login.php" method="post" autocomplete="off">
            <input type="text" name="user" placeholder="Benutzername">
            <input type="password" name="pass" placeholder="Passwort">
            <input type="submit" name="go" value="Login">
        </form>
    </div>
</div>
