<?php
$set = new Settings();
?>
<div id="content">
    <img src="css/img/locked.png" alt="" class="closed" title="Icon by http://vlademareous.deviantart.com (CC BY-NC-SA 3.0)">
    <p class="closedmessage">
        Die Galerie ist geschlossen.<br>
        <br>
        <?= $set->getGalleryMessage() ?>
    </p>
</div>