<?php
$main = new Main();
$set = new Settings();
$media = new Media();
?>
<script>
    Mousetrap.bind("h", function() { $("#hidden_link").fancybox().trigger('click'); $("#unomes").slideUp(400); });
    Mousetrap.bind("a", function() { window.location.href = 'admin.php'; });
    Mousetrap.bind("l", function() { window.location.href = 'login.php'; });
</script>
<div id="content">
    <?php
    echo (isset($_GET['logout'])) ? '<p class="message"><i class="icon-info"></i>Du wurdest erfolgreich ausgeloggt.</p>' : '' ;
    echo $set->checkInstallationStatus(); ?>
    <span class="sep">Photostream <small>(<?=$media->getUploadedPicturesString();?>)</small></span> 
    <?php echo $main->generateHomeContent(); ?>
    <div class="clearfix sepend"></div>
    <span class="unomes" id="unomes">Drücke <code class="keyboard">h</code> um die Hilfe anzuzeigen</span>
</div>
<span id="hidden_link" style="display:none">
	<h2><?=$set->getGalleryTitle()?>:Hilfe</h2>
	<p>
		Bilder werden nach Upload-Datum sortiert.<br>
		Wenn der Galeriebesitzer eine Lizenz für seine Bilder gewählt hat, sieht man diese unten links.<br>
		Wenn du mit dem Mauszeiger über das Bild fährst, siehst Sie folgenden Daten:
		<ul>
			<li>Bildtitel/Dateiname</li>
			<li>[Kamera Model] - [ISO-Wert] - [Blende] - [Belichtungszeit]</li>
			<li>Aufnahmedatum</li>
		</ul>
		Drücke <code class="keyboard">l</code> um dich einzuloggen<br>
		<hr>
		<p>Dieses Galerie nutzt <a href="http://git.io/Tz4Fyw" style="color:#222">gabGallery</a> (<?=$main->getVersion()?>)</p>
		<small>Diesen Dialog mit <code class="keyboard">ESC</code> schließen</small>
	</p>
</span>