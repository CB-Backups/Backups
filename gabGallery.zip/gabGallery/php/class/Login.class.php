<?php

/**
 * Einloggen, Ausloggen, Passwort hashen und MySQL-Serververbindung per PDO
 */
class Login {

    /**
     * Einbinden der Datenbank-Verbindungs-Daten + Verbindung mit der MySQL-Datenbank aufbauen
     * @return string (im Fehlerfall) Fehler zurückgeben (PDOException)
     */
    function __construct() {
        // MySQL-Config einbinden
        require 'php/config/gg.conf.php';
        try {
            //Verbindung zum MySQL-Server aufbauen
            $ds = new PDO('mysql:host=' . $host . ';dbname=' . $database . '', $user, $password);
            //Exceptions aktiv.
            $ds->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->ds = $ds;
        } catch (PDOException $e) {
            //bei Fehlern...den Fehler ausgeben
            return '<br><h3>Fehler:</h3><hr>' . $e->getMessage() . "<hr>";
        }
    }

    /**
     * Beim Einloggen Username und Passwort mit den Daten aus der Datenbank-Tabelle lesen und schauen ob es vorhanden ist
     * Bei einem Fund wird die $_SESSION['admin'] auf true gesetzt und man hat Zugang zum Backend
     * @param type $u Username
     * @param type $p Passwort (Klartext)
     * @return string Fehlermeldung (oder PDOException)
     */
    public function login($u, $p) {
        //Usernamen abspeichern
        $_SESSION['username'] = $u;
        //Passwort Hash erzeugen
        $hashed = $this->hashPassword($p);
        //Sonderzeichen maskieren (MySQL-Injection)
        $username = mysql_real_escape_string($u);
        try {
            $q = "SELECT * FROM gg_userdata WHERE username = '" . $username . "' AND password = '" . $hashed . "'";
            $dbc = $this->ds->prepare($q);
            $dbc->bindParam(1, $username);
            $dbc->bindParam(2, $hashed);
            $dbc->execute();
            if ($dbc->rowCount() > 0) {
                $_SESSION['admin'] = true;
                return true;
            } else {
                return "<p class='err'><i class='icon-cancel'></i>Der Benutzername wurde nicht gefunden oder das Passwort falsch. Bitte überprüfe deine Eingabe und versuchen es erneut.</p>";
            }
        } catch (PDOException $e) {
            //bei Fehlern...den Fehler ausgeben
            return '<br><h3>Fehler:</h3><hr>' . $e->getMessage() . "<hr>";
        }
    }

    /**
     * Klartext wird zu einem SHA1 Prüfsumme mit einem Salt einer CRC32-Prüfsumme
     * @param String $pw Klartext-Passwort
     * @return String $hash Hash der Passworts
     */
    public function hashPassword($pw) {
        $hash = sha1($pw) . hash('crc32', $pw);
        return $hash;
    }

    /**
     * Logout: Zerstört die Session, somit ist der Zugang zum Backend verwehrt
     * yeah, "logout"-Funktion in der Login-Klasse - Watch out! We got a badass over here.
     */
    public function logout() {
        session_unset();
        session_destroy();
    }

    /**
     * Datenbankverbindung schließen
     */
    function __destruct() {
        //verbindung schließen
        $this->ds = NULL;
    }

}

?>