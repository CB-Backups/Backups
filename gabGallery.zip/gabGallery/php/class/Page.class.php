<?php

/**
 * Die verschiedenen Seiten und Unterseiten laden
 */
class Page {

    public function loadHeader() {
        return require 'php/parts/header.inc.php';
    }

    public function loadFooter() {
        return require 'php/parts/footer.inc.php';
    }

    /**
     * Prüft ob Galerie gesperrt ist, oder nicht und lädt den entsprechenden Seitenteil
     * @return Home-Seite
     */
    public function loadHome() {
        $settings = new Settings();
        $status = $settings->getGalleryStatus();
        if ($status == "0") {
            return require 'php/content/home.inc.php';
        } elseif ($status == "1") {
            return require 'php/content/closed.inc.php';
        }
    }

    public function loadLogin() {
        return require 'php/content/login.inc.php';
    }

    public function loadBackend($s) {
        switch ($s) {
            case 'home':
                return require 'php/content/admin/admin.inc.php';
                break;
            case 'upload':
                return require 'php/content/admin/upload.inc.php';
                break;
            case 'delete':
                return require 'php/content/admin/delete.inc.php';
                break;
            case 'close':
                return require 'php/content/admin/close.inc.php';
                break;
            case 'color':
                return require 'php/content/admin/color.inc.php';
                break;
            case 'settings':
                return require 'php/content/admin/settings.inc.php';
                break;
            case 'help':
                return require 'php/content/admin/help.inc.php';
                break;
            case 'info':
                return require 'php/content/admin/info.inc.php';
                break;
            default:
                return require 'php/content/admin/admin.inc.php';
                break;
        }
    }

    public function loadBackendSidebar() {
        return require 'php/parts/admin-sidebar.inc.php';
    }

    public function loadBackendKeyboardShortcuts() {
        return require 'php/parts/admin-kbsc.inc.php';
    }

    public function loadFooterLinks() {
        $admin = '<a href="admin.php" class="link"><i class="icon-settings"></i> Admin</a>';
        $home = '<a href="index.php" class="link"><i class="icon-home"></i> Startseite</a>';
        $login = '<a href="login.php" class="link"><i class="icon-login"></i> Login</a>';
        $logout = '<a href="logout.php" class="link"><i class="icon-logout"></i> Logout</a>';
        $github = '<a href="http://git.io/Tz4Fyw" target="_blank" class="link"><i class="icon-github"></i> GitHub</a>';
        if (isset($_SESSION['admin'])) {
            $file = explode("/", $_SERVER['SCRIPT_NAME']);
            if (end($file) == "index.php") {
                return $github . $logout . $admin;
            } else {
                return $github . $logout . $home;
            }
        } else {
            return $github . $login;
        }
    }

}

?>