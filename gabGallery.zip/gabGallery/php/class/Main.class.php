<?php

class Main {

    /**
     * Gibt die gabGallery Version zurück
     * @return string Version
     */
    public function getVersion() {
        return file_get_contents('php/version.txt');
    }

    /**
     * Gibt die gabGallery aktuelle Version zurück die bei GitHub verfügbar ist
     * @return string Version
     */
    public function getNewestVersion() {
    //github über HTTP - Fehlanzeige!
       if (extension_loaded('openssl')) {
            $stream = @fopen('https://raw.github.com/GabrielWanzek/gabGallery/master/php/version.txt', 'r');
            ini_set('default_socket_timeout',1);
            if ($stream) {
                return stream_get_contents($stream);
                fclose($stream);
            } else {
                return false;
            }
        }       
    }

    public function checkVersion() {
        $newver = $this->getNewestVersion();
        if ($newver && ($this->getVersion() !== $newver)) {
            return "<p class='message'>Deine gabGallery Version ist nicht aktuell.<br>Wenn du Lust auf etwas Neues hast, lade die neue Version (". $newver .") <a href='http://git.io/MuPrqw'>hier</a> herunter.</p>";
        }
    }

    /**
     * - Liest Bilder aus dem /upload-Verzeichnis, sowie die passendes Thumbnails (wenn vorhanden)
     * - Soriert das Array nach Dateiänderungsdatum (neueste zuerst)
     * - Generiert einen Bildnamen aus dem Dateinamen
     * - Liest EXIF-Daten aus dem Bild
     * - Generiert den passenden HTML-Quelltext
     * @return string Alle Bilder mit Thumbnails als HTML Quelltext
     */
    public function generateHomeContent() {
        $content = "";
        $files = glob('upload/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);
        $thumb = glob('upload/thumbs/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);
        if (count($files) == 0) {
            return '<p class="bigmessage">Galerie ist leer!</p>';
        } else {
            foreach ($files as $key => $value) {
                $ft = filemtime($value);
                $exp = explode("/", $value);
                $fpname = end($exp);
                $data[] = array('upts' => $ft, 'filename' => $fpname, 'picture' => $value);
            }
            rsort($data);
            foreach ($data as $file) {
                $filename = $this->getClearPictureTitle($file['picture']);
                $exif = $this->readEXIFData($file['picture']);
                $content .= '<a class="fancybox" rel="g" href="' . $file['picture'] . '" title="<b>' . $filename . '</b><br>' . $exif['cam'] . ' - ' . $exif['iso'] . ' - ' . $exif['fnum'] . ' - ' . $exif['exposure'] . '<br>' . $exif['takendate'] . '"><img src="picture.php?file=' . urldecode($file['filename']) . '" alt="' . $filename . '" class="thumb"></a>' . "\n";
            }
            return $content;
        }
    }

    /**
     * Generiert aus einem Dateinamen einen Bildtitel
     * bspw: "Echt_dichter_Nebel.JPG" wird "Echt dichter Nebel"
     * @param string $input Dateiname
     * @return string Bildtitel
     */
    public function getClearPictureTitle($input) {
        $exp_filename = explode("/", $input);
        $find = array('_', '.jpg', '.jpeg', '.png');
        $rep = array(' ', '', '', '');
        $filename = str_ireplace($find, $rep, end($exp_filename));
        return $filename;
    }

    /**
     * Liest EXIF-Daten aus einem Bild
     * @param string $filepath Dateipfad zum Bild
     * @return string|boolean Bei Erfolg die gefundenden Daten, im Fehlerfall false
     */
    public function readEXIFData($filepath) {
        $fe = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
        if ($fe == 'jpg' || $fe == 'jpeg') {
            if ((isset($filepath)) && (file_exists($filepath))) {
                $exif_ifd0 = read_exif_data($filepath, 'IFD0', 0);
                $exif_exif = read_exif_data($filepath, 'EXIF', 0);
                $error = "";
                if (@array_key_exists('Model', $exif_ifd0))
                    $cam = $exif_ifd0['Model'];
                else
                    $cam = $error;
                if (@array_key_exists('ExposureTime', $exif_ifd0))
                    $exposure = $exif_ifd0['ExposureTime'] . 's';
                else
                    $exposure = $error;
                if (@array_key_exists('ApertureFNumber', $exif_ifd0['COMPUTED']))
                    $fnum = $exif_ifd0['COMPUTED']['ApertureFNumber'];
                else
                    $fnum = $error;
                if (@array_key_exists('DateTime', $exif_ifd0))
                    $takendate = $exif_ifd0['DateTime'];
                else
                    $takendate = "X:00:00 00:00:00";
                if (@array_key_exists('ISOSpeedRatings', $exif_exif))
                    $iso = "ISO: " . $exif_exif['ISOSpeedRatings'];
                else
                    $iso = $error;
                $return = array();
                $return['cam'] = $cam;
                $return['exposure'] = $exposure;
                $return['fnum'] = $fnum;
                $return['takendate'] = $this->ConvertEXIFDatetoEUDate($takendate);
                $return['iso'] = $iso;
                return $return;
            } else
                return false;
        }
    }

    /**
     * Überprüft Dateityp, um richtige Funktionen bereitzustellen (png oder jpg)
     * Überpüft ob zu dem Bild im /upload-Vz. ein Thumbnail im /upload/thumbs-Vz existiert
     * Falls nicht wird ein proportinales Vorschaubild (Thumbnail) erstellt und gespeichert
     * die Höhe ist hierbei auf 175px beschränkt. Der Wert kann für größere Bilder geändert werden
     */
    public function createThumbnail($file) {
        $filepath = 'upload/' . $file;
        $thumbpath = 'upload/thumbs/' . $file;
        $fileext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($fileext == 'jpg' || $fileext == 'jpeg' || $fileext == 'png') {
            if (!file_exists($thumbpath)) {
                if ($fileext == 'jpg' || $fileext == 'jpeg') {
                    $img = imagecreatefromjpeg($filepath);
                } elseif ($fileext == 'png') {
                    $img = imagecreatefrompng($filepath);
                }
                if (isset($img)) {
                    $newheight = 175;
                    $newwidth = $newheight * (imagesx($img) / imagesy($img));
                    $temp = imagecreatetruecolor($newwidth, $newheight);
                    imagecopyresampled($temp, $img, 0, 0, 0, 0, $newwidth, $newheight, imagesx($img), imagesy($img));
                    if ($fileext == 'jpg' || $fileext == 'jpeg') {
                        imagejpeg($temp, $thumbpath, 90);
                    } elseif ($fileext == 'png') {
                        imagepng($temp, $thumbpath);
                    }
                }
            }
        }
    }

    /**
     * EXIF-Date: YYYY:MM:DD HH:MM:SS ==>> UNIX-Timestamp ==>> EU-Date DD.MM.YYYY HH:MM:SS
     * @param string $exifdate Timestamp im EXIF-Format
     * @return string Timestamp Deutsches/EU-Format
     */
    public function ConvertEXIFDatetoEUDate($exifdate) {
        $clr = str_replace(" ", ":", $exifdate);
        $e = explode(":", $clr);
        if ($e[0] == "X")
            return "<i>Kein Aufnahmedatum verfügbar</i>";
        $timestamp = mktime($e[3], $e[4], $e[5], $e[1], $e[2], $e[0]);
        return date("d.m.Y H:i:s", $timestamp);
    }

}

?>