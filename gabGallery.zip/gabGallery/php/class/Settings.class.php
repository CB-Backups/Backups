<?php

/**
 * Daten der settings.ini auslesen sowie diese bearbeiten
 */
class Settings {

    public $inifile = 'php/config/settings.ini';

    /**
     * $data ist die INI-Datei als assoziativen Array
     * $file ist ein numerisches Array der INI-Datei
     */
    function __construct() {
        $data = parse_ini_file($this->inifile, true);
        $file = file($this->inifile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $this->data = $data;
        $this->file = $file;
    }

    public function getGalleryTitle() {
        return $this->data['gallery']['title'];
    }

    public function getGallerySlogan() {
        return $this->data['gallery']['slogan'];
    }

    public function getGalleryMeta() {
        return $this->data['meta'];
    }

    public function getGalleryTheme() {
        return $this->data['color']['theme'];
    }

    public function getGalleryColor() {
        return $this->data['color']['color'];
    }

    public function getGalleryStatus() {
        return $this->data['closed']['status'];
    }

    public function getInstallationStatus() {
        return $this->data['installation']['status'];
    }

    public function getGalleryMessage() {
        if (strlen($this->data['closed']['message']) == "0") {
            return "Der Galeriebesitzer hat keinen Grund angegeben";
        } else {
            return "<b>Grund: </b>" . $this->data['closed']['message'];
        }
    }

    public function getPicturesLicenseType() {
        return $this->data['license']['type'];
    }

    public function getPicturesLicenseLink() {
        $license = $this->getPicturesLicenseType();
        switch ($license) {
            case '0':
                return "&copy; " . date('Y') . " " . $this->getGalleryTitle();
                break;
            case '1': $type = 'by';
                break;
            case '2': $type = 'by-nd';
                break;
            case '3': $type = 'by-nc';
                break;
            case '4': $type = 'by-nc-nd';
                break;
            case '5': $type = 'by-nc-sa';
                break;
            case '6': $type = 'by-sa';
                break;
            default:
                return "&copy; " . date('Y') . " " . $this->getGalleryTitle();
                break;
        }
        return '<a title="License of Photos" rel="license" target="_blank" href="http://creativecommons.org/licenses/' . $type . '/3.0/deed.de"><img alt="Creative Commons Lizenzvertrag" style="border-width:0" src="http://i.creativecommons.org/l/' . $type . '/3.0/80x15.png"></a>';
    }

    public function checkInstallationStatus() {
        $status = $this->getInstallationStatus();
        if ($status == 0) {
            return '<p class="err"><i class="icon-info"></i>gabGallery muss noch installiert werden. <a href="install.php">Jetzt installieren</a></p>';
        }
    }

    public function checkLicenseRadios() {
        $arr = array();
        $lt = $this->data['license']['type'];
        for ($i = 0; $i < 10; $i++) {
            if ($lt == $i) {
                $arr[$i] = "checked";
            } else {
                $arr[$i] = '';
            }
        }
        return $arr;
    }

    /**
     * Speichert neue Daten in der settings.ini
     * @param string $title Titel der Galerie
     * @param string $slogan Slogan der Galerie
     * @param string $author meta-tag "author"
     * @param string $desc meta-tag "description"
     * @param string $keywords meta-tag "keywords"
     * @param int $licensetype Lizenztype
     * @return string Fehlermeldung oder Erfolg-Meldung
     */
    public function setGalleryData($title, $slogan, $author, $desc, $keywords, $licensetype) {
        $data = $this->file;
        $data[1] = "title=" . $title;
        $data[2] = "slogan=" . $slogan;
        $data[4] = "author=" . $author;
        $data[5] = "desc=" . $desc;
        $data[6] = "keywords=" . $keywords;
        $data[14] = "type=" . $licensetype;
        if (!is_writable($this->inifile)) {
            return "Es ist ein Fehler aufgetreten. Die Datei '" . $this->inifile . "' kann nicht beschrieben werden.";
        }
        $fp = fopen($this->inifile, 'wb');
        foreach ($data as $value)
            fwrite($fp, preg_replace("/[^0-9a-zA-Z_äÄöÖüÜß,.=\[\] ]/", "", $value) . "\n");
        fclose($fp);
        return "Die Daten wurden erfolgreich gespeichert.";
    }

    /**
     * Speichert neue Daten in der settings.ini
     * @param string $theme Template Farbe
     * @param string $color Akzent Farbe
     * @return string Fehlermeldung oder Erfolg-Meldung
     */
    public function setGalleryColor($theme, $color) {
        $data = $this->file;
        $data[8] = "theme=" . $theme;
        $data[9] = "color=" . str_replace("#", "", $color);
        if (!is_writable($this->inifile)) {
            return "Es ist ein Fehler aufgetreten. Die Datei '" . $this->inifile . "' kann nicht beschrieben werden.";
        }
        $fp = fopen($this->inifile, 'wb');
        foreach ($data as $value)
            fwrite($fp, $value . "\n");
        fclose($fp);
        return "Die Daten wurden erfolgreich gespeichert.";
    }

    /**
     * Schließt die Galerie und prüft ob eine Nachricht hinterlassen wurde und speichert diese ggf.
     * @param string $message (optional) Nachricht
     * @return string Fehlermeldung oder Erfolg-Meldung 
     */
    public function closeGallery($message) {
        $data = $this->file;
        $data[11] = "status=1";
        $data[12] = "message=" . preg_replace("/[^0-9a-zA-Z_äÄöÖüÜß ]/", "", $message);
        if (!is_writable($this->inifile)) {
            return "Es ist ein Fehler aufgetreten. Die Datei '" . $this->inifile . "' kann nicht beschrieben werden.";
        }
        $fp = fopen($this->inifile, 'wb');
        foreach ($data as $value)
            fwrite($fp, $value . "\n");
        fclose($fp);
        return "Die Galerie wurde geschlossen.";
    }

    /**
     * Öffnet die Galerie und löscht die Nachricht ggf.
     * @return string Fehlermeldung oder Erfolg-Meldung 
     */
    public function openGallery() {
        $data = $this->file;
        $data[11] = "status=0";
        $data[12] = "message=";
        if (!is_writable($this->inifile)) {
            return "Es ist ein Fehler aufgetreten. Die Datei '" . $this->inifile . "' kann nicht beschrieben werden.";
        }
        $fp = fopen($this->inifile, 'wb');
        foreach ($data as $value)
            fwrite($fp, $value . "\n");
        fclose($fp);
        return "Die Galerie ist wieder offen.";
    }

    public function setGalleryIsInstalled() {
        $data = $this->file;
        $data[16] = "status=1";
        if (!is_writable($this->inifile)) {
            return "Es ist ein Fehler aufgetreten. Die Datei '" . $this->inifile . "' kann nicht beschrieben werden.";
        }
        $fp = fopen($this->inifile, 'wb');
        foreach ($data as $value)
            fwrite($fp, $value . "\n");
        fclose($fp);
    }

}

?>