<?php

/**
 * Upload von Fotos
 */
class Upload {

    /**
    * Überprüft die Maximale Dateigröße, die hochgeladen werden darf
    * 
    * @return int - Größe in MB
    **/
    public function getMaxFileSize() {
        $mu = $this->calcBytes(ini_get('upload_max_filesize'));
        $mp = $this->calcBytes(ini_get('post_max_size'));
        $ml = $this->calcBytes(ini_get('memory_limit'));
        return min($mu, $mp, $ml)/1048576;
    }

    /**
    * Upload-Prozedur (Prüft Dateiendung, generiert neuen Dateinamen, speichert die Datei)
    * 
    * @param array $_FILES - Array mit den Daten
    * @return string - Erfolg-/Fehlermeldung(en)
    **/
    public function uploadPictures($pictures) {
        $i = 0;
        foreach ($pictures as $file) {
            foreach ($file['name'] as $filename) {
                $file_ext = $this->getOnlyFileExtension($filename);
                if (strtolower($file_ext) == "jpg" || strtolower($file_ext) == "jpeg" || strtolower($file_ext) == "png") {
                    $newfn = $this->generateNewFileName($filename);
                    if (file_exists('upload/' . $newfn)) {
                        $newfn1 = $this->generateNewFileSuffix($filename);
                        $newfn = $this->generateNewFileName($newfn1);
                    }
                } else {
                    return "<p class='err'><i class='icon-cancel'></i>Die Datei '" . $filename . "' konnte nicht hochgeladen werden, da Sie keine jpg- oder png-Datei  ist.</p>";
                }
                move_uploaded_file($file['tmp_name'][$i], 'upload/' . $newfn);
                $i++;
            }
        }
        return "<p class='message'><i class='icon-check'></i>".$i." Bild(er) wurden erfolgreich hochgeladen. Sie sind nun in der Galerie verfügbar.</p>";
    }

    /**
    * Nur Dateiname zurückgeben
    * 
    * @param string - Dateiname bzw. Dateipfad
    * @return string - Gibt nur Dateinamen zurück
    **/
    public function getOnlyFileName($filename) {
        return pathinfo($filename, PATHINFO_FILENAME);
    }

    /**
    * Nur Dateiendung zurückgeben
    * 
    * @param string - Dateiname bzw. Dateipfad
    * @return string - Gibt nur Dateiendung zurück
    **/
    public function getOnlyFileExtension($filename) {
        return pathinfo($filename, PATHINFO_EXTENSION);
    }

    /**
    * Neuen Dateinamen (ohne Sonderzeichen) generierern
    * 
    * @param string - Dateiname
    * @return string - Gibt neuen Dateinamen zurück
    **/
    public function generateNewFileName($oldfn) {
        $tmp = preg_replace("/[^0-9a-zA-Z ._-]/", "", $oldfn);
        $newfn = str_replace(" ", "_", $tmp);
        return $newfn;
    }

    /**
    * Neue Dateinamen-Endung generierern wenn Dateiname bereits vorkommt (hängt '_<zahl>' an dateinamen an)
    * 
    * @param string - neuer Dateiname
    * @return string - Gibt neuen Dateinamen zurück
    **/
    public function generateNewFileSuffix($oldfn) {
        $file_name = $this->getOnlyFileName($oldfn);
        $file_ext = $this->getOnlyFileExtension($oldfn);
        for ($f = 1; $f < 99999; $f++) {
            if (!file_exists('upload/' . $file_name . "_" . $f . "." . $file_ext)) {
                return $file_name . "_" . $f . "." . $file_ext;
                break;
            } else {
                continue;
            }
        }
    }

    /**
    * Macht aus einem php.ini-Wert eine Byte-Zahl
    * 
    * @author Marcel Heisinger (https://github.com/marhei)
    * @param string $sizeString - Ein Größen-String
    * @return int - Eine Größe in Byte
    **/
    public function calcBytes($sizeString) {
        $sizeString = trim($sizeString);
        $last = strtolower($sizeString[strlen($sizeString)-1]);
        switch($last) {
            case 'g':
                $sizeString *= 1024;
            case 'm':
                $sizeString *= 1024;
            case 'k':
                $sizeString *= 1024;
        }

        return $sizeString;
    }

}

?>