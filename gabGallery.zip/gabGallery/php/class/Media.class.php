<?php

/**
 * Für die Verwaltung der Fotos
 */
class Media {

    /**
     * Lädt alle Bilder in ein num. Array (einmal die Orginale und einmal die Vorschaubilder)
     */
    function __construct() {
        $allthumbs = glob('upload/thumbs/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);
        $allpictures = glob('upload/*.{jpeg,jpg,JPG,JPEG,png,PNG}', GLOB_BRACE);
        $this->allthumbs = $allthumbs;
        $this->allpictures = $allpictures;
    }

    /**
     * Gibt ein Array zurück mit allen jpg/jpeg-Dateien im /upload-Ordner
     * @return type
     */
    public function showUploadedFiles() {
        return $this->allpictures;
    }

    /**
     * Gibt Anzahl der jpg/jpeg-Dateien im /upload-Ordner zurück
     * @return int Anzahl der Fotos
     */
    public function getUploadedPicturesNum() {
        $num = count($this->allpictures);
        return $num;
    }

    /**
     * Gibt Anzahl der jpg/jpeg-Dateien im /upload-Ordner zurück (Als String)
     * @return string Anzahl der Fotos
     */
    public function getUploadedPicturesString() {
        $num = $this->getUploadedPicturesNum();
        if ($num == "0")
            return "N/A";
        elseif ($num == "1")
            return "1 Bild";
        else
            return $num." Bilder";
    }

    /**
     * Gibt Anzahl der jpg/jpeg-Dateien im /upload/thumbs/-Ordner zurück
     * @return int Anzahl der Fotos
     */
    public function getGeneratedThumbsNum() {
        $num = count($this->allthumbs);
        return $num;
    }
    
    /**
     * Löscht das Bild und das passende Thumbnail, wenn dieses existiert
     * @param array $files Bilder die gelöscht werden sollen
     */
    public function deleteFiles($files) {
        foreach ($files as $filename => $value) {
            $file = str_ireplace(array("_jpg", "_jpeg","_png"), array(".jpg", ".jpeg",".png"), $filename);
            $thumb = str_replace("/", "/thumbs/", $file);
            unlink($file);
            if (file_exists($thumb))
                unlink($thumb);
        }
    }
    /**
     * Berechnet den Speicherplatzverbrauch der Galerie
     * @return string Größe in MB
     */
    public function getSizeofUploadDir() {
        $size = 0;
        $thumbs = $this->allthumbs;
        $pictures = $this->allpictures;
        foreach ($thumbs as $value) {
            $fs = @filesize($value);
            $size += $fs;
        }
        foreach ($pictures as $value) {
            $fs = filesize($value);
            $size += $fs;
        }
        $size_mb = $size / 1048576;
        $round = round($size_mb, 2);
        return number_format($round,2, ',', '.') ;
    }

}

?>