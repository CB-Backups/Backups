<?php
//diese Datei wird während der Installation generiert
?>
