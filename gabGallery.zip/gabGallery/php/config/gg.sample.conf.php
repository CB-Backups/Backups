<?php

/* *** gabGallery Beispiel-Datei *** */

//MySQL-Server-Host (bspw.: localhost)
$host = '';

//MySQL-Benutzer
$user = '';

//MySQL-Passwort
$password = '';

//Datenbank für gabGallery (muss existieren)
$database = '';
?>