<script>
Mousetrap.bind("g", function() { window.location.href = 'index.php'; });
Mousetrap.bind("1", function() { window.location.href = 'admin.php?s=home'; });
Mousetrap.bind("2", function() { window.location.href = 'admin.php?s=upload'; });
Mousetrap.bind("3", function() { window.location.href = 'admin.php?s=delete'; });
Mousetrap.bind("4", function() { window.location.href = 'admin.php?s=close'; });
Mousetrap.bind("5", function() { window.location.href = 'admin.php?s=color'; });
Mousetrap.bind("6", function() { window.location.href = 'admin.php?s=settings'; });
Mousetrap.bind("7", function() { window.location.href = 'admin.php?s=help'; });
Mousetrap.bind("8", function() { window.location.href = 'admin.php?s=info'; });

Mousetrap.bind("l o", function() { 
	if (confirm('Möchten Sie sich ausloggen?')) {
	 window.location.href = "logout.php"; 
	};
});
Mousetrap.bind("?", function() { 
	alert('Keyboard-Shortcuts:\n\nZwischen Seiten navigieren:\t 1-8\n\nMehr Keyboard-Shortcuts finden Sie unter "Hilfe"'); 
});
</script>