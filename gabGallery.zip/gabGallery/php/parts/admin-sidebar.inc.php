<ul>
    <li><a href="admin.php?s=home"><i class="icon-database"></i> Admin-Übersicht</a></li>
    <li><a href="admin.php?s=upload"><i class="icon-camera"></i> Bilder hochladen</a></li>
    <li><a href="admin.php?s=delete"><i class="icon-trash"></i> Bilder löschen</a></li>
    <li><a href="admin.php?s=close"><i class="icon-lock"></i> Galerie schließen</a></li>
    <li><a href="admin.php?s=color"><i class="icon-magic"></i> Stilfarben ändern</a></li>
    <li><a href="admin.php?s=settings"><i class="icon-settings"></i> Einstellungen</a></li>
    <li><a href="admin.php?s=help"><i class="icon-help"></i> Hilfe</a></li>
    <li><a href="admin.php?s=info"><i class="icon-info"></i> Über gabGallery</a></li>
</ul>