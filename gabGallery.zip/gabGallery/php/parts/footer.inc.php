        <div class="clearfix"></div>
        <div id="footer">
            <?php 
            $load = new Page();
            $set = new Settings();
            echo "<span class=\"license\">".$set->getPicturesLicenseLink()."</span>";
            echo $load->loadFooterLinks();
            ?>
        </div>
    </body>
</html>