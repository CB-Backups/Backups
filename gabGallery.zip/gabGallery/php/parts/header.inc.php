<?php
$data = new Settings();
$title = $data->getGalleryTitle();
$meta = $data->getGalleryMeta();
$slogan = $data->getGallerySlogan();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?=$title?> &middot; <?=$slogan?></title>
        <meta name="author" content="<?=$meta['author']?>">
        <meta name="keywords" content="<?=$meta['keywords']?>">
        <meta name="description" content="<?=$meta['desc']?>">
        <meta name="generator" content="gabGallery 2">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/normalize.min.css">
        <link rel="stylesheet" href="css/gabgallery.css">
        <link rel="shortcut icon" href="css/favicon.ico">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script src="js/vendor/jquery.mousewheel-3.0.6.pack.js"></script>
        <script src="js/vendor/jquery.fancybox.pack.js"></script>
        <script src="js/vendor/helpers/jquery.fancybox-thumbs.js"></script>
        <script src="js/vendor/farbtastic.js"></script>
        <script src="js/vendor/mousetrap.min.js"></script>
        <script src="js/main.js"></script>
    </head>
    <body>
        <noscript><div id="nojsactive"><p>Um den vollen Funktionsumfang von gabGallery nutzen können, <a href="http://www.enable-javascript.com/de/">aktiviere bitte JavaScript</a>.</p></div></noscript>
        <div id="top">
            <a href="index.php" class="logo"><?=$title?></a>
            <span class="slogan">- <?=$slogan?></span>
        </div>
