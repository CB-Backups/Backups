<?php

session_start();

if (!isset($_SESSION['admin']))
    header('Location: index.php');

require_once 'php/class/Login.class.php';

$a = new Login();
$a->logout();
header('Location: index.php?logout');
?>