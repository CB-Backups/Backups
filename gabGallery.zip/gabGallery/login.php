<?php

session_start();
if (isset($_SESSION['admin']))
    header('Location: admin.php');

function __autoload($class) {
    require_once 'php/class/' . $class . '.class.php';
}

$login = new Login();
$load = new Page();

$load->loadHeader();
if (isset($_POST['go']) && (strlen($_POST['user']) != 0) && (strlen($_POST['pass']) != 0)) {
    echo $login->login($_POST['user'], $_POST['pass']);
    $load->loadLogin();
} elseif (isset($_POST['go'])) {
    echo "<p class='err'><i class='icon-cancel'></i> Bitte füllen Sie das Formular vollständig aus, um sich einzuloggen.</p>";
    $load->loadLogin();
} else
    $load->loadLogin();
$load->loadFooter();

if (isset($_SESSION['admin']))
    header('Location: admin.php?login');
?>