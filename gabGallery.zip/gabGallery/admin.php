<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

function __autoload($class) {
    require_once 'php/class/' . $class . '.class.php';
}

$s = (isset($_GET['s'])) ? $_GET['s'] : 'home';

$load = new Page();
$load->loadHeader();
$load->loadBackend($s);
$load->loadBackendKeyboardShortcuts();
$load->loadFooter();
?>