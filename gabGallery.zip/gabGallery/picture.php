<?php

/* Thumbnail-Anzeige und eventl. Erzeugung des Thumbs */

require 'php/class/Main.class.php';
$main = new Main();

if (isset($_GET['file'])) {
    $file = urlencode($_GET['file']);
    $picture = 'upload/' . $file;
    $thumb = 'upload/thumbs/' . $file;
    $fe = strtolower(pathinfo($_GET['file'], PATHINFO_EXTENSION));
    if ($fe == 'jpg' || $fe == 'jpeg') {
        header('Content-Type: image/jpeg');
    } elseif ($fe == 'png') {
        header('Content-Type: image/png');
        $main->createThumbnail($file);
        readfile($thumb);
    }

    if (file_exists($thumb)) {
        readfile($thumb);
    } else {
        $main->createThumbnail($file);
        if (file_exists($thumb)) {
            readfile($thumb);
        }
    }
}
?>