<?php
$themes = array('black' => '#000', 'white' => '#fefefe');
$data = parse_ini_file("../php/config/settings.ini");
$t = $themes[$data['theme']];
$c = "#".$data['color'];
$e = ($t == "#000") ? "#fff" : "#000";
header('Content-type: text/css');
?>
::-moz-selection {background-color:<?= $c ?>;}
::selection {background-color:<?= $c ?>;}
body {background-color:<?= $t ?>;color:<?= $e ?>;}
a {color:<?= $e ?>;}
#top {border-color:<?= $c ?>;}
#top {color:<?= $e ?>;}
#top a.logo {color:<?= $e ?>;}
#top a.logo:hover {color:<?= $c ?>;}
#footer a.link {color:<?= $e ?>;border-color:<?= $e ?>;}
#content span.sep{border-color:<?= $c ?>;}
.sepend {border-color:<?= $c ?>;}
#sidebar ul li {border-color:<?= $c ?>;}
#admin input[type=text], #admin input[type=password] {background-color:<?= $t ?>;color: <?= $e ?>;border-color:<?= $c ?>;}
#admin input[type=submit], #admin button {background-color:<?= $t ?>;color: <?= $e ?>;border-color:<?= $e ?>;}
.licensetext {border-color:<?= $c ?>;}