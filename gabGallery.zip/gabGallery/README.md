# gabGallery 2

[English readme](https://gist.github.com/GabrielWanzek/8a7c68ecbe2b8a5c0dec)

Eine simple und moderne Galerie - PHP, HTML5, CSS3 und ein bisschen jQuery.

Demo: [hier](http://mangopix.de/ps) (könnte eine ältere Version sein)

## Anforderungen

### Server
* Webserver (e.g. Apache 2.2+, lighttpd, nginx ...)
* PHP 5.3 (Memory-Limit > 32M)
* MySQL Datenbank (v5+)

### Benutzer
* Ein moderner Browser (Chrome, Firefox, Safari, Opera .. oder IE9+)
* Der Browser sollte Javascript aktiviert haben

## Installation

1. Aktuelleste Version herunterladen: [ZIP](https://github.com/GabrielWanzek/gabGallery/zipball/master) _oder_ [TAR](https://github.com/GabrielWanzek/gabGallery/tarball/master).
2. Archiv entpacken und auf den Webserver hochladen
3. Der Galerie chmod 777 geben (rekursiv)
4. Beim Aufrufen erscheint eine Meuldung, die zur Installation führt.. Installieren!
5. Installationsskript löschen
6. Spaß haben! :v:

__Achtung! gabGallery befindet sich immernoch in der Entwicklungsphase!__

## gG Version 1

Die Version 1 war der Grundgedanke des Projektes, welches jedoch den zeitlichen Rahmen sprengen würde. Daher wurde diese Version verworfen.
Die neue Version 2 ist kleiner & simpler, trotzdem ist diese super! Ich plane bereits gabGallery weiterzuentwickeln, mit mehr Funktionen (wie in v1).

### HTML5/CSS3 Template von gG Version 1
*  MIT-License 
* Download: [here](http://mangopix.de/projects/gabGallery_v1_template.zip)
* Demo: [here](http://mangopix.de/projects/gabGallery_template/)
