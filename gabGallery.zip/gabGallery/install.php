<?php
/**
 *  Title:          gabGallery2 Installation
 *  Authors:        Gabriel Wanzek
 *  Version:        v1.4
 *  License:        MIT License
 *  Requirements:   PHP 5.3 | MySQL-Server
 */
require 'php/class/Settings.class.php';
$cf = "php/config/gg.conf.php";
$cfw = is_writable($cf);
$message = "";
$settings = new Settings();

function hashPassword($pw) {
    return sha1($pw) . hash('crc32', $pw);
}

if (isset($_POST['dbhost']) && isset($_POST['dbuser'])) {
    $link = mysql_connect($_POST['dbhost'], $_POST['dbuser'], $_POST['dbpw']);
    mysql_query("CREATE DATABASE IF NOT EXISTS " . $_POST['dbname'], $link) or die(mysql_error());
    $selectdb = mysql_select_db($_POST['dbname'], $link);
    if (!$link) {
        die('Bitte &uuml;berpr&uuml;fen Sie die eingegebenen Daten!<br>Fehlermeldung: ' . mysql_error());
    } elseif (!$selectdb) {
        die('Bitte &uuml;berpr&uuml;fen Sie die eingegebenen Daten<br>Fehlermeldung: ' . mysql_error());
    } elseif (!$cfw) {
        echo "Geben Sie der Datei <code>" . $cf . "</code> Schreibrechte.";
    } elseif ($_POST['ggpw'] != $_POST['ggpw2']) {
        $message = "<span class=\"fail\">Die Passwörter stimmen nicht überein. Bitte  <a href='javascript:history.back();'>wiederholen</a> Sie die Installation. </span>";
    } else {
        $file = fopen($cf, 'w') or die("Datei " . $cf . " konnte nicht geoeffnet werden.");
        $mysqldata = "<?php\n\$host='" . $_POST['dbhost'] . "';\n\$user='" . $_POST['dbuser'] . "';\n\$password='" . $_POST['dbpw'] . "';\n\$database='" . $_POST['dbname'] . "';\n?>";
        fwrite($file, $mysqldata);
        fclose($file);
        mysql_select_db($_POST['dbname'], $link);
        mysql_query("DROP TABLE IF EXISTS `gg_userdata`") or die(mysql_error());
        mysql_query("CREATE TABLE `gg_userdata` (`id` int(11) not null auto_increment,`username` varchar(150),`password` varchar(255),`email` varchar(255),PRIMARY KEY (`id`))") or die(mysql_error());
        $hashedpw = hashPassword($_POST['ggpw']);
        $gguser = $_POST['gguser'];
        $ggmail = $_POST['ggmail'];
        mysql_query("INSERT INTO gg_userdata (username,password,email) VALUES ('$gguser','$hashedpw','$ggmail')") or die(mysql_error());
        $settings->setGalleryIsInstalled();
        $message = "<span class=\"yeah\">Installation war erfolgreich. Aus Sicherheitsgründen sollten Sie diese Datei löschen. <a href='index.php'>zur Galerie</a></span>";
    }
    mysql_close($link);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>gabGallery &middot; Installation</title>
        <link rel="stylesheet" href="../css/normalize.min.css" media="all">
        <style>
            body {font-family: Verdana,Arial,Helvetica,sans-serif;font-size:12pxbackground:#7d7e7d;background:-moz-linear-gradient(top,#7d7e7d 0,#0e0e0e 100%);background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,#7d7e7d),color-stop(100%,#0e0e0e));background:-webkit-linear-gradient(top,#7d7e7d 0,#0e0e0e 100%);background:-o-linear-gradient(top,#7d7e7d 0,#0e0e0e 100%);background:-ms-linear-gradient(top,#7d7e7d 0,#0e0e0e 100%);background:linear-gradient(to bottom,#7d7e7d 0,#0e0e0e 100%); background-size: 2000px 1000px}
            .clear {clear:both;height:1px}
            .form {margin:20px auto 0;width:500px;padding:14px; box-shadow: 0 0 5px #ccc;}
            #install {border:solid 2px #476AD3;background:#efefef;border-radius: 5px;}
            #install h1 {font-size:14px;font-weight:bold;margin-bottom:8px}
            #install p {font-size:11px;color:#666;margin-bottom:20px;border-bottom:solid 1px #476AD3;padding-bottom:10px}
            #install label {font-size: 12px;display:block;font-weight:bold;text-align:right;width:240px;float:left}
            #install .small {color:#666;display:block;font-size:11px;font-weight:normal;text-align:right;width:240px}
            #install input {float:left;font-size:12px;padding:4px 2px;border:solid 1px #ccc;width:200px;margin:2px 0 20px 10px}
            #install input:focus {background-color: #A9B6EB;}
            #install input[type=submit] {border-radius: 5px;clear:both;margin-left:330px;width:125px;height:31px;background:#666;text-align:center;line-height:31px;color:#fff;font-size:13px;}
            #install input[type=submit]:hover {background-color: #222;}
            #install input[type=submit]:active {box-shadow: 0 0 3px #222;}
            span.fail{width:80%;font-size:13px;text-align:center;background:#ffdfdf;display:block;padding:10px;margin:5px auto;border:1px solid #ffcfce;border-radius:5px}
            span.yeah{width:80%;font-size:13px;text-align:center;background:#d6f7db;display:block;padding:10px;margin:5px auto;border:1px solid #c7f5ce;border-radius:5px}
        </style>
    </head>
    <body>
        <?php echo ($cfw) ? "" : "<span class=\"fail\">Geben Sie der Datei <code>includes/config.inc.php</code> Schreibrechte</span>"; ?>
        <?php echo $message; ?>
        <?php echo (PHP_VERSION_ID > 50300) ? "" : "<span class=\"fail\">Ihre PHP-Version (" . PHP_VERSION . ") ist zu alt. gabGallery könnte somit nicht funktionieren.</span>"; ?>
        <div id="install" class="form">
            <form id="form" name="form" method="post" action="install.php">
                <h1>gabGallery &middot; Installation</h1>
                <p>MySQL-Server Daten</p>
                <label>Datenbank-Host
                    <span class="small">Standard: <code>localhost</code></span>
                </label>
                <input type="text" name="dbhost">
                <label>Datenbank-Name
                    <span class="small">Datenbank kann erstellt werden</span>
                </label>
                <input type="text" name="dbname">
                <label>Benutzername
                    <span class="small">f&uuml;r den MySQL-Server</span>
                </label>
                <input type="text" name="dbuser">
                <label>Passwort
                    <span class="small">des MySQL-Benutzers</span>
                </label>
                <input type="password" name="dbpw">
                <p>gabGallery Daten</p>
                <label>Benutzername
                    <span class="small">f&uuml;r gabGallery</span>
                </label>
                <input type="text" name="gguser">
                <label>Passwort
                    <span class="small">mind. 5 Zeichen</span>
                </label>
                <input type="password" name="ggpw">
                <label>Passwort wdh.
                    <span class="small">zur Sicherheit</span>
                </label>
                <input type="password" name="ggpw2">
                <label>E-Mail
                    <span class="small">g&uuml;ltige E-Mail-Adresse</span>
                </label>
                <input type="email" name="ggmail">
                <input type="submit" value="ausf&uuml;hren">
                <div class="clear"></div>
            </form>
        </div>
    </body>
</html>