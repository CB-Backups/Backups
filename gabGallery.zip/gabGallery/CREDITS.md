# gabGallery 2 - Credits

## Javascripts/jQuery

### FancyBox 2.1.4

* License: CC BY-NC 3.0 (http://creativecommons.org/licenses/by-nc/3.0/)
* Homepage: http://www.fancyapps.com/fancybox/

### Farbtastic Color Picker 1.2

* License: GPL 3.0 (http://www.gnu.org/licenses/gpl.html)
* Homepage: http://acko.net/blog/farbtastic-jquery-color-picker-plug-in/

### Mousetrap v1.3.2

* License: Apache License,v2.0 (http://www.apache.org/licenses/LICENSE-2.0)
* Homepage: http://craig.is/killing/mice

## PHP Snippets

### Upload calcBytes()
* Copyright (C) 2012-2013 Marcel Heisinger
* License: Apache License, v2.0 (http://www.apache.org/licenses/LICENSE-2.0)
* Homepage: http://marcel-heisinger.de/

## Graphics, Icons, Fonts

### Icons (as font) [by http://fontello.com]
__Entypo__
* Copyright (C) 2012 by Daniel Bruce
* License:   SIL (http://scripts.sil.org/OFL)
* Homepage:  http://www.entypo.com

__Font Awesome__
* Copyright (C) 2012 by Dave Gandy
* License:   CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/)
* Homepage:  http://fortawesome.github.com/Font-Awesome/

### Lock HD icon
* by Vlademareous
* License:   CC BY-NC-SA 3.0 (http://creativecommons.org/licenses/by-nc-sa/3.0/)
* Homepage:  http://vlademareous.deviantart.com/

### Source Sans Pro
* by Paul D. Hunt for Adobe Systems
* License:   SIL (http://scripts.sil.org/OFL)
* Homepage:  http://store1.adobe.com/cfusion/store/html/index.cfm?store=OLS-US&event=displayFontPackage&code=1959

