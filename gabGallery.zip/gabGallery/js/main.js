$(document).ready(function() {
    $(".fancybox").fancybox({
        type        : 'image',
        padding     : 0,
        openEffect	: 'none',
        openSpeed	: 200,
        closeEffect	: 'none',
        closeSpeed	: 200,
        prevEffect	: 'fade',
        nextEffect	: 'fade',
        
        helpers : {
            title	: {
                type: 'over'
            },
            thumbs	: {
                width: 50,
                height: 50
            }
        },
        afterShow : function() {
            $(".fancybox-title").hide();

            $(".fancybox-wrap").hover(function() {
                $(".fancybox-title").stop(true,true).fadeIn(500);
            }, function() {
                $(".fancybox-title").stop(true,true).fadeOut(250);
            });
        }
        
    })

    $("#hidden_link").fancybox({
        type        : 'inline',
        closeBtn    : false,
        closeClick  : false,
        autoSize    : false, 
        height      : 300,
        width       : 600,
        maxHeight   : 450,
        maxWidth    : 700,
        openEffect  : 'fade',
        openSpeed   : 200,
        closeEffect : 'fade'

    });
});