<?php

/**
 *  Title:          gabGallery 2
 *  Authors:        Gabriel Wanzek
 *  Version:        see php/version.txt
 *  License:        MIT License
 *  Requirements:   PHP 5.3 | MySQL-Server
 *  Link:           https://github.com/GabrielWanzek/gabGallery
 */
session_start();

error_reporting(E_ERROR | E_WARNING | E_PARSE);

function __autoload($class) {
    require_once 'php/class/' . $class . '.class.php';
}

$load = new Page();
$load->loadHeader();
$load->loadHome();
$load->loadFooter();
?>