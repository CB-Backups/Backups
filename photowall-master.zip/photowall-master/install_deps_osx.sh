#!/bin/bash

brew -v >/dev/null 2>&1 || { echo "homebrew is required. please install it. (http://brew.sh/)" >&2; exit 1; }

brew update
#brew upgrade
brew install imagemagick