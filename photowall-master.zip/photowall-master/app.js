// ------- init -------
hound = require('hound')
fs    = require('fs')
gm    = require('gm').subClass({ imageMagick: true });

app = {
    config: {
        sourceDir: './source',
        photosDir: './photos',
        thumbsDir: './thumbs',
        extensions: ['jpg', 'png'],
        thumbSize: 250,
        viewSize: 2000,
    }
}

images = [];

// ------- extendings/core functions -------
if (!Array.prototype.last){
    Array.prototype.last = function(){
        // @todo check key exists
        return this[this.length - 1];
    };
};

// ------- app-functions -------
function init() {
    fs.readdir(app.config.sourceDir, function(err, list) {
        if (err) throw err;
        list.forEach(function(filename, i) {
            if (filename.indexOf('.') > -1) {
                var extension = filename.split('.').last().toLowerCase();
                if (app.config.extensions.indexOf(extension) >= 0) {
                    console.log('INIT| found: ' + filename);
                    images.push(app.config.sourceDir + '/' + filename);
                    resizeSource(filename);
                }
            }
        });
    });
}

function watchSource() {
    watcherSource = hound.watch(app.config.sourceDir)
    watcherSource.on('create', function(file, stats) {
        console.log('WTCH| ' + file + ' found')
        resizeSource(file.split('/').last());
    })
    watcherSource.on('delete', function(file) {
        console.log('WTCH|' + file + ' was deleted')
        fs.unlink(file.replace(app.config.sourceDir, app.config.photosDir), function(e) {
            console.log(e);
        });
        fs.unlink(file.replace(app.config.sourceDir, app.config.thumbsDir), function(e) {
            console.log(e);
        });
    })
}

function resizeSource(image) { // source => photo
    var filename = app.config.sourceDir + '/' + image;
    fs.exists(filename, function(exists) {
        if (exists) {
            if (fs.existsSync(filename.replace(app.config.sourceDir, app.config.photosDir))) {
                return;
            }
            gm(filename)
            .quality(70)
            .resize(app.config.viewSize, app.config.viewSize)
            .noProfile()
            .write(filename.replace(app.config.sourceDir, app.config.photosDir), function (err) {
                if (!err) {
                    console.log('RS  | done: ' + filename);
                    makeThumb(image);
                } else {
                    console.log('RS  | Error: ', err);
                }
            });
        } else {
            console.log('RS  | file not found: ' + filename);
        }
    });
    
}

function makeThumb(image) { // photo => thumb
    var filename = app.config.photosDir + '/' + image;
    fs.exists(filename, function(exists) {
        if (exists) {
            if (fs.existsSync(filename.replace(app.config.photosDir, app.config.thumbsDir))) {
                return;
            }
            /** 
             * Sadly SmartCrop is not usable for production use atm
             * - also has to much deps for easy usage.
             * - http://git.io/v8isV
            SmartCrop.crop(filename, {
                width: app.config.thumbSize,
                height: app.config.thumbSize
            }, function(result) {
                console.log('MT  | ' + result);
            });
            */
            gm(filename)
            .resize(app.config.thumbSize, app.config.thumbSize)
            .write(filename.replace(app.config.photosDir, app.config.thumbsDir), function (err) {
                if (!err) {
                    console.log('MT  | done: ' + filename);
                    makeThumb(image);
                } else {
                    console.log('MT  | Error: ', err);
                }
            });
        } else {
            console.log("MT  | file not found: " + filename);
        }
    });
}

// start
init();
watchSource();