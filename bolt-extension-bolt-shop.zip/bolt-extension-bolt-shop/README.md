# bolt-extension-bolt-shop

**This extension is atm just a idea. implementation will start as we learned how to deal with symphony and silex :) .**

**We don't know if this is even possible**

a simple shop for the bolt cms (http://bolt.cm)


## functions

* client area
* add/edit/delete products
* set products online/offline
* availability of products (in stock, available in 3-4 weeks, sold out etc.)
* small inventory control system
* coupon system
* payment-options
* shipping-options and costs
* tax and currency
* "content-types" for products for easy customizing custom product fields




## "nice to have"-features

* all mails send with <http://mandrill.com>

### payment gateways

* amazon payment
* paypal
* credit card
* bitcoin
* google wallet
* bank transfer
* cash on delivery
