<?php 
session_start();
if ((@$_SESSION['admin'] == false) || (!isset($_POST['edit_post']))){
    header("Location: index.php");
}
require_once 'config.php';

//----------------------------------------------------------
@$ed_id = $_POST['edit_post'];
$res = mysql_query("SELECT * FROM mb_posts;");			
echo mysql_result($res,$ed_id,"posttitle");
echo mysql_result($res,$ed_id,"posttext");

?>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $blogname." | ". $blogdescription;?> </title>
		<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
		<script src="js/jquery-1.8.3.min.js"></script>
	</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="index.php"><?php echo $blogname;?></a></h1>
				<p><?php echo $blogdescription ?></p>
			</div>
		</div>
	</div>
	<div id="page">
		<h1>Beitrag ändern</h1>
		<br>
		<fieldset>
			<legend id="bn">Neuer Beitrag</legend>
			<script src="ckeditor/ckeditor.js"></script>
			<form action="do.php" method="post">
				<p><input type="text" class="big" name="posttitle" required="required" placeholder="Beitragstitel"></p>
				<p>Beitrag:<br><textarea class="posttext" id="textarea" name="posttext" cols="30" rows="10"></textarea></p>
				<input type="hidden" name="posttype" value="1">
				<input type="submit" value="Posten" name="posted">
			</form>
		</fieldset>
		<script>
			CKEDITOR.replace( 'posttext', {
				language: 'de',
				height: 300
			});

		</script>
<div id="footer">
	<p>
		&copy; <?php echo date("Y")."&nbsp;".$blogname ?> | Powered by <a href="#">Mangolicious <?php echo $sysversion ?></a>
	</p>
</div>
</body>
</html>