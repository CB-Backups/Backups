Mangolicious
============

###ein einfacher Blog

Dieser Blog ist in PHP geschrieben, jedoch nicht objektorientiert, sondern eher primitiv und diente zu Lernzwecken.

- Der Blog nutzt HTML5/CSS3 sowie den CKEditor (v4.0)
- Daten werden aus einer MySQL-Datenbank gelesen
- Eigene Templates können relativ einfach eingebettet werden
