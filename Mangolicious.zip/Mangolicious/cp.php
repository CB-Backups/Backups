<?php 

session_start();
if (@$_SESSION['admin'] == false)
    header("Location: index.php");
require_once 'config.php';
//----------------------------------------------------------
$res = mysql_query("SELECT * FROM mb_posts ORDER BY id DESC;"); 
$num = mysql_num_rows($res);


?>

<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $blogname." | ". $blogdescription;?> </title>
		<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
		<script src="js/jquery-1.8.3.min.js"></script>
	</head>
<body>
<noscript>
	<div id="nojs">
		<span>
			<b>Ohne Javascript funktioniert Mangolicious nur teilweise.</b><br>Wichtige Dialoge werden somit nicht mehr angezeigt.
			<br>
			<a href="http://www.enable-javascript.com/de/" target="_blank">Wie aktiviere ich Javascript?</a>
		</span>
	</div>
</noscript>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="index.php"><?php echo $blogname;?></a></h1>
				<p><?php echo $blogdescription ?></p>

			</div>
		</div>
	</div>
	<div id="page">
		<h1>Control Panel</h1>
		<br>
			<div class="top-links">
				<a href="index.php">Startseite</a> | <a href="logout.php">Ausloggen</a>
			</div>
		<fieldset>
			<legend id="bn">Neuer Beitrag</legend>
			<script src="ckeditor/ckeditor.js"></script>
			<form action="do.php" method="post">
				<p>
					<input type="text" class="big" name="posttitle" id="posttitle" required="required" placeholder="Beitragstitel">
				</p>
				<p>Beitrag:<br>
					<textarea class="posttext" id="textarea" name="posttext"></textarea>
				</p>
				<input type="hidden" name="posttype" value="1">
				<input type="submit" value="Posten" name="posted">
			</form>
		</fieldset>
		<script>
				CKEDITOR.replace( 'posttext', {
					language: 'de',
					height: 300
				});
		</script>
		<fieldset>
			<legend id="be">Beitrag ändern</legend>
		<p>Welcher Beitrag soll geändert werden?</p>
			<form action="edit.php" method="post">
				<select name="edit_post" disabled="disabled">
					<option>Funktion steht noch nicht zur Vefügung</option>
					<?php 
					for($i=0;$i < $num; $i++) {
							echo "<option value=\"".mysql_result($res,$i,"id")."\">".mysql_result($res,$i,"posttitle")." | ".date("d.m.Y H:i",strToTime(mysql_result($res,$i,"posttime")))."</option>";
					}
					?>				
				</select>
				<input type="submit" value="Ändern" name="edit" disabled="disabled">
			</form>
		</fieldset>
		<br>
		<fieldset>
			<legend id="bl">Beiträg löschen</legend>
		<p>Welcher Beitrag soll gelöscht werden?</p>
			<form action="do.php" method="post">
				<select name="del_post">
					<?php 
					for($i=0;$i < $num; $i++) {
							echo "<option value=\"".mysql_result($res,$i,"id")."\">".mysql_result($res,$i,"posttitle")." | ".date("d.m.Y H:i",strToTime(mysql_result($res,$i,"posttime")))." | ID:".mysql_result($res,$i,"id")."</option>";
					}
					?>				
				</select>
				<input type="submit" value="Löschen" name="delete" onClick="return confirm(unescape('Sind Sie sich sicher, dass Sie den Beitrag l%F6schen m%F6chten?'))">
			</form>			
		</fieldset>
	</div>
</div>
<div style="text-align:center;">
	<a href="#wrapper" >nach oben</a>
	<br>
</div>


<div id="footer">
	<p>
		&copy; <?php echo date("Y")."&nbsp;".$blogname ?> | Powered by <a href="#">Mangolicious <?php echo $sysversion ?></a>
	</p>
</div>
</body>
</html>


