<?php 
session_start();
require_once 'config.php';
//----------------------------------------------------------
$res = mysql_query("SELECT * FROM mb_posts ORDER BY id DESC LIMIT 0,$showposts;"); 
$num = mysql_num_rows($res);
?>

<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $blogname." | ". $blogdescription;?> </title>
		<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
		<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
	</head>
<body>
<noscript>
	<div id="nojs">
		<span>
			<b>Ohne Javascript funktioniert Mangolicious nur teilweise.</b><br>Wichtige Dialoge werden somit nicht mehr angezeigt.
			<br>
			<a href="http://www.enable-javascript.com/de/" target="_blank">Wie aktiviere ich Javascript?</a>
		</span>
	</div>
</noscript>
<div id="wrapper">
		<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="index.php"><?php echo $blogname;?></a></h1>
				<p><?php echo $blogdescription ?></p>
			</div>
		</div>
	</div>
	<div id="page">
		<div id="content">
			<div class="contentbg">
				<?php				
					for($i=0;$i < $num; $i++){
						echo '
						<div class="post">
							<h3 class="title">'.mysql_result($res,$i,"posttitle").'</h3>
							<p class="meta">Gepostet von '.$autorname.' am '.date("d.m.Y \u\m H:i",strToTime(mysql_result($res,$i,"posttime"))).' Uhr</p>
								<div class="entry">
								<p>'.mysql_result($res,$i,"posttext").'</p>
								</div>
							</div>
						';
					}
				?>			
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
		<div id="sidebar-bg">
			<div id="sidebar">
				<ul>
					<li>
						<h2>Blogbeschreibung</h2>
						<p><?php echo $blogdescriptionlong ?></p>
					</li>
					<li>
						<h2>Über den Autor</h2>
						<p><?php echo $autorname.",&nbsp;".$autorage ?> Jahre alt</p>
					</li>
					<li>
						<h2>Mangolicious</h2>
						<p>Der einfache Blog!<br>
							<a href="https://github.com/GabrielWanzek">https://github.com/GabrielWanzek</a></p>
					</li>
					<li>
						<h2>Nützliche Links</h2>
						<ul>
							<li><a href="http://mangopix.de">Mangopix.de</a></li>
							<li><a href="http://webflix.de">Mangopix.de Server 'Melone'</a></li>
						</ul>
					</li>
					<li>
						<ul>
						<?php 
						if (@$_SESSION['admin'] == true) {
			 			 	echo '<h2>Logout</h2>
			 			 	<a href="cp.php">Control-Panel</a><br>
			 			 	<a href="logout.php">Logout</a>';
						}

						else {
							echo '
							<h2>Login</h2>
								<form action="login.php" method="post">
								<input type="text" name="username" style="width: 250px" placeholder="User"><br>
								<input type="password" name="password" style="width: 250px" placeholder="Passwort"><br>
								<input type="submit" value="Login">
							</form>';
						}

						
						?>
						</ul>
					</li>
				</ul>
			</div>
		</div>
		<div style="clear: both;">&nbsp;</div>
	</div>
</div>
<div id="footer">
	<p>
		&copy; <?php echo date("Y")."&nbsp;".$blogname ?> | Powered by <a href="http://git.io/O1jTLA">Mangolicious <?php echo $sysversion ?></a>
	</p>
</div>
</body>
</html>
<?php @mysql_close($db);

// PHP Style => Quick & Dirty!  ?>
