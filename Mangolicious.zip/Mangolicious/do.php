<?php
session_start();
if (@$_SESSION['admin'] == false)
	header("Location: index.php");
require_once 'config.php';
//----------------------------------------------------------

//------------------------ Beitrag erstellen ------------------------
@$posttitle = $_POST['posttitle'];
@$posttext = $_POST['posttext'];
if (isset($_POST["posted"])) {
	mysql_query("INSERT INTO mb_posts (id, posttitle, posttext, posttime, posttype) VALUES (NULL, '$posttitle', '$posttext', CURRENT_TIMESTAMP, '1');");
	echo '<script>alert(unescape(\'der Beitrag "'.$posttitle.'" wurde erfolgreich gepostet.\'))</script>';
}

//------------------------ Beitrag löschen ------------------------
if (isset($_POST["delete"])) {
	@$pid = $_POST['del_post'];
	mysql_query("DELETE FROM mb_posts WHERE id='$pid';");
	echo '<script>alert(unescape(\'der Beitrag mit der ID "'.$pid.'" wurde erfolgreich gel%F6scht.\'))</script>';
}

//------------------------ Beiträg ändern ------------------------
if (isset($_POST["edited"])) {


}

// Ändern: UPDATE accounts SET Tralala = 'Tralala' WHERE blabla = 'blabla'");
?>

<!DOCTYPE HTML>
<html lang="de-DE">
<head>
	<meta charset="UTF-8">
	<title>Mangolicious Engine is working...</title>
</head>
<style>body {font-family: sans-serif;}</style>
<body>
	<h3>Mangolicious Engine is working...</h3>
	<p>Sie werden in <span id="sec_time">3</span> Sekunden weitergeleitet, andernfalls klicken Sie <a href="cp.php">hier</a>.</p>

	<script>
		var sec = 3;
		var url = "cp.php";
		var SetInt = window.setInterval("umleitung()", 1000);

		function umleitung(){
			sec--;
			document.getElementById('sec_time').innerHTML=sec;
			if(sec==0){
				window.clearInterval(SetInt);
				window.location = url;
			}
		}
	</script>
</body>
</html>
