DROP TABLE IF EXISTS `mb_posts`;
CREATE TABLE IF NOT EXISTS `mb_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posttitle` varchar(255) NOT NULL,
  `posttext` text NOT NULL,
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `posttype` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

INSERT INTO `mb_posts` (`id`, `posttitle`, `posttext`, `posttime`, `posttype`) VALUES
(9, 'this blog is mangolicious!', '<p><strong>This is just mangolicious!</strong></p>\r\n\r\n<p>Lorem <em>ipsum</em> dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n\r\n<blockquote>\r\n<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n', '2012-12-26 22:45:49', 1),
(12, 'Ein neuer Tag!', '<p><em>Ein neuer tag beginnt<br />\r\nEs f&auml;ngt von vorne an<br />\r\nIch lass es hinter mir<br />\r\nLass los was ich nicht &auml;ndern kann<br />\r\nEin neuer tag beginnt<br />\r\nEin tag wie frischer schnee<br />\r\nIch hab noch nichts kaputt gemacht<br />\r\nIch geh...</em></p>\r\n', '2012-12-26 23:27:47', 1),
(13, 'Jacky', '<h4><span style="font-family:verdana,geneva,sans-serif;">Das ist Jacky!<img alt="" src="http://mangopix.de/gallery/_data/i/upload/2012/09/23/20120923231332-45f3a8ef-xl.jpg" style="width: 200px; height: 200px; border-width: 2px; border-style: solid; float: right; margin: 2px;" /></span></h4>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Jacky&#39;s voller Name ist <em>&quot;Jacky Alf&quot;</em></span></p>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Jacky ist ein 5,5 Monate alter Jack Russel Terrier.</span></p>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Links im Bild ist er etwa 4 Monate alt und seeehr m&uuml;de :)</span></p>\r\n\r\n<hr />', '2012-12-26 23:50:03', 1),
(15, 'Frohes Fest 2012', '<p style="text-align: center;">&nbsp;</p>\r\n\r\n<p style="text-align: center;"><span style="font-size:36px;"><span style="font-family: times new roman,times,serif;"><strong><span style="color:#FF0000;">Frohe</span> <span style="color:#008000;">Weihnachten</span></strong></span></span></p>\r\n\r\n<p style="text-align: center;"><span style="font-size:36px;"><span style="font-family: times new roman,times,serif;"><strong>! ! !</strong></span></span></p>\r\n\r\n<hr />\r\n<p>&lt;p style=&quot;text-align: center;&quot;&gt;&amp;nbsp;&lt;/p&gt;</p>\r\n\r\n<p>&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size:36px;&quot;&gt;&lt;span style=&quot;font-family: times new roman,times,serif;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color:#FF0000;&quot;&gt;Frohe&lt;/span&gt; &lt;span style=&quot;color:#008000;&quot;&gt;Weihnachten&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;</p>\r\n\r\n<p>&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size:36px;&quot;&gt;&lt;span style=&quot;font-family: times new roman,times,serif;&quot;&gt;&lt;strong&gt;! ! !&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2012-12-27 12:00:51', 1);

DROP TABLE IF EXISTS `mb_user`;
CREATE TABLE IF NOT EXISTS `mb_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `fullname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
