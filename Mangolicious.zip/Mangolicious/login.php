<?php
session_start();
require_once 'config.php';
$result = mysql_query("SELECT password FROM mb_user WHERE username = '".$_POST['username']."'");

if (($row = mysql_fetch_object($result)))
{
    if ($_POST['password'] == $row->password) {
        $_SESSION['admin'] = true;
        echo '
<!DOCTYPE HTML>
<html lang="de-DE">
<head>
	<meta charset="UTF-8">
</head>
<style>body {font-family: sans-serif;}</style>
<body>
	<h3>Erfolgreich eingeloggt</h3>
	<p>Sie werden in <span id="sec_time">3</span> Sekunden weitergeleitet, andernfalls klicken Sie <a href="index.php">hier</a>.</p>
<script>
	var sec = 3;
	var url = "index.php";
	var SetInt = window.setInterval("umleitung()", 1000);

	function umleitung(){
		sec--;
		document.getElementById(\'sec_time\').innerHTML=sec;
		if(sec==0){
			window.clearInterval(SetInt);
			window.location = url;
		}
	}
</script>
</body>
</html>';
    }
    
    else {
        $_SESSION['admin'] = false;
        echo '<script>alert(unescape(\'Einloggen war nicht erfolgreich\'))</script>';
    }
}

else{
    $_SESSION['admin'] = false;
    echo '<script>alert(unescape(\'Einloggen war nicht erfolgreich\'))</script>';
}
?>