-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 27. Dez 2012 um 21:06
-- Server Version: 5.5.28
-- PHP-Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `m_blog`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `mb_posts`
--

CREATE TABLE IF NOT EXISTS `mb_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `posttitle` varchar(255) NOT NULL,
  `posttext` text NOT NULL,
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `posttype` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Daten für Tabelle `mb_posts`
--

INSERT INTO `mb_posts` (`id`, `posttitle`, `posttext`, `posttime`, `posttype`) VALUES
(9, 'this blog is mangolicious!', '<p><strong>This is just mangolicious!</strong></p>\r\n\r\n<p>Lorem <em>ipsum</em> dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n\r\n<blockquote>\r\n<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n', '2012-12-26 22:45:49', 1),
(13, 'Jacky', '<h4><span style="font-family:verdana,geneva,sans-serif;">Das ist Jacky!<img alt="" src="http://mangopix.de/gallery/_data/i/upload/2012/09/23/20120923231332-45f3a8ef-xl.jpg" style="width: 200px; height: 200px; border-width: 2px; border-style: solid; float: right; margin: 2px;" /></span></h4>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Jacky&#39;s voller Name ist <em>&quot;Jacky Alf&quot;</em></span></p>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Jacky ist ein 5,5 Monate alter Jack Russel Terrier.</span></p>\r\n\r\n<p><span style="font-family:verdana,geneva,sans-serif;">Links im Bild ist er etwa 4 Monate alt und seeehr m&uuml;de :)</span></p>\r\n\r\n<hr />', '2012-12-26 23:50:03', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `mb_user`
--

CREATE TABLE IF NOT EXISTS `mb_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `fullname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `mb_user`
--

INSERT INTO `mb_user` (`id`, `username`, `password`, `email`, `fullname`) VALUES
(1, 'gabriel', 'server', 'gabriel8810@yahoo.de', 'Gabriel Wanzek');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
