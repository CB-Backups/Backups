<?php 
/*-| Blog Konfiguration |-------------------------------------*/

// Name ihres Blogs
$blogname = "Mangolicious";

// Kurze Beschreibung ihres Blogs bzw. Slogan
$blogdescription = "a easy blogging system";

// Mangolicious-Version
$sysversion = "(v0.2)";

// Der Name des Autors
$autorname = "Gabriel Wanzek";

// Die Anzahl der Beiträge die auf der Startseite angezeigt werden sollen (int-wert)
$showposts = 50;

// Etwas längere Beschreibung ihres Blogs
$blogdescriptionlong = 'Dieser Blog dient zu Entwicklungszwecken.<br>Mauris vitae nisl nec metus placerat perdiet est. Phasellus dapibus semper consectetuer hendrerit.';


/*-| optionale Features |-------------------------------------*/

// Alter des Autors
$autorage = "18";


/*-| MySQL-Datenbank Konfiguration |--------------------------*/

$host = "localhost"; // MySQL-Serveradresse (Standard: "localhost" -oder- "127.0.0.1")
$port = "3306";		 // MySQL-Serverport (Standard: "3306")
$user = "root";		 // MySQL-Server-User
$password = "123";	 // MySQL-Server-Passwort
$db = "m_blog";		 // MySQL-Datenbank

/*-----------------------------------------------------------------------*/

mysql_connect($host.":".$port, $user, $password) or die (mysql_error());
mysql_select_db($db);

?>

