<?php
session_start();
if (@$_SESSION['admin'] == false)
    header("Location: index.php");
unset($_SESSION['admin']);
session_destroy();
echo '
<!DOCTYPE HTML>
<html lang="de-DE">
<head>
	<meta charset="UTF-8">
</head>
<style>body {font-family: sans-serif;}</style>
<body>
	<h3>Erfolgreich ausgeloggt</h3>
	<p>Sie werden in <span id="sec_time">3</span> Sekunden weitergeleitet, andernfalls klicken Sie <a href="index.php">hier</a>.</p>
<script>
	var sec = 3;
	var url = "index.php";
	var SetInt = window.setInterval("umleitung()", 1000);

	function umleitung(){
		sec--;
		document.getElementById(\'sec_time\').innerHTML=sec;
		if(sec==0){
			window.clearInterval(SetInt);
			window.location = url;
		}
	}
</script>
</body>
</html>';
?>
