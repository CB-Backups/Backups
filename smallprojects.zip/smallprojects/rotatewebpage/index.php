<?php
if (isset($_POST['rot'])) {
    $content = file_get_contents($_POST['site']);
    $element = (isset($_POST['all'])) ? '*' : 'body' ;
    $magic = '
    <style>
        '.$element.' {-webkit-animation: rotateEverything 3s infinite linear;-o-animation: rotateEverything 3s infinite linear;animation: rotateEverything 3s infinite linear; }
        @-webkit-keyframes rotateEverything {0% { -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); -ms-transform: rotate(0deg); -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); -moz-transform: rotate(360deg); -ms-transform: rotate(360deg); -o-transform: rotate(360deg); transform: rotate(360deg); } }
        @-moz-keyframes rotateEverything {0% { -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); -ms-transform: rotate(0deg); -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); -moz-transform: rotate(360deg); -ms-transform: rotate(360deg); -o-transform: rotate(360deg); transform: rotate(360deg); } }
        @-ms-keyframes rotateEverything {0% { -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); -ms-transform: rotate(0deg); -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); -moz-transform: rotate(360deg); -ms-transform: rotate(360deg); -o-transform: rotate(360deg); transform: rotate(360deg); } }
        @-o-keyframes rotateEverything {0% { -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); -ms-transform: rotate(0deg); -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); -moz-transform: rotate(360deg); -ms-transform: rotate(360deg); -o-transform: rotate(360deg); transform: rotate(360deg); } }
        @keyframes rotateEverything {0% { -webkit-transform: rotate(0deg); -moz-transform: rotate(0deg); -ms-transform: rotate(0deg); -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); -moz-transform: rotate(360deg); -ms-transform: rotate(360deg); -o-transform: rotate(360deg); transform: rotate(360deg); } }
    </style></head>
    ';
    $show = str_replace('</head>', $magic, $content);
    echo $show;
} else {

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
    <title>rotate.me</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>rotate.me</h1>
        <p>
            <b>Info:</b> Works only with some websites - still in development!
        </p>
        <form action="index.php" method="post" class="form-inline">
            <div class="form-group">
                <input type="text" class="form-control" name="site" placeholder="Website URL...">
            </div>
            <input type="submit" name="rot" value="drehen!" class="btn btn-primary">
            <br><br>
            <label>
                <input name="all" type="checkbox"> Rotate all elements in page
            </label>
        </form>
    </div>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.js"></script>
</body>
</html>

<?php } ?>
