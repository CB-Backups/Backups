<?php
if (isset($_POST['send'])) 
	header('Location: http://php.net/'.$_POST['s']);
$arr = get_defined_functions();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>PHP.net - Suche</title>
	<style>
	@import url(https://raw.github.com/necolas/normalize.css/master/normalize.css);@import url(http://fonts.googleapis.com/css?family=PT+Sans);body{background:url(http://mangopix.de/local_images/bg.png) repeat #222;font-family:'PT Sans',sans-serif;text-align:center}h1{color:#fff;font-size:100px;margin:50px 0 0;padding:0;text-shadow:0 1px 0 #ccc,0 2px 0 #c9c9c9,0 3px 0 #bbb,0 4px 0 #b9b9b9,0 5px 0 #aaa,0 6px 1px rgba(0,0,0,.1),0 0 5px rgba(0,0,0,.1),0 1px 3px rgba(0,0,0,.3),0 3px 5px rgba(0,0,0,.2),0 5px 10px rgba(0,0,0,.25),0 10px 10px rgba(0,0,0,.2),0 20px 20px rgba(0,0,0,.15)}input[type=text]{width:300px;height:50px;border-radius:5px;box-shadow:inset 0 0 3px #222;border:0 transparent;font-size:28px;padding:3px 4px}input[type=submit]{margin-top:20px;width:150px;border-radius:5px;border:2px solid #222;height:50px;background:transparent;font-size:20px;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;-ms-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;transition:all .3s ease-in-out}input[type=submit]:hover{background:#fff}input[type=submit]:active{width:160px}
	</style>
</head>
<body>
	<h1>PHP.net</h1>
	<form action="<?=$_SERVER['SCRIPT_NAME']?>" method="post">
		<input type="text" name="s" placeholder="Suchbegriff" autofocus list="functions"><br>
		<datalist id="functions">
<?php
foreach ($arr['internal'] as $value) {
	echo "\t\t\t<option value=\"".$value."\"></option>\n";
}
?>
		</datalist>
		<input type="submit" name="send" value="Suchen">
	</form>
</body>
</html>