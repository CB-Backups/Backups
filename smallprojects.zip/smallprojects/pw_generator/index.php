<?php

/* Simple password generator with variable length 
 * by Gabriel Wanzek (https://github.com/GabrielWanzek)
 * 
 * Have fun. It's free!
 */

$pw_length = (isset($_POST['l'])) ? $pw_length = $_POST['l'] : $pw_length = 8 ;

function generatePassword($length) {
    $pw = "<span class=\"pw\">";
    $char = "qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM1234567890.-_=?!"; // all chars that are useful for a pw
    $char_c = strlen($char);
    for ($i = 0; $i < $length; $i++) { // get rand. char and add it to $pw
       $pw .= $char[rand(0, $char_c -1)];
    }   
    $pw .= "</span>\n";
    if ($length > 30) {         //handling for too short/long passwords
        unset($pw);
        $pw = "<span class=\"error\">This length is too long. (max. 30 characters)</span>";
    } elseif ($length < 6) {
        unset($pw);
        $pw = "<span class=\"error\">This length is too short. (min. 6 characters)</span>";
    }
    return $pw;
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Generate a Password!</title>
    <link rel="stylesheet" href="style.css">
</head>
    <body>
        <h1>Generate a Password!</h1>
        <div id="pw">
            <form action="index.php" method="post">
                <p>Length: <input type="text" name="l" value="<?=$pw_length?>" maxlength="2" required="required">
                <input type="submit" name="s" value="Generate!" onclick=""></p>
            </form>
            <?php echo generatePassword($pw_length)?>
        </div>
        <div id="footer">
            <span>
                "Generate a Password!" v1.1 by <a href="https://github.com/GabrielWanzek">Gabriel Wanzek</a> - 2013 - 
                Designed for <a onclick="alert('Browsers using webkit:\n\nGoogle Chrome, Safari, Konqueror and more... ')" href="#">webkit-browsers</a>
            </span>
        </div>
    </body>
</html>     
