<?php
$md5 = "";
$whirlpool = "";
$adler32 = "";
$sha256 = "";
$sha512 = "";
$gost = "";

if (isset($_POST['str'])) {
	$md5 = md5($_POST['str']);
	$sha1 = sha1($_POST['str']);
	$whirlpool = hash('whirlpool', $_POST['str']);
	$adler32 = hash('adler32', $_POST['str']);
	$sha256 = hash('sha256', $_POST['str']);
	$sha512 = hash('sha512', $_POST['str']);
	$gost = hash('gost', $_POST['str']);
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>HASHING</title>
	<style>
	body { padding:30px;font-family: sans-serif;}
label{width: 100px; display: inline; float:left;}
input[type=text]{width: 500px; padding: 3px 5px; border-radius: 0; border: 2px solid #222; margin-top: 1px;font-family: monospace;}
	</style>
</head>
<body>
	<form action="index.php" method="post" style="text-align:center;">
		<input type="text" name="str" id="text" placeholder="string"><br>
		<input type="submit" value="Hash it"><br>
		<br>
	</form>

<label>md5:</label><input type="text" value="<?=$md5?>" readonly><br><br>
<label>sha1:</label><input type="text" value="<?=$sha1?>" readonly><br><br>
<label>sha256:</label><input type="text" value="<?=$sha256?>" readonly><br><br>
<label>sha512:</label><input type="text" value="<?=$sha512?>" readonly><br><br>
<label>whirlpool:</label><input type="text" value="<?=$whirlpool?>" readonly><br><br>
<label>gost:</label><input type="text" value="<?=$gost?>" readonly><br><br>
</body>
</html>
