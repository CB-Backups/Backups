/*
 DO WHAT THE F*** YOU WANT TO PUBLIC LICENSE    
 
 Copyright (C) Gabriel Wanzek, 2013
 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.
 
 DO WHAT THE F*** YOU WANT TO PUBLIC LICENSE
 TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 
 0. You just DO WHAT THE F*** YOU WANT TO.
 */


/* init rotation of each image */
var rotatep1 = 0;
var rotatep2 = 0;
var rotatep3 = 0;
var rotatep4 = 0;
var rotatep5 = 0;
var rotatep6 = 0;
var rotatep7 = 0;
var rotatep8 = 0;
var rotatep9 = 0;

/* 
 * on click on img#p1 add css:transform rotataion 
 * on each "click" add 90deg 
 */

$('#p1').click(function() {
    rotatep1 += 90;
    $('#p1').css('transform', 'rotate(' + rotatep1 + 'deg)');
});

$('#p2').click(function() {
    rotatep2 += 90;
    $('#p2').css('transform', 'rotate(' + rotatep2 + 'deg)');
});

$('#p3').click(function() {
    rotatep3 += 90;
    $('#p3').css('transform', 'rotate(' + rotatep3 + 'deg)');
});

$('#p4').click(function() {
    rotatep4 += 90;
    $('#p4').css('transform', 'rotate(' + rotatep4 + 'deg)');
});

$('#p5').click(function() {
    rotatep5 += 90;
    $('#p5').css('transform', 'rotate(' + rotatep5 + 'deg)');
});

$('#p6').click(function() {
    rotatep6 += 90;
    $('#p6').css('transform', 'rotate(' + rotatep6 + 'deg)');
});

$('#p7').click(function() {
    rotatep7 += 90;
    $('#p7').css('transform', 'rotate(' + rotatep7 + 'deg)');
});

$('#p8').click(function() {
    rotatep8 += 90;
    $('#p8').css('transform', 'rotate(' + rotatep8 + 'deg)');
});

$('#p9').click(function() {
    rotatep9 += 90;
    $('#p9').css('transform', 'rotate(' + rotatep9 + 'deg)');
});

