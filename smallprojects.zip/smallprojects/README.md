# smallprojects
some smaller projects :smile:

### projects
* __pw_generator:__ a simple and css3-styled script/page for generating a safe password with variable length. 
* __cool-clock:__ a cool clock (html/php | one file) (inspired by qlocktwo)
* __hashing:__ hash a string to md5, sha1, sha256, sha512, whirlpool and gost
* __php.net-search__ a cool way to search php.net, with functions-"autocomplete" (html5 datalist)