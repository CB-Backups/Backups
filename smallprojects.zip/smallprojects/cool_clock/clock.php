<!DOCTYPE html>
<html><head>
	<meta charset="UTF-8">
	<title>Clock</title></head>
	<style>
	/*@font-face {font-family: 'Coolvetica';font-style: normal;font-weight: 400;src: url(coolvetica.woff) format('woff');}*/
	@import url(http://fonts.googleapis.com/css?family=Droid+Sans:700);
	html {font-family:'Droid Sans', sans-serif; background: #222; }
	table {border:none; margin: 0 auto; text-align: center; font-size: 46px; vertical-align: middle; width: 600px; height: 600px; margin-top: 25px;}
	td.x{color: #fff;}
	</style>
<body>
	<table border="0">
		<tbody><tr>
			<td class="x">E</td><td class="x">S</td>
			<td>K</td>
			<td class="x">I</td><td class="x">S</td><td class="x">T</td><td>A</td>
			<td>F</td><td>Ü</td><td>N</td><td>F</td>
		</tr>
		<tr>
			<td class="x">Z</td><td class="x">E</td><td class="x">H</td><td class="x">N</td>
			<td>Z</td><td>W</td><td>A</td><td>N</td><td>Z</td><td>I</td><td>G</td>
		</tr>
		<tr>
			<td>V</td><td>I</td><td>E</td><td>R</td><td>T</td><td>E</td><td>L</td>
			<td>X</td>
			<td class="x">V</td><td class="x">O</td><td class="x">R</td>
		</tr>
		<tr>
			<td>N</td><td>A</td><td>C</td><td>H</td>
			<td>A</td><td>J</td><td>U</td>
			<td>H</td><td>A</td><td>L</td><td>B</td>
		</tr>
		<tr>
			<td>E</td><td>I</td><td>N</td><td>S</td>
			<td>L</td><td>M</td><td>E</td>
			<td>Z</td><td>W</td><td>E</td><td>I</td>
		</tr>
		<tr>
			<td>D</td><td>R</td><td>E</td><td>I</td>
			<td>A</td><td>U</td><td>J</td>
			<td>V</td><td>I</td><td>E</td><td>R</td>
		</tr>
		<tr>
			<td>F</td><td>Ü</td><td>N</td><td>F</td>
			<td>T</td><td>O</td>
			<td>S</td><td>E</td><td>C</td><td>H</td><td>S</td>
		</tr>
		<tr>
			<td>S</td><td>I</td><td>E</td><td>B</td><td>E</td><td>N</td>
			<td>L</td>
			<td class="x">A</td><td class="x">C</td><td class="x">H</td><td class="x">T</td>
		</tr>
		<tr>
			<td>N</td><td>E</td><td>U</td><td>N</td>
			<td>Z</td><td>E</td><td>H</td><td>N</td>
			<td>E</td><td>L</td><td>F</td>
		</tr>
		<tr>
			<td>Z</td><td>W</td><td>Ö</td><td>L</td><td >F</td>
			<td>U</td><td>N</td><td>K</td>
			<td>U</td><td>H</td><td>R</td>
		</tr>
	</tbody></table>
</body></html>