<?php
const APPNAME = "Youtube Thumbnail Downloader v1";

$error = "";
$image = "";

if (isset($_GET['link'])) {
	$link = $_GET['link'];
	if ((!preg_match('/youtube\.com/', $link)) || (!preg_match('/watch/', $link))) {
		$error = "The URL is not a valid Youtube-URL";
	} else {
		$data_arr = explode("\n", file_get_contents($link));
		foreach ($data_arr as $line => $content) {
			if (preg_match("/og\:image/", $content)) {
				$arr = explode('"', $content);
				if (isset($arr[3])) {
					if (preg_match('/ytimg\.com/', $arr[3])) {
						$image = '<img src="'.$arr[3].'" title="Click to open in new tab/window">';
					} else {
						$error = "Can't find image.";
					}
				} else {
					$error = "Can't find image.";
				}
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=APPNAME?></title>
	<style>
		body{font-family:sans-serif;text-align:center;}
		img{max-width:75%;max-height:75%;box-shadow: 0 13px 13px -10px #000000;}
	</style>
</head>
<body>
	<h1><?=APPNAME?></h1>
	<p>
		<?=$error?>
	</p>
	<form action="<?=$_SERVER['SCRIPT_NAME']?>" method="get">
		<input type="text" name="link" id="link" placeholder="Youtube Video Link" required>
		<input type="submit" value="Get Thumbnail" class="medium awesome">
	</form>
	<div style="text-align:center; margin: 20px auto;">
		<?php 
		if (strlen($image) != 0)
			echo '<a href="'.$arr[3].'" target="_blank">'.$image.'</a><br><p>No useful image found? Try <a href="youtube.php">this version</a>';
		?>
	</div>
</body>
</html>
