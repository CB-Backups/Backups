<?php
const APPNAME = "Youtube Thumbnail Downloader v2";

$error = "";
$image = "";

if (isset($_GET['link'])) {
	$link = $_GET['link'];
	if ((!preg_match('/youtube\.com/', $link)) || (!preg_match('/watch/', $link))) {
		$error = "The URL is not a valid Youtube-URL";
	} else {
		$arr = explode("v=", $link);
		$image = '<img src="http://i1.ytimg.com/vi/'.$arr[1].'/maxresdefault.jpg" alt="">';
		$arr[3] = 'http://i1.ytimg.com/vi/'.$arr[1].'/maxresdefault.jpg';
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=APPNAME?></title>
	<style>
		body{font-family:sans-serif;text-align:center;}
		img{max-width:75%;max-height:75%;box-shadow: 0 13px 13px -10px #000000;}
	</style>
</head>
<body>
	<h1><?=APPNAME?></h1>
	<p>
		<?=$error?>
	</p>
	<form action="<?=$_SERVER['SCRIPT_NAME']?>" method="get">
		<input type="text" name="link" id="link" placeholder="Youtube Video Link" required>
		<input type="submit" value="Get Thumbnail" class="medium awesome">
	</form>
	<div style="text-align:center; margin: 20px auto;">
		<?php 
		if (strlen($image) != 0)
			echo '<a href="'.$arr[3].'" target="_blank">'.$image.'</a><br><p>No useful image found? Try <a href="youtube.php">this version</a>';
		?>
	</div>
</body>
</html>
