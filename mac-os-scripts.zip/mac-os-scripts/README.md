# my-macos-scripts
my scripts for my mac os x shell
