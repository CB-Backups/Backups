<?php
/**
* Skript für das Hochladen von Dateien.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-19
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Ordner angefordert?
		$reqPath = $this->mi()->getUserInput('path', NULL, true);
		// Medien-Instanz öffnen
		$mediaInstance = new \Content\Media($reqPath);

		try {
			// Dateien mitgesendet?
			$files = isset($_FILES['files']) ? [$_FILES['files']] : [];
			// Alle hochgeladenen Dateien durchlaufen
			foreach($files as $currentFile) {			
				// Eine Instanz draus machen
				$file = \Core\IO\i::File($currentFile['tmp_name']);
				
				// Element hinzufügen
				$mediaInstance->addElement($file, $currentFile['name']);
			}
			
			// Alles okay!
			echo 'done';
		} catch(\Exception $exception) { // Fehler beim Upload? Ausgeben!
			echo $exception->getMessage().' ('.$exception->getCode().')';
		}
	}
}
?>