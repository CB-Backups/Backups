<?= ^^^('messages') ?>

<div class="Warning Hidden" id="changeNameWarning">
	Um die geänderten Elementnamen zu speichern musst du noch auf den „Umbennen“-Button drücken.
</div>

<? if(???mediaInstance???): ?>
	<h4>Medienverwaltung</h4>
	<p>
		Hier sind alle Medienelemente aufgezählt, die hochgeladen wurden.
		Du kannst neue Elemente hochladen und bereits vorhandene Elemente umbenennen, verschieben oder löschen.
		Um ein Element-Link zu kopieren klicke auf das <img src="images/icons/link_go.png" alt="Link kopieren">-Icon.
		Dir wird zusätzlich dein verfügbarer Speicher angezeigt.
	</p>

	<div id="elementBox">
		<div id="dropzone">
			<span>Neue Elemente hier herziehen…</span>
			<progress max="100"></progress>
		</div>
	
		<div id="mediaSpace">
			<div class="Left">
				<ul>
					<li>
						<div class="OrangeBackground Square"></div>
						<span class="UsageSize"><?= Format::size(!!!mainMediaDir!!!->getSize()) ?></span>
						Bilder
					</li>
					<li>
						<div class="YellowBackground Square"></div>
						<span class="UsageSize"><?= Format::size(!!!cacheMediaDir!!!->getSize()) ?></span>
						Thumbnails
					</li>
					<li>
						<div class="GreyBackground Square"></div>
						<span class="UsageSize"><?= Format::size(!!!mainMediaDir!!!->getFreeSpace()) ?></span>
						Freier Speicher
					</li>
				</ul>
			</div>
			<div class="Right">
				<div id="spaceIndicator">
					<div class="UsedSpace OrangeBackground"
						style="width: <?= !!!mainMediaDir!!!->getPercentUsage(false) * 100 ?>%"></div><div class="UsedSpace YellowBackground"
						style="width: <?= !!!cacheMediaDir!!!->getPercentUsage(false) * 100 ?>%"></div>
						
					<div id="spaceBorder"></div>
				</div>
			</div>
			<div class="Clear"></div>
		</div>
		<div class="Clear"></div>
	</div>

	<form method="post" action="<?= >>>(NULL, ['path'=>!!!reqPath!!!]) ?>">
		<ul id="mediaList">
			<? if(!!!!mediaInstance!!!->isMainDir()): ?>
				<li onclick="location.href='<?= >>>(NULL, ['path'=>!!!mediaInstance!!!->getDirectoryInstance()->getParentDirectory()->getPath()]) ?>'">
					<img src="images/folder.png" alt="höher">
					..
				</li>
			<? endif; ?>
			<? $i = 0; ?>
			<? foreach(!!!mediaInstance!!! as $key => $currentMedia): ?>
				<? $i ++ ?>	
				<li>
					<input type="checkbox" name="elements[]" value="<?= $key ?>" id="elementKeyID<?= $i ?>">
					<? if($currentMedia->getType() != \Core\IO\Element::TYPE_DIR): ?>
						<a class="ClipboardLink" title="Link in die Zwischenablage kopieren…" href="javascript:copyToClipboard('<?= \Content\Media::getRelativPath($currentMedia) ?>')">
							<img src="images/icons/link_go.png" alt="Link kopieren">
						</a>
					<? endif; ?>
					<? if($currentMedia->getType() == \Core\IO\Element::TYPE_IMG): ?>
						<a class="Fancybox" href="<?= \Content\Media::getRelativPath($currentMedia) ?>"
							title="<?= Format::string($currentMedia->getName()) ?>">
					<? endif; ?>
					<img 
						<? if($currentMedia instanceof \Core\IO\Directory): ?>
							onclick="location.href='<?= >>>(NULL, ['path'=>$currentMedia->getPath()]) ?>'"
						<? endif; ?>
						<? if($currentMedia->getType() == \Core\IO\Element::TYPE_DIR): ?>
							src="images/folder.png" alt="Ordner">
						<? elseif($currentMedia->getType() == \Core\IO\Element::TYPE_IMG): ?>
							src="<?= >>>('Admin_Media_Thumb', ['file'=>$key]) ?>"
							alt="Vorschau" class="Preview"></a>
						<? elseif($currentMedia->getType() == \Core\IO\Element::TYPE_CSS): ?>
							src="images/files/css.png" alt="CSS-Datei">
						<? elseif($currentMedia->getType() == \Core\IO\Element::TYPE_PDF): ?>
							src="images/files/pdf.png" alt="PDF-Dokument">
						<? else: ?>
							src="images/files/unknown.png" alt="Unbekannter Dateitype">
						<? endif; ?>
					<span class="Hidden" id="elementKeyID<?= $i ?>InputSpan">
						<input type="text" name="elementNames[<?= $key ?>]" id="elementKeyID<?= $i ?>Input"
						value="<?= Format::string($currentMedia->getNameWithoutSuffix()) ?>"><?= Format::string($currentMedia->getSuffix(true)) ?>
					</span>
					<span onclick="showChangeInput(<?= $i ?>)"
						title="Zum Umbennen klicken" id="elementKeyID<?= $i ?>Span">
						<?= Format::string($currentMedia->getName(), false, false, 18) ?>
					</span>
				</li>
			<? endforeach; ?>
		</ul>
		<div class="Clear"></div>
	
		<p class="Center">
			<span class="Right">
				<input placeholder="Ordername" name="dirName">
				<input type="submit" name="create" value="Ordner erstellen">
			</span>
		
			<input type="submit" name="remove" value="Löschen"> &middot;
			<input type="submit" name="rename" value="Umbennen">

			<span class="Left">
				<select name="targetDir">
					<option value="">Hauptverzeichnis</option>
					<? foreach(!!!mediaDirs!!! as $currentDir): ?>
						<option value="<?= Format::string($currentDir) ?>"><?= Format::string($currentDir) ?></option>
					<? endforeach; ?>
				</select>
				<input type="submit" name="move" value="Verschieben">
			</span>
		</p>
		<div class="Clear"></div>
	</form>
<? endif; ?>