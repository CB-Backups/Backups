<?php
/**
* Skript für zum Darstellen von Thumbnails
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-20
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Welches Element ist angefordert
		$file = $this->mi()->getUserInput('file', NULL, true);
		// File-Instanz draus machen
		$fileInstance = \Core\IO\i::File($file);
		
		// Thumbnail darstelen
		\Content\Media::drawThumb($fileInstance);
	}
}
?>