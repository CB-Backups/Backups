<?php
/**
* Hauptskript für die Medienverwaltung.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-14
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Rechte des Benutzers prüfen
		if(!\Content\i::Config('rights')['media']->getCurrent() && !$this->si()->getUserInstance()->isDebugUser())
			\Core\Module::goToModule('Admin_Rights');
	}
}
?>