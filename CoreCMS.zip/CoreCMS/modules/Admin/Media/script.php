<?php
/**
* Skript für die Medien-Übersicht.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-08
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $mediaInstance;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Medienverwaltung');
		
		// Header-Template setzen
		$this->mi()->addVarCache('headerTemplate', 'mediaHeader');
		// Maximale Upload-Größe für Dateien setzen
		$this->mi()->addVarCache('maxFileSize', \Core\System::uploadLimit()/1024/1024);	
		// Maximale Upload-Größe unverändert
		$this->mi()->addVarCache('maxFileSizeRaw', \Core\System::uploadLimit());
		
		// Ordner angefordert?
		$reqPath = $this->mi()->getUserInput('path', NULL, true);
		
		try {
			// Medien-Instanz öffnen
			$this->mediaInstance = new \Content\Media($reqPath);
			// Versteckte Dateien nicht anzeigen
			$this->mediaInstance->getDirectoryInstance()->setShowHidden(false);
			
			// Medien-Instanz im Modul speichern
			$this->mi()->addVarCache('mediaInstance', $this->mediaInstance);
			// Path im Modul speichern
			$this->mi()->addVarCache('reqPath', $this->mediaInstance->getDirectory());
			
			// Hauptordner speichern
			$this->mi()->addVarCache('mainMediaDir', \Content\Media::mainDirectory());
			// Cache-Ordener speichern
			$this->mi()->addVarCache('cacheMediaDir', \Content\Media::cacheDirectory());
		
			try {
				if(isset($_POST['remove'])) {
					// Elemente durchlaufen und löschen
					foreach($this->getElements() as $currentElement) \Content\Media::removeElement($currentElement);
				} else if(isset($_POST['move'])) {
					// Wo hin?
					$targetDir = $this->mi()->getUserInput('targetDir');
			
					// Elemente durchlaufen und löschen
					foreach($this->getElements() as $currentElement) \Content\Media::moveElement($currentElement, $targetDir);
				} else if(isset($_POST['create'])) {
					// Name des Ordners
					$directoryName = $this->mi()->getUserInput('dirName');
					// Ordner erstellen
					$this->mediaInstance->getDirectoryInstance()->addDirectory($directoryName);
				} else if(isset($_POST['rename'])) {
					foreach($this->getElements() as $key => $currentElement) {
						// Neuer Name des Elements?
						$newName = isset($_POST['elementNames'][$key]) ? $_POST['elementNames'][$key] : NULL;
					
						// Name ändern
						\Content\Media::renameElement($currentElement, $newName);
					}
				}
			} catch(\HumanException $exception) {
				$this->mi()->addVarCache('showError', true);
				$this->mi()->addVarCache('errorString', $exception->getMessage());
			} catch(\Exception $exception) {
				$this->mi()->addVarCache('showError', true);
				$this->mi()->addVarCache('errorString', 'Interner Fehler: '.$exception->getMessage().' ('.$exception->getCode().')');
			}
		
			// Media-Dirs hinzufügen
			$this->mi()->addVarCache('mediaDirs', \Content\Media::getMediaDirs());
		} catch(\Exception $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', 'Fehler beim Öffnen dieses Ordners: '.$exception->getMessage().' ('.$exception->getCode().')');
		}
	}
	
	/**
	* Gibt die ausgewählten Elemente zurück.
	*
	* @return array[Element] - Die Elemente
	**/
	private function getElements() {
		// Ausgewählte Elemente bekommen
		$elements = $this->mi()->getUserInput('elements', []);
		// Muss ein Array sein!
		if(!is_array($elements)) $elements = [];
		
		// Rückgabearray erstellen
		$returnArray = [];
		foreach($elements as $currentElement) {
			// Element laden
			try {
				$currentElementInstance = \Core\IO\Element::toElement($currentElement);
			
				// Element dem Array hinzufügen
				$returnArray[$currentElement] = $currentElementInstance;
			} catch(\Exception $e) {
				throw new \HumanException('Unbekannte Datei ausgewählt.', -1, $e);
			}
		}
		
		return $returnArray;
	}
}
?>