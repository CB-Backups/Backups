<?php
/**
* Skript für die Seiten-Verwaltung
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-05
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $manager;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Seitenverwaltung');
		
		// Manager dem Modul hinzufügen
		$this->manager = \Content\Site\i::Manager();
		$this->mi()->addVarCache('siteManager', $this->manager);
		
		// Alle Seiten laden
		$this->manager->loadAll();
		
		try {
			// Neue Seite erstellen
			if(isset($options['newSite']) && $options['newSite'])
				$this->addNewSite($this->mi()->getUserInput('sitename'));
			
			// Aufgabe durchführen
			if(isset($options['id']) && isset($options['option'])) {
				// Seite laden
				$siteID = $options['id'];
				$siteObject = $this->getSiteForID($siteID);
				
				switch($options['option']) {
					// Seite löschen?
					case 'remove':
						$this->manager->removeObject($siteID);
						break;
						
					// Seite verstecken?
					case 'hide':
						$siteObject->hide();
						break;
					// Seite anzeigen
					case 'unhide':
						$siteObject->unhide();
						break;
						
					// Seite bearbeiten
					case 'edit':
						\Core\Module::goToModule('Admin_Sites_Edit', ['siteID'=>$siteID]);
					
					// Sortierung hoch
					case 'sortUp':
						$this->manager->sortUpObject($siteID);
						break;
					// Sortierung runter
					case 'sortDown':
						$this->manager->sortDownObject($siteID);
						break;
					
					// Seite im CMS anzeigen
					case 'show':
						\Core\Module::goToModule(NULL, ['siteID'=>$siteID]);
						
					default:
						throw new \HumanException('Es wurde eine ungültige Option ausgewählt.', -1);
				}
			}
			
			// Startseite festlegen
			if(isset($options['changeHome']) && $options['changeHome'])
				$this->manager->setHome($this->mi()->getUserInput('homeID', -1));
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
	}
	
	/**
	* Gibt die zur ID passende Seite zurück.
	*
	* @param int $id
	* @param \Content\Site
	**/
	private function getSiteForID($id) {
		if(!isset($this->manager[$id]))
			throw new \HumanException('Die ausgewählte Seite existiert nicht (mehr). Versuche es erneut.', -1);
			
		return $this->manager[$id];
	}
	
	/**
	* Erstellt eine neue Seite.
	*
	* @param string $sitename - Der Seitenname
	**/
	private function addNewSite($sitename) {
		// Neue Seite erstellen
		$site = new \Content\Site($sitename);
		// Die erste Seite? Dann ist das automatisch die Startseite
		if(!count($this->manager)) $site->setHome(true);
		
		// Dem Manager hinzufügen
		$this->manager->addObject($site);
	}
}
?>