<?= ^^^('messages') ?>

<h4>Seiteninhalt bearbeiten</h4>
<p>
	Hier sind einige Informationen zu dieser Seite und alle Beiträge aufgelistet.
	Füge neue hinzu, bearbeite oder lösche alte Beiträge.
</p>

<form method="post" action="<?= >>>(NULL, ['siteID'=>!!!siteID!!!,'changeSite'=>true]) ?>">
	<table class="TableOverview TableSmall">
		<tr>
			<th colspan="2">Seiteninformationen</th>
		</tr>
		<tr>
			<td>Seitenname</td>
			<td><input type="text" name="sitename" value="<?= Format::string(!!!siteObject!!!->getName()) ?>"</td>
		</tr>
		<tr>
			<td>Letze Änderung</td>
			<td><?= Format::date(!!!siteObject!!!->getLastChange(), false, false) ?></td>
		</tr>
	</table>
	
	<p>
		<a href="<?= >>>('Admin_Sites_Edit', ['siteID'=>!!!siteID!!!,'newPost'=>true]) ?>">
			&raquo; Neuen Beitrag hinzufügen
		</a>
	</p>
	
	<table class="TableOverview">
		<tr>
			<th class="ColBig">Titel</th>
			<th>Inhalt</th>
			<th class="ColMiddleBig">Erstellt</th>
			<th class="ColMiddleBig">Änderung</th>
			<th class="ColSmall"><img src="images/icons/eye_hidden.png" alt="Versteckt" title="Verstecken?"></th>
			<th class="ColSmall"><img src="images/icons/delete.png" alt="Löschen" title="Löschen?"></th>
			<th class="ColSmall"><img src="images/icons/cog.png" alt="Optionen" title="Optionen"></th>
		</tr>
		<? if(!count(!!!siteObject!!!)): ?>
			<tr>
	    		<td colspan="7" class="Center">Keine Beiträge auf dieser Seite vorhanden…</td>
	    	</tr>
		<? else: ?>
			<? foreach(!!!siteObject!!! as $id => $currentPost): ?>
				<tr>
					<td class="Top"><?= Format::string($currentPost->getTitle()) ?></td>
					<td class="Top"><?= strip_tags($currentPost->getText(),'<br><p>') ?></td>
					<td class="Center Top"><?= Format::date($currentPost->getPostTime(),false,false) ?></td>
					<td class="Center Top"><?= Format::date($currentPost->getLastChange(),false,false) ?></td>
					<td class="Center Top"><input type="checkbox" name="hide[]" value="<?= $id ?>" <? if($currentPost->isHidden()): ?> checked="checked"<? endif; ?>></td>
					<td class="Center Top"><input type="checkbox" name="delete[]" value="<?= $id ?>"></td>
					<td class="Center Top">
						<a href="<?= >>>('Admin_Sites_Edit_Post', ['siteID'=>!!!siteID!!!, 'postID'=>$id]) ?>" title="Beitrag bearbeiten" class="NoBorder"><img src="images/icons/pencil.png" alt="bearbeiten"></a>
					</td>
				</tr>
			<? endforeach; ?>
		<? endif; ?>
	</table>
	
	<span class="Right">
		<input type="submit" value="Änderungen speichern">
		<input type="submit" value="Änderungen speichern & Zurück" name="saveAndBack">
	</span>
</form>

<button onClick="window.location.href='<?= >>>('Admin_Sites') ?>'" class="Left">&laquo; Zurück</button>
<div class="Clear"></div>