<?php
/**
* Skript für das Bearbeiten des Seiteninhalts.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-11
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $siteObject;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Seiteninhalt bearbeiten');
		
		// Manager öffnen
		$manager = \Content\Site\i::Manager();
		// Seiten laden
		$manager->loadAll();
		
		// Seiten-ID laden
		$siteID = isset($options['siteID']) ? $options['siteID'] : -1;
		// Seiten-ID im Modul speichern
		$this->mi()->addVarCache('siteID', $siteID);
		// Existiert die Seite nicht? Weiterleiten
		if(!isset($manager[$siteID])) \Core\Module::goToModule('Admin_Sites');
		
		// Seite im Modul speichern
		$this->siteObject = $manager[$siteID];
		$this->mi()->addVarCache('siteObject', $this->siteObject);
		
		// Änderung angefordert?
		if(isset($options['changeSite']) && $options['changeSite']) {
			// Seite ändern
			$this->changeSite();
			// Wieder zurück?
			if(isset($_POST['saveAndBack'])) \Core\Module::goToModule('Admin_Sites');
		}
		
		// Neuer Beitrag?
		if(isset($options['newPost']) && $options['newPost'])
			$this->newPost();
	}
	
	/**
	* Den Inhalt der Seite nach User-Eingaben anpassen.
	**/
	private function changeSite() {
		// Den neuen Seitenname setzen
		$this->siteObject->setName($this->mi()->getUserInput('sitename'));
		
		// Welche Beiträge sollen gelöscht werden?
		$postArray = $this->mi()->getUserInput('delete', [], false, 'is_array');
		// Alle ausgewählten Beiträge durchlaufen und löschen
		foreach($postArray as $currentPost) $this->siteObject->removePost($currentPost);
		
		// Welche Beiträge sollen versteckt sein? 
		$postArray = $this->mi()->getUserInput('hide', [], false, 'is_array');
		// Alle Beträge durchlaufen
		foreach($this->siteObject as $id => $currentPost) {
			// Soll dieser Beitrag versteckt werden?
			if(in_array($id, $postArray)) $currentPost->hide();
			else $currentPost->unhide();
		}
		
		// Letze Änderung aktuallisieren
		$this->siteObject->setLastChange();
	}
	
	/**
	* Erstellt einen neuen Beitrag.
	**/
	private function newPost() {
		// Neuen Beitrag erstellen
		$newPost = new \Content\Site\Post();
		// Post der Seite hinzufügen
		$this->siteObject->addPost($newPost);
		
		// Alle Posts der Seite
		$posts = $this->siteObject->toArray();
		// ID des neuen Posts ermitteln
		$postID = array_keys($posts)[count($posts)-1];
		
		// Seiten-ID?
		$siteID = $this->mi()->getVarCache('siteID');
		// Weiterleiten
		\Core\Module::goToModule('Admin_Sites_Edit_Post', ['siteID'=>$siteID, 'postID'=>$postID, 'newPost'=>true]);
	}
}
?>