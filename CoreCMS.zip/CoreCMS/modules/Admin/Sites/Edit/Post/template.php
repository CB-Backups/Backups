<?= ^^^('messages') ?>

<h4>Beitrag bearbeiten</h4>
<p>
	Bearbeiten eines Beitrags der Seite „<strong><?= Format::string(!!!siteObject!!!->getName()) ?></strong>“.
	Um ein Bild aus der Medienverwaltung hier einzufügen, kopieren den Link dort und klicke hier auf „Bild“ im Editor.
</p>

<form method="post" action="<?= >>>(NULL, ['siteID'=>!!!siteID!!!,'postID'=>!!!postID!!!, 'editPost'=>true]) ?>">
	<div class="LabelForm" style="margin-bottom: 10px;">
		<label for="title">Titel:</label>
		<input type="text" name="title" id="title" value="<?= Format::string(!!!postObject!!!->getTitle()) ?>">
		
		<div class="Clear"></div>
	</div>
	
	<textarea id="postEditor" name="text"><?= Format::string(!!!postObject!!!->getText()) ?></textarea>
	
	<p></p>
	<span class="Right">
		<input type="submit" value="Änderungen speichern">
		<input type="submit" value="Änderungen speichern & Zurück" name="saveAndBack">
	</span>
</form>

<button onClick="window.location.href='<?= >>>('Admin_Sites_Edit', ['siteID'=>!!!siteID!!!]) ?>'" class="Left">&laquo; Zurück</button>
<div class="Clear"></div>