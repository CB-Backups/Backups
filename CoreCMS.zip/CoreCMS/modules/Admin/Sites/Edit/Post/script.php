<?php
/**
* Skript für das Bearbeiten eines Posts
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-12
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $siteObject, $postObject;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Seiteninhalt bearbeiten');
		
		// Header-Template setzen
		$this->mi()->addVarCache('headerTemplate', 'postHeader');
		
		// Manager öffnen
		$manager = \Content\Site\i::Manager();
		// Seiten laden
		$manager->loadAll();
		
		// Seiten-ID laden
		$siteID = isset($options['siteID']) ? $options['siteID'] : -1;
		// Seiten-ID im Modul speichern
		$this->mi()->addVarCache('siteID', $siteID);
		// Existiert die Seite nicht? Weiterleiten
		if(!isset($manager[$siteID])) \Core\Module::goToModule('Admin_Sites');
		
		// Seite im Modul speichern
		$this->siteObject = $manager[$siteID];
		$this->mi()->addVarCache('siteObject', $this->siteObject);
		
		// Seiten-ID laden
		$postID = isset($options['postID']) ? $options['postID'] : -1;
		// Seiten-ID im Modul speichern
		$this->mi()->addVarCache('postID', $postID);
		if(!isset($this->siteObject[$postID])) \Core\Module::goToModule('Admin_Sites_Edit', ['siteID'=>$siteID]);
		
		// Post im Modul speichern
		$this->postObject = $this->siteObject[$postID];
		$this->mi()->addVarCache('postObject', $this->postObject);
		
		// Beitrag bearbeiten?
		if(isset($options['editPost']) && $options['editPost']) {
			$this->editPost();
			// Wieder zurück?
			if(isset($_POST['saveAndBack'])) \Core\Module::goToModule('Admin_Sites_Edit',['siteID'=>$siteID]);
		}
	}
	
	/**
	* Bearbeitet einen Post.
	**/
	private function editPost() {
		// Den neuen Beitragtitel setzen
		$this->postObject->setTitle($this->mi()->getUserInput('title'));
		// Den neuen Text setzen
		$this->postObject->setText($this->mi()->getUserInput('text'));
		
		// Änderungsdatum setzen
		$this->postObject->setLastChange();
		$this->siteObject->setLastChange();
	}
}
?>