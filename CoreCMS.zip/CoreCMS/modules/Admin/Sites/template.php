<?= ^^^('messages') ?>

<h4>Seitenliste</h4>
<p>
    Hier findest du eine Liste aller Seiten die in diesem CMS vorhanden sind.
    Klicke auf den Namen einer Seite um den Inhalt dieser Seite anzupassen.
    Wenn eine CMS-Seite versteckt ist, kann diese nur über den Direktlink aufgerufen werden.
</p>

<form method="post" action="<?= >>>(NULL, ['changeHome'=>true]) ?>">
	<table class="TableOverview">
	    <tr>
	    	<th class="ColSmall">
	    		<img src="images/icons/house.png" alt="Haus" title="Welche Seite ist als Startseite definiert?">
	    	</th>
	    	<th>Seitenname</th>
	    	<th class="ColBig">Aktualisierung</th>
	    	<th class="ColMiddle">Beiträge</th>
	    	<th class="ColMiddle">Aufrufe</th>
	    	<th class="ColMiddle">Sortierung</th>
	    	<th class="ColMiddle">Optionen</th>
	    </tr>
	    <? if(!count(!!!siteManager!!!)): ?>
	    	<tr>
	    		<td colspan="7" class="Center">Keine Seiten gefunden…</td>
	    	</tr>
	    <? else: ?>
	    	<? $i = 0 ?>
	    	<? foreach(!!!siteManager!!! as $id => $currentSite): ?>
	    		<? $i ++ ?>
	    		<tr>
	    			<td class="Center">
	    				<input type="radio" name="homeID" value="<?= $id ?>" onChange="this.form.submit()" <? if($currentSite->isHome()): ?> checked="checked"<? endif; ?>>
	    			</td>
	    			<td>
	    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'show']) ?>" title="Im CMS anzeigen">
		    				<img src="images/icons/world_link.png" alt="Anzeigen">
		    				<?= Format::string($currentSite->getName()) ?>
		    			</a>
	    			</td>
	    			<td class="Center"><?= Format::date($currentSite->getLastChange(), false, false) ?></td>
	    			<td class="Center"><?= Format::number(count($currentSite)) ?></td>
	    			<td class="Center"><?= Format::number($currentSite->getHits()) ?></td>
	    			<td class="Center">
	    				<? if($i < count(!!!siteManager!!!)): ?>
		    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'sortDown']) ?>" title="weiter runter" class="NoBorder">
		    					<img src="images/icons/arrow_down.png" alt="Pfeil nach unten">
		    				</a>
		    			<? endif; ?>
		    			<? if($i > 1): ?>
		    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'sortUp']) ?>" title="weiter hoch" class="NoBorder">
		    					<img src="images/icons/arrow_up.png" alt="Pfeil nach oben">
		    				</a>
		    			<? endif; ?>
		    			<? if(count(!!!siteManager!!!) == 1): ?>
		    				-
		    			<? endif; ?>
	    			</td>
	    			<td class="Center">
	    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'edit']) ?>" title="Den Seitenamen bearbeiten" class="NoBorder">
		    				<img src="images/icons/pencil.png" alt="Bearbeiten">
		    			</a>
		    			<? if($currentSite->isHidden()): ?>
		    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'unhide']) ?>" title="Diese Seite anzeigen" class="NoBorder">
		    					<img src="images/icons/eye.png" alt="Anzeigen">
		    				</a>
		    			<? else: ?>
		    				<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'hide']) ?>" title="Diese Seite verstecken" class="NoBorder">
		    					<img src="images/icons/eye_hidden.png" alt="Verstecken">
		    				</a>
		    			<? endif ?>
		    			<a href="<?= >>>(NULL, ['id'=>$id,'option'=>'remove']) ?>" title="Diese Seite löschen" class="NoBorder">
		    				<img src="images/icons/delete.png" alt="Löschen">
		    			</a>
	    			</td>
	    		</tr>
	    	<? endforeach; ?>
	    <? endif; ?>
	</table>
</form>

<p>
	<form method="post" action="<?= >>>(NULL, ['newSite'=>true]) ?>" class="Right">
		<label for="sitename">Neue Seite:</label>
		<input type="text" id="sitename" name="sitename" placeholder="Seitenname" size="25">
		<input type="submit" value="Erstellen">
	</form>
</p>