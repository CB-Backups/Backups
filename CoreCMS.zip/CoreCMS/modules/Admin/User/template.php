<div id="contentRight">
	<?= ^^^('messages') ?>

	<h4>Benutzerliste</h4>
	<p>
		Hier hast du einen Überblick über alle Benutzer, die sich an dieser Installation von CoreCMS einloggen können.
		Neue Benutzer lassen sich über das Menü in der Seitennavigation hinzufügen.
	</p>
	<table class="TableOverview">
		<tr>
			<th class="ColSmall">ID</th>
			<th class="ColBig">Name</th>
			<th>E-Mail</th>
			<th>Letzter Login</th>
			<th class="ColMiddle">Optionen</th>
		</tr>
		<? if(!count(!!!userList!!!)): ?>
			<tr>
				<td colspan="5" class="Center">Keine Benutzer gefunden…</td>
			</tr>
		<? else: ?>
			<? foreach(!!!userList!!! as $userID => $currentUser): ?>
				<tr>
					<td class="Center"><?= Format::number($userID) ?></td>
					<td>
						<?= Format::string($currentUser->getUserName()) ?>
						<? if($currentUser->isDebugUser()): ?>
							<img src="images/icons/user_suit.png" alt="Anzugmensch" title="Dieser Benutzer ist der Hauptbenutzer.">
						<? endif; ?>
					</td>
					<td><?= Format::string($currentUser->getUserMail()) ?></td>
					<td class="Center"><?= Format::date($currentUser->getLastLogin(), false, false) ?></td>
					<td class="Center">
						<a href="<?= >>>('Admin_User_Edit', ['userID'=>$userID]) ?>" class="NoBorder">
							<img src="images/icons/pencil.png" alt="bearbeiten" title="Den User bearbeiten">
						</a>
						<? if($currentUser->isLocked()): ?>
							<a href="<?= >>>(NULL, ['option'=>'unlock', 'userID'=>$userID]) ?>" class="NoBorder">
								<img src="images/icons/lock_break.png" alt="entsperren" title="Den User entsperren">
							</a>
						<? else: ?>
							<a href="<?= >>>(NULL, ['option'=>'lock', 'userID'=>$userID]) ?>" class="NoBorder">
								<img src="images/icons/lock.png" alt="sperren" title="Den User sperren">
							</a>
						<? endif; ?>
						<a href="<?= >>>(NULL, ['option'=>'delete', 'userID'=>$userID]) ?>" class="NoBorder">
							<img src="images/icons/delete.png" alt="löschen" title="Den User löschen">
						</a>
					</td>
				</tr>
			<? endforeach; ?>
		<? endif; ?>
	</table>
</div>