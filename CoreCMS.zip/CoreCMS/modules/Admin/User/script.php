<?php
/**
* Skript für die Benutzerverwaltung. (Auflistung aller Benutzer.)
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-09
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Benutzerverwaltung');
		
		// Neuer Benutzer angelegt?
		if(isset($options['addUser']) && $options['addUser']) {
			$this->mi()->addVarCache('showSuccess', true);
			$this->mi()->addVarCache('successString', 'Der neue Benutzer wurde erfolgreich erstellt. Er kann sich ab sofort einloggen.');
		} else if(isset($options['editUser']) && $options['editUser']) {
			$this->mi()->addVarCache('showSuccess', true);
			$this->mi()->addVarCache('successString', 'Der Benutzer wurde erfolgreich bearbeitet.');
		}
		
		try {
			// User-Daten laden
			$userID = $this->mi()->getUserInput('userID', -1, true);
			$userOption = $this->mi()->getUserInput('option', false, true);
			
			// Option senden
			if($userOption)
				$this->makeUserOption($userID, $userOption);
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
		
		// Benutzerliste laden
		$this->mi()->addVarCache('userList', \Core\User::listAllUser());
	}
	
	/**
	* Führt User-Optionen durch.
	*
	* @param int $userID - Die ID des Benutzers
	* @param string $option - Die Option die durchgeführt werden soll.
	**/
	private function makeUserOption($userID, $option) {
		try {
			// User-Objekt laden
			$userObject = \Core\i::User($userID);
		} catch(\Exception $exception) {
			// Benutzer nicht gefunden?
			throw new \HumanException('Unbekannter Benutzer ausgewählt, versuche es erneut.', -1, $exception);
		}
		
		switch($option) {
			// User entsperren
			case 'unlock':
				$userObject->unlock();
				break;
			// User sperren
			case 'lock':
				$userObject->lock();
				break;
				
			// User löschen
			case 'delete':
				$userObject->delete();
				
				// Erfolgsmeldung
				$this->mi()->addVarCache('showSuccess', true);
				$this->mi()->addVarCache('successString', 'Der ausgewählte Benutzer wurde erfolgreich gelöscht.');
				break;
				
				
			// Unbekannte Option
			default:
				throw new \HumanException('Unbekannte User-Option ausgewählt. Aufgabe konnte nicht ausgeführt werden', -2);
		}
	}
}
?>