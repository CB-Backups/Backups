<div id="contentRight">
	<?= ^^^('messages') ?>
	
	<h4>Neuer Benutzer erstellen</h4>
	<p>
		Hier kannst du einen neuen Benutzer erstellen, der auf den Adminbereich des CMS Zugriff hat.
		Bitte trage alle erforderlichen Informationen ein.
	</p>
	
	<form method="post" action="<?= >>>(NULL, ['action'=>true]) ?>" class="LabelForm">
		<label for="userName">Loginname:</label> <input type="text" name="userName" id="userName" value="<?= Format::string(!!!userName!!!) ?>">
		<label for="userMail">E-Mail-Adresse:</label> <input type="mail" name="userMail" id="userMail" value="<?= Format::string(!!!userMail!!!) ?>">
		<label for="userPass">Passwort:</label> <input type="password" name="userPass" id="userPass" value="<?= Format::string(!!!userPass!!!) ?>">
		<label for="userPassAgain">Wiederholen:</label> <input type="password" name="userPassAgain" id="userPassAgain" value="<?= Format::string(!!!userPassAgain!!!) ?>">
		
		<input type="submit" value="Benutzer erstellen">
	</form>
</div>