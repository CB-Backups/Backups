<?php
/**
* Skript für das Erstellen eines Benutzers.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Neuer Benutzer');
		
		// User-Eingaben laden
		foreach(['Name', 'Mail', 'Pass', 'PassAgain'] as $current)
			$this->mi()->addVarCache('user'.$current, $this->mi()->getUserInput('user'.$current));
		
		// Benutzer hinzufügen
		try {
			if (isset($options['action']) && $options['action'] == true)
				$this->addUser();
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
	}
	
	/**
	 * Führt eine Registrierung durch und lädt die dafür benötigten Ressurcen
	 **/
	protected function addUser() {	
		// Neuen Nutzer in die Datenbank schreiben
		\Core\User::createNewUser(
			$this->mi()->getVarCache('userName'),
			$this->mi()->getVarCache('userPass'),
			$this->mi()->getVarCache('userPassAgain'),
			$this->mi()->getVarCache('userMail'));
		
		// Weiterleitung auf Startseite
		\Core\Module::goToModule('Admin_User',['addUser'=>true]);
	}
}
?>