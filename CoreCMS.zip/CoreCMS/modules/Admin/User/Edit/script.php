<?php
/**
* Skript für das Bearbeiten eines Benutzers.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-12
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $userObject;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Benutzer bearbeiten');
		
		// User-ID
		$userID = isset($options['userID']) ? $options['userID'] : -1;
		$this->mi()->addVarCache('userID', $userID);
		
		try {
			// User-Objekt laden
			$this->userObject = \Core\i::User($userID);
		} catch(\Exception $exception) {
			// Benutzer nicht gefunden? Zurückleiten!
			\Core\Module::goToModule('Admin_User');
		}
		
		// User-Eingaben laden (Standard-Wert aus DB)
		foreach(['Name', 'Mail'] as $current)
			$this->mi()->addVarCache('user'.$current, $this->mi()->getUserInput('user'.$current, call_user_func([$this->userObject, 'getUser'.$current])));
		// User-Eingaben laden (Kein Standard-Wert.)
		foreach(['Pass', 'PassAgain'] as $current)
			$this->mi()->addVarCache('user'.$current, $this->mi()->getUserInput('user'.$current));
			
		// Benutzer bearbeiten
		try {
			if (isset($options['action']) && $options['action'] == true)
				$this->editUser();
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
	}
	
	/**
	* Bearbeitet den Benutzer
	**/
	private function editUser() {
		// User-Name setzen
		if($this->mi()->getVarCache('userName') != $this->userObject->getUserName())
			$this->userObject->setUserName($this->mi()->getVarCache('userName'));
		// User-Mail setzen
		if($this->mi()->getVarCache('userMail') != $this->userObject->getUserMail())
			$this->userObject->setUserMail($this->mi()->getVarCache('userMail'));
		// User-Passwort setzen, falls verlangt.
		if(strlen($this->mi()->getVarCache('userPass')))
			$this->userObject->setUserPass($this->mi()->getVarCache('userPass'),$this->mi()->getVarCache('userPassAgain'));
			
		// Weiterleitung
		\Core\Module::goToModule('Admin_User',['editUser'=>true]);
			
	}
}