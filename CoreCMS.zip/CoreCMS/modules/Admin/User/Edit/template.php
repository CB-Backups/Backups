<div id="contentRight">
	<?= ^^^('messages') ?>
	
	<h4>Benutzer bearbeiten</h4>
	<p>
		Hier kannst du den Benutzer <strong><?= Format::string(!!!userName!!!) ?></strong> bearbeiten.
		Trage ein neues Passwort nur ein, falls du es ändern möchtest.
	</p>
	
	<form method="post" action="<?= >>>(NULL, ['userID'=>!!!userID!!!,'action'=>true]) ?>" class="LabelForm">
		<label for="userName">Loginname:</label> <input type="text" name="userName" id="userName" value="<?= Format::string(!!!userName!!!) ?>">
		<label for="userMail">E-Mail-Adresse:</label> <input type="mail" name="userMail" id="userMail" value="<?= Format::string(!!!userMail!!!) ?>">
		<label for="userPass">Passwort:</label> <input type="password" name="userPass" id="userPass" value="<?= Format::string(!!!userPass!!!) ?>">
		<label for="userPassAgain">Wiederholen:</label> <input type="password" name="userPassAgain" id="userPassAgain" value="<?= Format::string(!!!userPassAgain!!!) ?>">
		
		<input type="submit" value="Benutzer bearbeiten">
	</form>
</div>