<?php
/**
* Loggt den Benutzer aus.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Session löschen
		session_destroy();
		
		// Zur Startseite weiterleiten
		\Core\Module::goToModule();
	}
}
?>