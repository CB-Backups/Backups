<?php
/**
* Skript für die Rechte-Einstellungen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-14
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $settingsInstance;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Rechte');
		
		// Nur der Hauptbenutzer hat Zugriff auf dieses Modul
		if(!$this->si()->getUserInstance()->isDebugUser())
			\Core\Module::goToModule('Admin_Rights');
		
		// Einstellungs-Objekt speichern
		$this->settingsInstance = \Content\i::Config('rights');
		$this->mi()->addVarCache('settings', $this->settingsInstance);
		
		try {
			// Einstellungen ändern?
			if(isset($options['changeSettings']) && $options['changeSettings'])
				$this->changeSettings($this->mi()->getUserInput('setting', []));
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
	}
	
	/**
	* Ändert die Einstellung der angegeben Optionen.
	*
	* @param array $settings
	**/
	private function changeSettings(array $settings) {
		// Alle mitgegenebe Einstellungen durchlaufen
		foreach($settings as $key => $currentSetting) {
			// Diese Einstellung gibt es gar nicht
			if(!isset($this->settingsInstance[$key])) continue;			
			
			// Keine Einstellung mitgegeben -> Standard-Wert verwenden
			if(empty($currentSetting)) $currentSetting = NULL;
			// Einstellung setzen
			$this->settingsInstance[$key]->setCurrent($currentSetting);
		}
	}
}
?>