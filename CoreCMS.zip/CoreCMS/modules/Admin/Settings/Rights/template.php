<div id="contentRight">
	<?= ^^^('messages') ?>

	<h4>Rechte anpassen</h4>
	<p>
		Hier kannst du einstellen, welche Module andere Benutzer haben. Du als Hauptbenutzer hast immer alle Rechte.
	</p>
	
	<form method="post" action="<?= >>>(NULL, ['changeSettings'=>true]) ?>">
		<table class="TableOverview TableSmall">
			<tr>
				<th class="ColBig">Modul</th>
				<th>Erlaubt?</th>
			</tr>
			<? foreach(!!!settings!!! as $currentEntry): ?>
				<tr>
					<td><?= $currentEntry->getName() ?></td>
					<td class="Center"><?= ^^^('settingsEntry', ['entry'=>$currentEntry]) ?></td>
				</tr>
			<? endforeach; ?>
		</table>
		
		<input type="submit" value="Einstellungen ändern">
	</form>	
</div>