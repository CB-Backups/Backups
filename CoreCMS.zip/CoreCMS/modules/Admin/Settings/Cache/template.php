<div id="contentRight">
	<?= ^^^('messages') ?>

	<h4>Cache</h4>
	<p>
		Hier siehst du einen Überblick über den Cache der CoreCMS-Installation.
		Alle Daten, die im Cache gespeichert sind können automatisch wieder neu generiert werden.
	</p>
	<p>
		<em>Der Cache-Ordner ist nie ganz leer, da nach dem Leeren direkt wieder neue Daten geschrieben werden.</em>
	</p>
	
	<table class="TableOverview">
		<tr>
			<th class="ColBig">Cache-Element</th>
			<th>Beschreibung</th>
			<th class="ColMiddleBig">Datenverbrauch</th>
			<th class="ColMiddle">Optionen</th>
		</tr>
		<? foreach(!!!cacheDirectory!!! as $currentElement): ?>
			<tr>
				<td class="Top">Cache/<?= $currentElement->getName() ?></td>
				<td>
					<? if($currentElement instanceof \Core\IO\Directory): ?>
						<? $dirInfo = $currentElement->readInfo(); ?>
						<? if(isset($dirInfo['description'])): ?>
							<?= Format::string($dirInfo['description']) ?>
						<? else: ?>
							Ordner
						<? endif; ?>
					<? else: ?>
						Datei
					<? endif; ?>
				</td>
				<td class="Center Top"><?= Format::size($currentElement->getSize()) ?></td>
				<td class="Center Top">
					<a href="<?= >>>(NULL, ['removeElement'=>$currentElement->getPath()]) ?>" class="NoBorder" title="Das Element löschen">
						<img src="images/icons/delete.png" alt="Löschen">
					</a>
				</td>
			</tr>
		<? endforeach; ?>
		<tr class="EndRow">
			<td colspan="2">Insgesamt</td>
			<td class="Center"><?= Format::size(!!!cacheDirectory!!!->getSize()) ?></td>
			<td class="Center">
				<a href="<?= >>>(NULL, ['clearCache'=>true]) ?>" class="NoBorder" title="Den Ordner leeren">
					<img src="images/icons/bin_empty.png" alt="Leeren">
				</a>
			</td>
		</tr>
	</table>
</div>