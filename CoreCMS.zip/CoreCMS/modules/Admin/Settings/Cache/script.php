<?php
/**
* Skript für die Cache-Informationen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-06
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $directoryInstance;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Cache');
		
		// Cacheordner-Instanz
		$this->directoryInstance = \Core\Cache::getDirectoryInstance();
		$this->mi()->addVarCache('cacheDirectory', $this->directoryInstance);
		
		try {
			// Cache-Ordner leeren
			if(isset($options['clearCache']) && $options['clearCache'])
				$this->clearCache();
				
			// Einzelne Elemente löschen
			if(isset($options['removeElement'])) {
				// Pfad zu Element
				$element = \Core\IO\Element::toElement($options['removeElement']);
				
				// Löschen durchfüren
				$this->removeElement($element);
			}
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		} catch(\Exception $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', 'Interner Fehler: '.$exception->getMessage().' ('.$exception->getCode().')');
		}
	}
	
	/**
	* Leert den Cache-Ordner
	**/
	private function clearCache() {
		// Alle Elemente durchlaufen
		foreach($this->directoryInstance as $current) $current->remove();
	}
	
	/**
	* Löscht ein Element aus dem Cache-Ordner
	*
	* @param Core\IO\Element $element
	**/
	private function removeElement(\Core\IO\Element $element) {
		// Rechte prüfen
		if(!$this->directoryInstance->inDir($element))
			throw new \HumanException('Keine Cache-Daten.', -1);
			
		// Der Hauptordner darf nicht gelöscht werden.
		if($element->getPath() == $this->directoryInstance->getPath())
			throw new \HumanException('Der Haupt-Cacheordner darf nicht verändert werden.', -2);
		
		// Element löschen
		$element->remove();
	}
}