<div id="contentRight">
	<?= ^^^('messages') ?>

	<h4>Allgemeine Einstellungen</h4>
	<p>
		Hier kannst du einige allgemeine Einstellungen zu dieser Installation von CoreCMS ändern.
	</p>
	
	<form method="post" action="<?= >>>(NULL, ['changeSettings'=>true]) ?>">
		<table class="TableOverview TableMiddle">
			<tr>
				<th class="ColBig">Einstellung</th>
				<th>Wert</th>
			</tr>
			<? foreach(!!!settings!!! as $currentEntry): ?>
				<tr>
					<td><?= $currentEntry->getName() ?></td>
					<td><?= ^^^('settingsEntry', ['entry'=>$currentEntry]) ?></td>
				</tr>
			<? endforeach; ?>
		</table>
		
		<input type="submit" value="Einstellungen ändern">
	</form>	
</div>