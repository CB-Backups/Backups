<?php
/**
* Skript für die Informationsseite.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-09
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Information');
		
		// Header-Template setzen
		$this->mi()->addVarCache('headerTemplate', 'infoHeader');
		
		// Lizenz laden
		$licenseText = file_get_contents(ROOT_PATH.\Config\Version\LICENSE_FILE);
		$this->mi()->addVarCache('licenseText', $licenseText);
		
		// Versions-String laden
		$this->mi()->addVarCache('versionsString', \Config\Version\STRING);
		foreach(['phpVersion','memoryLimit','uploadLimit','serverSoftware', 'serverOS'] as $current)
			$this->mi()->addVarCache($current, \Core\System::$current());
	}
}
?>