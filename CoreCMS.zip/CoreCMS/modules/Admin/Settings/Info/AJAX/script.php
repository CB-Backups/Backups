<?php
/**
* Skript für Versionsvergleich
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-19
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Main-Instanz speichern
		$main = \Content\i::Main();
		
		try {
			// Existiert eine neuere Version? Versionsnummer zurückgeben
			if($main->existNewVersion())
				echo $main->getCurrentVersion();
			else // Bereits aktuelle Version
				echo 'current';
		} catch(\Exception $expcetion) {
			// Einfach nur Fehler zurückgeben
			echo 'loadingError';
		}
	}
}
?>