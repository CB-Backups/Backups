<div id="contentRight">
	<div class="Notice Loader" id="loadingSplash">
		Es wird versucht Informationen über eine neuere Version von CoreCMS zu laden…
	</div>
	<div class="Success Hidden" id="noNewerVersion">
		Es ist bereits die aktuellste Version von CoreCMS installiert.
	</div>
	<div class="Warning Hidden" id="newerVersionExists">
		Es existiert eine neuere Version von CoreCMS. <strong>Versionsnummer:</strong> <span id="newerVersionNumber">unbekannt</span>
	</div>
	<div class="Error Hidden" id="loadingError">
		Beim Versuch Informationen über eine neue Version zu laden ist ein Fehler aufgetreten.
	</div>

	<h4>Information</h4>
	<p>
		Auf dieser Seite stehen einige Informationen zu CoreCMS und dem System auf dem diese Installation läuft.
	</p>
	
	<table class="TableOverview TableSmall">
		<tr>
			<th colspan="2">
				CoreCMS, Version <?= Format::string(!!!versionsString!!!) ?>
			</th>
		</tr>
		<tr>
			<td class="Top ColMiddleBig">PHP-Version</td>
			<td class="Top"><?= Format::string(!!!phpVersion!!!) ?></td>
		</tr>
		<tr>
			<td class="Top">Memory-Limit</td>
			<td><?= Format::size(!!!memoryLimit!!!) ?></td>
		</tr>
		<tr>
			<td class="Top">Upload-Limit</td>
			<td><?= Format::size(!!!uploadLimit!!!) ?></td>
		</tr>
		<tr>
			<td class="Top">Server-Software</td>
			<td><?= Format::string(!!!serverSoftware!!!) ?></td>
		</tr>
		<tr>
			<td class="Top">Betriebsystem</td>
			<td><?= Format::string(!!!serverOS!!!) ?></td>
		</tr>
	</table>
	
	<div class="CodeBlock"><?= Format::string(!!!licenseText!!!) ?></div>
</div>