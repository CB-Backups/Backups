<?php
/**
* Hauptskript für das Einstellungs-Menü.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-12
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Navigations-Array
		$navigationArray = [''		=> 'Allgemein',
							//'Plugin'=> 'Pluginverwaltung',
							'Cache'	=> 'Cache',
							'Info'	=> 'Information'];
		// Hauptbenutzer sieht noch das Rechte-Menü
		if($this->si()->getUserInstance()->isDebugUser())
			$navigationArray['Rights'] = 'Rechte anpassen';
		// Navigation dem Modul hinzufügen
		$this->mi()->addVarCache('navigationArray', $navigationArray);
		// root-Modul angeben
		$this->mi()->addVarCache('navigationRoot', 'Admin_Settings');
		
		// Rechte des Benutzers prüfen
		if(!\Content\i::Config('rights')['config']->getCurrent() && !$this->si()->getUserInstance()->isDebugUser())
			\Core\Module::goToModule('Admin_Rights');
	}
}
?>