<div id="contentRight">
	<?= ^^^('messages') ?>

	<h4>Pluginverwaltung</h4>
	<p>
		Eine Liste aller installierten Plugins und die Möglichkeit neue Plugins zu installieren findest du hier.
	</p>
	
	<p>
		<form class="Center" method="post" action="<?= >>>(NULL, ['installPlugin'=>true]) ?>" enctype="multipart/form-data">
			<input type="file" name="pluginFile">
			<input type="submit" value="Installieren…">
		</form>
	</p>
	
	<table class="TableOverview">
		<tr>
			<th class="ColMiddleBig">Pluginname</th>
			<th>Beschreibung</th>
			<th class="ColMiddle">Version</th>
			<th class="ColMiddle">Optionen</th>
		</tr>
		<? if(count(!!!pluginManager!!!)): ?>
			<? foreach(!!!pluginManager!!! as $currentPlugin): ?>
				<tr>
					<td class="Top"><?= Format::string($currentPlugin->getName()) ?></td>
				</tr>
			<? endforeach; ?>
		<? else: ?>
			<tr>
				<td class="Center" colspan="4">
					Es sind derzeit keine Plugins installiert…
				</td>
			</tr>
		<? endif; ?>
	</table>
</div>