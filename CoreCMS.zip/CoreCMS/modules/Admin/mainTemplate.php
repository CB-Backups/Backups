<div class="Right" id="navigation">
	<ul>
		<li><a href="<?= >>>('Admin_Logout') ?>" title="Ausloggen">Logout</a></li>
		<li><a href="<?= >>>('Admin_Settings') ?>" title="Einstellungen"
			<? if(\Core\i::Module()->kindOf('Admin_Settings')): ?> class="Active" <? endif ?>>Einstellungen</a></li>
		<li><a href="<?= >>>('Admin_User') ?>" title="Benutzerverwaltung"
			<? if(\Core\i::Module()->kindOf('Admin_User')): ?> class="Active" <? endif ?>>Benutzerverwaltung</a></li>
		<li><a href="<?= >>>('Admin_Media') ?>" title="Medienverwaltung"
			<? if(\Core\i::Module()->kindOf('Admin_Media')): ?> class="Active" <? endif ?>>Medienverwaltung</a></li>
		<li><a href="<?= >>>('Admin_Sites') ?>" title="Seitenverwaltung"
			<? if(\Core\i::Module()->kindOf('Admin_Sites')): ?> class="Active" <? endif ?>>Seitenverwaltung</a></li>
		
		
	</ul>
</div>

<div class="Clear"></div>
<hr>

<? if(???navigationArray???): ?>
	<div id="navigationLeft">
		<ul>
			<? foreach(!!!navigationArray!!! as $key => $currentElement): ?>
				<li><a href="<?= >>>((???navigationRoot??? ? !!!navigationRoot!!!.'_' : '').$key) ?>"><?= Format::string($currentElement) ?></a></li>
			<? endforeach; ?>
		</ul>
	</div>
<? endif; ?>