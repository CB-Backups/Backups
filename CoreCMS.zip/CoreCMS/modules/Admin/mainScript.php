<?php
/**
* Hautpskript für die Administrations-Oberfläche.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-08
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Ändert das Template-Set
		$this->mi()->setTemplateSet('system');
		
		$this->checkSession();
	}
	
	/**
	* Überprüft ob eine Sitzung vorhanden ist und sie valid ist.
	**/
	protected function checkSession() {
		try {
			// Der Versuch, die Session abzurufen reicht.
			$this->si()->isValid();
		} catch(\Exception $exception) {
			// Sitzung entfernen
			session_destroy();
			
			// Keine valide Sitzung? Erstmal zur Startseite.
			\Core\Module::goToModule('Login', ['currentSession'=>'invalid']);
		}
	}
}
?>