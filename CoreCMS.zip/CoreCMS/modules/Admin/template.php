<h4>Willkommen im Adminbereich von CoreCMS</h4>
<p>
	Hier hast du die Möglichkeit eine Vielzahl an Einstellungen vorzunehmen, um dieses CMS voll an deine Bedürfnisse anzupassen.
	Dies ist zum Beispiel durch das Installieren von Plugins oder durch verschiedene Einstellungen möglich.
</p>
<p>
	CoreCMS ist ein einfaches CMS-System, welches mithilfe von PHP, MySQL, HTML5 und CSS3 entwickelt wird.
	Das CMS soll durch eine einfache Plugin-Schnittstelle schnell erweiterbar sein.
	Eine Medienverwaltung und eine einfache Seitenverwaltung sind standardmäßig dabei.
</p>
<p>
	Das System beinhaltet eine sehr einfache Benutzer-/Rechteverwaltung und ist deswegen für kleinere Seiten ideal.
</p>
<p>
	Derzeit befindet sich die Entwicklung noch in der Alpha-Phase.
</p>