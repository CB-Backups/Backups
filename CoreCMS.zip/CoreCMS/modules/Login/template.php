<div id="headline">
	Login
</div>
<div class="Clear"></div>
<hr>

<? ^^^('messages') ?>

<div id="loginBox">
	<form method="post" action="<?= >>>(NULL, ['login'=>true]) ?>" class="LabelForm">
		<label for="userName">Loginname:</label> <input type="text" id="userName" name="userName">
		<label for="userPass">Passwort:</label> <input type="password" id="userPass" name="userPass">
		<div class="Clear"></div>
		
		<input type="submit" value="Login">
	</form>
</div>