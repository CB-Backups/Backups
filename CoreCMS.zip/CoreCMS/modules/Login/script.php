<?php
/**
* Loggt den Benutzer ein.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		$this->mi()->addVarCache('siteTitle', 'Login');
	
		// Ändert das Template-Set
		$this->mi()->setTemplateSet('system');
		
		try {
			if(isset($options['currentSession']) && $options['currentSession'] == 'invalid')
				throw new \HumanException('Deine Sitzung ist nicht mehr valid. Bitte logge dich erneut ein.', -1);
				
			// Login durchführen
			if (isset($options['login']) && $options['login'] == true) $this->login();
		} catch(\HumanException $exception) {
			$this->mi()->addVarCache('showError', true);
			$this->mi()->addVarCache('errorString', $exception->getMessage());
		}
	}
	
	/**
	* Führt einen Login aus, lädt die dazu benötitgten Daten aus dem $_POST-Array.
	**/
	private function login() {
		// Benutzerdaten laden
		$userName = $this->mi()->getUserInput('userName');
		$userPassword = $this->mi()->getUserInput('userPass');
		
		// Login durchführen
		$loginResult = \Core\User::loginUser($userName, $userPassword);

		// Session erstellen und speichern
		$sessionInstance = new \Core\Session($loginResult);
		\Core\Session\i::Manager()->setSessionInstance($sessionInstance);
		
		// Ins Spiel weiterleiten
		\Core\Module::goToModule('Admin');
	}
}
?>