<?php
/**
* Installations-Modul.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-13
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $installationInstance;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		
		// Installations-Status
		$this->mi()->addVarCache('packageStatus', 0);
		
		// Neue Installations-Instanz erstellen
		$this->installationInstance = new \Content\Install(false);
		
		// Eine Liste aller Zeitzonen laden
		$this->mi()->addVarCache('knownTimeZones', $this->installationInstance->getTimeZones());
		
		// User-Eingaben zum MySQL-Server laden
		foreach(['Server', 'User', 'Pass', 'Database'] as $current)
			$this->mi()->addVarCache('mysql'.$current, $this->mi()->getUserInput('mysql'.$current));
		// Sonstige User-Eingaben laden
		$this->mi()->addVarCache('currentTimeZone', $this->mi()->getUserInput('currentTimeZone', \Config\TIME_ZONE));
		$this->mi()->addVarCache('createDatabase', isset($_POST['createDatabase']) ? true : false);
		$this->mi()->addVarCache('debugMode', isset($_POST['debugMode']) ? true : false);
		
		try {
			// System-Check durchführen
			$this->installationInstance->systemCheck();
		
			// Der System-Check war erfolgreich
			$this->mi()->addVarCache('badStatus', false);
			$this->mi()->addVarCache('statusString', "Der Server scheint alle Systemvorraussetzungen zu erfüllen.");
			
			try {
				// Installation soll durchgeführt werden?
				if(isset($options['writeConfiguration']) && $options['writeConfiguration'] == true)
					$this->writeConfigurations();				
			} catch(\HumanException $exception) { // Fehlermeldungen während der Installation abfangen
				$this->mi()->addVarCache('showError', true);
				$this->mi()->addVarCache('errorString', $exception->getMessage());
			}
		} catch (\HumanException $exception) { 
			// Der System-Check war nicht erfolgreich
			$this->mi()->addVarCache('badStatus', true); 
			$this->mi()->addVarCache('statusString', $exception->getMessage());
		}
	}
	
	/**
	* Überprüft die eingegeben Daten und schreibt die Konfiguration, falls alles korrekt war.
	**/
	protected function writeConfigurations() {
		// Debug-Modus setzen
		$this->installationInstance->setDebugMode($this->mi()->getVarCache('debugMode'));
		// Zeitzone setzen
		$this->installationInstance->setTimeZone($this->mi()->getVarCache('currentTimeZone'));
		// MySQL-Daten setzen		
		$this->installationInstance->setMySQLData($this->mi()->getVarCache('mysqlServer'),$this->mi()->getVarCache('mysqlUser'),$this->mi()->getVarCache('mysqlPass'),$this->mi()->getVarCache('mysqlDatabase'), $this->mi()->getVarCache('createDatabase'));
		
		// Tabellen in die Datenbank schreiben
		$this->installationInstance->createMySQLTables();
		// Konfigurations-Datei schreiben
		$this->installationInstance->writeConfig();
		
		// Auf die Startseite umleiten
		\Core\Module::goToModule('Install_User');
	}
}
?>