<?php
/**
* Hautpskript für die Installation.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-13
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	public function __construct() {
		// Dieses Modul steht nur zur Verfügung, wenn das Script nicht installiert ist.
		if(\Config\INSTALLED) \Core\Module::goToModule();
		
		// Ändert das Template-Set
		$this->mi()->setTemplateSet('install');
		// Packet-Name setzen
		$this->mi()->addVarCache('packageName', 'CoreCMS');
	}
}