<p>
	Du kannst hier ein Hauptuser für das CMS erstellen. Dieser Benutzer kann nicht gelöscht oder gesperrt werden.
	Es wird dringend empfohlen einen Hauptuser anzulegen, da ansonsten kein Login möglich ist.
</p>

<form method="post" action="<?= >>>(NULL, ['writeConfiguration'=>true]) ?>">
	<fieldset class="Right">
		<legend>Benutzer-Details</legend>
		
		<label for="userName">Benutzername:</label>
		<input type="text" name="userName" id="userName" value="<?= Format::string(!!!userName!!!) ?>">
			
		<label for="userMail">E-Mail-Adresse:</label>
		<input type="email" name="userMail" id="userMail" value="<?= Format::string(!!!userMail!!!) ?>">
			
		<label for="userPassword">Passwort:</label>
		<input type="password" name="userPassword" id="userPassword" value="<?= Format::string(!!!userPassword!!!) ?>">
			
		<label for="userPasswordAgain">Passwort wiederholen:</label>
		<input type="password" name="userPasswordAgain" id="userPasswordAgain" value="<?= Format::string(!!!userPasswordAgain!!!) ?>">
	</fieldset>
	
	<fieldset class="Box">
		<legend>Anlegen?</legend>
		
		<label for="debugUser">Haupt-User anlegen?</label>
		<input type="checkbox" name="debugUser" id="debugUser" checked="checked">
	</fieldset>
	
	<div class="Clear"></div>
	<input type="submit" class="Right" value="Installation durchführen">
	<input type="submit" class="Left" value="&laquo; Zurück" name="back">
	<div class="Clear"></div>
</form>