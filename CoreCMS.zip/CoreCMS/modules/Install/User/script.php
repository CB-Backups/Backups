<?php
/**
* Skript zum erstellen des Hauptusers.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-13
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $installationInstance;

	public function __construct() {
		$options = $this->mi()->getVarCache('options');
		
		// Installations-Status
		$this->mi()->addVarCache('packageStatus', 50);
		
		// User-Eingaben laden
		foreach(['Name', 'Mail', 'Password', 'PasswordAgain'] as $current)
			$this->mi()->addVarCache('user'.$current, $this->mi()->getUserInput('user'.$current));
		
		// Neue Installations-Instanz erstellen
		$this->installationInstance = new \Content\Install(true);
		
		try {
			// System-Check durchführen
			$this->installationInstance->systemCheck();
			
			// MySQL-Verbindung aufbauen
			\Core\i::MySQL();
			
			try {
				// Installation soll durchgeführt werden?
				if(isset($options['writeConfiguration']) && $options['writeConfiguration'] == true) {
					if(isset($_POST['back']))
						\Core\Module::goToModule('Install');
					else
						$this->writeConfigurations();	
				} 
			}  catch(\HumanException $exception) {
				$this->mi()->addVarCache('showError', true);
				$this->mi()->addVarCache('errorString', $exception->getMessage());
			}
		} catch (\Exception $exception) {
			// Einen Schritt zurück gehen
			\Core\Module::goToModule('Install');
		}
	}
	
	private function writeConfigurations() {
		if($this->mi()->getUserInput('debugUser', false)) {
			// Neuen Nutzer in die Datenbank schreiben
			$userInstance = \Core\User::createNewUser($this->mi()->getVarCache('userName'),$this->mi()->getVarCache('userPassword'),$this->mi()->getVarCache('userPasswordAgain'),$this->mi()->getVarCache('userMail'));
				
			$this->installationInstance->setDebugUser($userInstance);
		} else
			$this->installationInstance->setDebugUser();
					
		// Konfigurations-Datei schreiben
		$this->installationInstance->writeConfig();
					
		// Zum Admin-Login weiterleiten
		\Core\Module::goToModule('Login', ['installationSuccessfull'=>true]);
	}
}