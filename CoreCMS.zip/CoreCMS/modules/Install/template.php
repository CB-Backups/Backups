<p>
	Für die Grundinstallation von CoreCMS müssen einige Basis-Einstellungen vorgenommen werden.
	Nach dem du die MySQL-Daten erfolgreich eingegeben hast werden die benötigten Tabellen in der Datenbank erstellt.
</p>

<form method="post" action="<?= >>>(NULL, ['writeConfiguration'=>true]) ?>">
	<fieldset class="Right">
		<legend>MySQL-Daten</legend>
		<label for="mysqlServer">Servername:</label>
		<input type="text" name="mysqlServer" id="mysqlServer" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  value="<?= Format::string(!!!mysqlServer!!!) ?>">
		
		<label for="mysqlUser">Benutzer:</label>
		<input type="text" name="mysqlUser" id="mysqlUser" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  value="<?= Format::string(!!!mysqlUser!!!) ?>">
		
		<label for="mysqlPass">Passwort:</label>
		<input type="password" name="mysqlPass" id="mysqlPass" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  value="<?= Format::string(!!!mysqlPass!!!) ?>">
		
		<label for="mysqlDatabase">Datenbank-Name:</label>
		<input type="text" name="mysqlDatabase" id="mysqlDatabase" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  value="<?= Format::string(!!!mysqlDatabase!!!) ?>">
		
		<label for="createDatabase">Datenbank erstellen?</label>
		<input type="checkbox" name="createDatabase" id="createDatabase" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  <? if(!!!createDatabase!!!): ?> checked="checked"<? endif; ?>>
	</fieldset>

	<fieldset class="Left">
		<legend>Status</legend>
		<? if(!!!badStatus!!!):?> <span style="color: red;"> <? endif; ?>
			<?= !!!statusString!!! ?>
		<? if(!!!badStatus!!!):?> 
			</span>
		<? endif; ?>
	</fieldset>

	<fieldset class="Left">
		<legend>Allgemeine Einstellungen</legend>
		<label for="currentTimeZone">Aktuelle Zeitzone:</label>
		<select name="currentTimeZone" id="timeZone" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>>
			<? foreach (!!!knownTimeZones!!! as $key=>$time): ?>
				<option value="<?= $key ?>" <? if($key == !!!currentTimeZone!!!): ?>selected="selected"<? endif; ?>>
					(GMT<?= $time->toString(false,true) ?>) <?= Format::string($key) ?>
				</option>
			<? endforeach; ?>
		</select>
		
		<label for="debugMode">Debug-Modus?</label>
		<input type="checkbox" name="debugMode" id="debugMode" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>  <? if(!!!debugMode!!!): ?> checked="checked"<? endif; ?>>
	</fieldset>

	<div class="Clear"></div>
	<input type="submit" class="Right" value="Weiter &raquo;" <? if(!!!badStatus!!!):?> disabled="disabled" <? endif; ?>>
	<div class="Clear"></div>
</form>