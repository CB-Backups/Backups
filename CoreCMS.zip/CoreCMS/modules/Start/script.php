<?php
/**
* Skript für das Startseiten-Modul.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-08
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

script {
	private $siteManager, $currentSite;

	public function __construct() {
		// Konfiguration lesen
		$this->readConfig();
		
		// Seiten-Manager laden
		$this->siteManager = \Content\Site\i::Manager();
		// Alle Inhalte laden
		$this->siteManager->loadAll();
		// Seiten-Manager dem Modul hinzufügen
		$this->mi()->addVarCache('siteManager', $this->siteManager);
		
		try {
			// Aktuelle Seite festlegen
			$this->setCurrentSite();
			// Aktuelle Seite im Modul speichern
			$this->mi()->addVarCache('currentSite', $this->currentSite);
		} catch(\Exception $exception) {
			// Auf die Fehlerseite weiterleiten
			\Core\Module::goToModule(\Core\Module::ERROR_MODULE);
		}
		
		// Seitentitel anhand aktueller Seite festlegen
		$siteTitle = $this->currentSite->getName();
		// Seitenamen hinzufügen
		$siteTitle .= ' &middot; '.$this->mi()->getVarCache('sitename');
		// Seitentitel festlegen
		$this->mi()->addVarCache('siteTitle', $siteTitle);
	}
	
	/**
	* Lässt die Konfiguration der Seite.
	**/
	protected function readConfig() {
		// Intanz lesen
		$configInstance = \Content\i::Config('general');

		// Ließt die Konfigurationen aus
		foreach(['sitename', 'showLogin', 'copyright', 'cssStyle', 'lang'] as $current)
			$this->mi()->addVarCache($current, $configInstance[$current]->getCurrent());
	}
	
	/**
	* Ermittelt, welche Seite aktuell angeforder ist.
	**/
	protected function setCurrentSite() {
		// Seiten-ID gesetzetz?
		$siteID = $this->mi()->getUserInput('siteID', false, true);
		
		// Seite gesetzt? Nein? Dann Startseite verwenden
		if($siteID === false)
			$this->currentSite = $this->siteManager->getHome();
		else {
			// Seite vorhanden?
			if(isset($this->siteManager[$siteID])) $this->currentSite = $this->siteManager[$siteID];
			// Seite nicht gefunden? Zur Fehlerseite weiterleiten
			else \Core\Module::goToModule(\Core\Module::ERROR_MODULE);
		}
		
		// Seite-Aufrufszähler hochzählen
		$this->currentSite->setHits();
	}
}
?>