<header>
	<h1 id="sitename"><a href="<?= >>>(NULL) ?>"><?= !!!sitename!!! ?></a></h1>
	<? if(!!!showLogin!!!): ?>
		<span id="loginLink"><a href="<?= >>>('Login') ?>">Login</a></span>
	<? endif; ?>
</header>

<nav>
	<ul>
		<? foreach(!!!siteManager!!! as $id => $currentSite): ?>
			<? if($currentSite->isHidden()) continue; ?>
			<li <? if($currentSite == !!!currentSite!!!): ?> id="currentSite"<? endif;?>>
				<a href="<?= >>>(NULL, ['siteID'=>$id]) ?>"><?= Format::string($currentSite->getName()) ?></a>
			</li>
		<? endforeach; ?>
	</ul>
</nav>

<main>
	<? foreach(!!!currentSite!!! as $currentPost): ?>
		<? if($currentPost->isHidden()) continue; ?>
		<article>
			<h2 class="PostTitle"><?= Format::string($currentPost->getTitle()) ?></h2>
			<span class="PostDate">gepostet <?= Format::date($currentPost->getPostTime(), false, false) ?></span>
				
			<div class="PostContent"><?= $currentPost->getText() ?></div>
		</article>
	<? endforeach; ?>
</main>

<footer>
	Letzte Änderung: <?= Format::date(!!!currentSite!!!->getLastChange(), false, false, true) ?> &middot; &copy; <?= Format::string(!!!copyright!!!) ?>
</footer>