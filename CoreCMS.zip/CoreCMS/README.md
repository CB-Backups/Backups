# CoreCMS

CoreCMS is a simple CMS system, which is developed using PHP, MySQL, HTML5 and CSS3. The CMS uses a simple plug-in interface that is easily extended. Media management and a simple Site manager are included.

Currently, the development is still in the alpha phase.

### Server Requirements.
- PHP 5.4 (Memory-Limit > 64 MiB)
- MySQL 5.x
- Apache 2.x or lighttpd
