<?php
/**
* Interface, welches ein Session-Save-Handler beinhalten muss.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-25
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Session;

interface Handler {
	/**
	* Öffnet eine neue Session.
	*
	* @param string $path - Der Pfad zu der Session.
	* @param string $name - Name der Session
	**/
	public function open($path, $name);
	
	/**
	* Ließt die Daten aus der Session.
	*
	* @param string $id - ID Der Session
	* @return string
	**/
	public function read($id);
	
	/**
	* Schreibt die Daten in die Datenbank
	*
	* @param string $id - Die ID
	* @param string $data - Die Daten
	**/
	public function write($id, $data);
	
	/**
	* Schließt die Session.
	**/
	public function close();
	
	/**
	* Zerstört die Session
	*
	* @param string $id - Die ID
	**/
	public function destroy($id);
	
	/**
	* Löscht alte Sessions automatisch 
	*
	* @param int $lifetime - Wie lange dürfen Sessions leben?
	**/
	public function garbage($lifetime);
}
?>