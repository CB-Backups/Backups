<?php
/**
* Übernimmt die Session-Verwaltung.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-13
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Session;

class Manager extends \Core\Singleton implements Handler {
	use \Core\Singleton\Vars, \Core\Singleton\Auto;
	
	const SESSION_INSTANCE = 'SESSION_INSTANCE';
	const CAPTCHA_TEXT = 'CAPTCHA_TEXT';
	
	const SESSION_NAME = 'CORE_SESSION';
	const LIFETIME = 30; // in Minuten
	
	protected $tableActions;

	/**
	* Initialisiert die Session-Umgebung
	**/
	public function __construct() {
		parent::__construct();
		
		// TableAction setzen
		$this->tableActions = \Core\i::MySQL()->tableActions('sessions');

		// Session-Save-Handler setzen
		self::setSaveHandler($this);
		// Die Lebenszeit eine Sitzung festlegen
		session_cache_expire(self::LIFETIME);
		// Den Namen des Cookies setzen
		session_name(self::SESSION_NAME);
		
		// Session starten
		session_start();
	}
	
	/**
	* Speichert die Session-Daten
	**/
	public function __destruct() {
		session_write_close();
	}
	
	/**
	* Gibt die Session-Instance zurück.
	*
	* @return \Core\Session
	**/
	public function getSessionInstance() {
		if(!isset($_SESSION[self::SESSION_INSTANCE]))
			throw new \Exception('Es ist keine Session-Instance im Speicher vorhanden.', 1070);
	
		return $_SESSION[self::SESSION_INSTANCE];
	}
	
	/**
	* Setzt die Session-Instance
	*
	* @param \Core\Sesssion $sessionInstance
	**/
	public function setSessionInstance(\Core\Session $sessionInstance) {
		$_SESSION[self::SESSION_INSTANCE] = $sessionInstance;
	}
	
	/**
	* Setzt einen Captcha-Text in der Session.
	*
	* @param string $text
	**/
	public function setCaptchaText($string) {
		$_SESSION[self::CAPTCHA_TEXT] = $string;
	}
	
	/**
	* Überprüft einen Text.
	*
	* @param strin $text
	**/
	public function checkCaptchaText($string) {
		if(empty($_SESSION[self::CAPTCHA_TEXT]))
			throw new \Exception('Es ist kein Captcha-Text im Speicher vorhanden.', 1071);
			
		if($string != $_SESSION[self::CAPTCHA_TEXT])
			throw new \Exception('Der mitgegeben Text stimmt nicht mit dem gespeicherten Captcha-Text überein.', 1072);
	}
	
	/**
	* Öffnet eine neue Session. (Ist nicht wichtig.)
	*
	* @param string $path - Der Pfad zu der Session.
	* @param string $name - Name der Session
	**/
	public function open($path, $name) {}
	
	/**
	* Ließt die Daten aus der Session.
	*
	* @param string $id - ID Der Session
	* @return string
	**/
	public function read($id) {
		// Session in die DB tragen. (Falls bereits vorhande, lastAction aktuallisieren)
		$this->tableActions->insert(['id'=>$id, 'lastAction'=>time()], ['lastAction'=>time()]);
	
		// Daten aus der DB lesen und zurückgeben
		$queryObject = $this->tableActions->select(['id'=>$id]);
		return $queryObject->fetch()['data'];
	}
	
	/**
	* Schreibt die Daten in die Datenbank
	*
	* @param string $id - Die ID
	* @param string $data - Die Daten
	**/
	public function write($id, $data) {
		$this->tableActions->update(['data'=>$data],['id'=>$id]);
	}
	
	/**
	* Schließt die Session.
	**/
	public function close() {}
	
	/**
	* Zerstört die Session
	*
	* @param string $id - Die ID
	**/
	public function destroy($id='') {
		if(empty($id)) $id = session_id();
	
		$this->tableActions->delete(['id'=>$id]);
		
		// Cookie löschen
		\Core\i::Header()->deleteCookie(self::SESSION_NAME);
	}
	
	/**
	* Löscht alte Sessions automatisch 
	*
	* @param int $lifetime - Wie lange dürfen Sessions leben?
	**/
	public function garbage($lifetime) {
		$this->tableActions->delete('lastAction < '.(time()-$lifetime));
	}
	
	/**
	* Setzt den Session-Handler
	*
	* @param Handler
	**/
	public static function setSaveHandler(Handler $sessionHandler) {
		// Setzt die Instance
		session_set_save_handler(	[$sessionHandler, 'open'],
									[$sessionHandler, 'close'],
									[$sessionHandler, 'read'],
									[$sessionHandler, 'write'],
									[$sessionHandler, 'destroy'],
									[$sessionHandler, 'garbage']);
	}
}
?>