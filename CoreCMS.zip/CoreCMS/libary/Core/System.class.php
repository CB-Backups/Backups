<?php
/**
* Diese Klasse gibt Informationen über das System, auf dem sie läuft aus.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-11
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class System {
	/**
	* Gibt die volle PHP-Version zurück.
	*
	* @return string
	**/
	public static function phpVersion() {
		return phpversion();
	}
	
	/**
	* Gibt die größe des Arbeitsspeicher-Limits als Integer-Wert zurück.
	*
	* @return int
	**/
	public static function memoryLimit() {
		return calcBytes(ini_get('memory_limit'));	
	}
	
	/**
	* Gibt zurück, wie groß ein Datei-Upload maximla sein darf.
	*
	* @return int
	**/
	public static function uploadLimit() {
		// Erforderliche Einstellungen laden
		$mL = self::memoryLimit();
		$fL = calcBytes(ini_get('upload_max_filesize'));
		$pL = calcBytes(ini_get('post_max_size'));
		
		// Den kleinsten Wert zurückgeben
		return min($mL, $fL, $pL);
	}
	
	/**
	* Gibt die Server-Software zurück.
	*
	* @return string
	**/
	public static function serverSoftware() {
		return $_SERVER['SERVER_SOFTWARE'];
	}
	
	/**
	* Gibt das Betriebsystem des Servers zurück.
	*
	* @return string
	**/
	public static function serverOS() {
		return PHP_OS;
	}
	
	/**
	* Ist die GD-Lib installiert ist.
	*
	* @return bool
	**/
	public static function withGD() {
		return function_exists('gd_info');
	}
	
	/**
	* Ist MySQL installiert?
	*
	* @return bool
	**/
	public static function withMySQL() {
		return function_exists('mysqli_connect');
	}
}