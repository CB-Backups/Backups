<?php
/**
* Ein Trait, das erlaubt, ein bestimmtes Instanz-Arrasy als „Hauptarray“ behandeln zu lassen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-22
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

trait MainArray {
	/**
	* Diese Funktion gibt das Haupt-Array zurück.
	*
	* @return array
	**/
	abstract public function toArray();
	
	/**
	* Gibt die Anzahl der Verspätungen zurück.
	*
	* @return int
	**/
	public function count() {
		return count($this->toArray());
	}
	
	/**
	* Gibt die Iterator-Instanz zurück.
	*
	* @return \ArrayIterator
	**/
	public function getIterator() {
		return new \ArrayIterator($this->toArray());
	}
	
	/**
	* Gibt zurück, ob das Offset von einem Array vorhanden ist.
	*
	* @param mixed $offset
	* @return bool
	**/
	public function offsetExists($offset) {
		// return isset($this->toArray()[$offset]); // Geht erst ab PHP 5.5
	
		$array = $this->toArray();
		return isset($array[$offset]);
	}
	
	/**
	* Gibt den Wert eines Offsets zurück.
	*
	* @param mixed $offset
	* @return mixed
	**/
	public function offsetGet($offset) {
		if(!$this->offsetExists($offset))
			throw new \Exception('Es gibt kein Inhalt zu dem angeforderten Offset „'.$offset.'“.', 1180);
			
		return $this->toArray()[$offset];
	}
	
	/**
	* Das Setzen von neuen Werten ist nicht erlaubt.
	*
	* @param mixed $offset
	* @param mixed $value
	**/
	public function offsetSet($offset, $value) {
		throw new \Exception('Es ist nicht erlaubt Werte dieser Instanz zu verändern.', 1181);
	}
	
	/**
	* Das Löschen von Werten ist nicht erlaubt.
	*
	* @param mixed $offset
	**/
	public function offsetUnset($offset) {
		throw new \Exception('Es ist nicht erlaubt Werte dieser Instanz zu verändern.', 1181);
	}
}
?>