<?php
/**
* Eine angepasste Version der DateTimeZone-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Time;

class Zone extends \DateTimeZone {
	private static $abbreviationsCache;

	/**
	* Passt die Funktion der Eltern-Klasse an.
	*
	* @return array
	**/
	public static function listAbbreviations() {
		// Bereits Zeitzonen im Cache?
		if(is_array(self::$abbreviationsCache)) return self::$abbreviationsCache;
	
		$data = parent::listAbbreviations();
		$array = [];
		
		// Vorhandene Zeitzonen von PHP bekommen
		foreach($data as $currentTimeZoneArray) {
			foreach($currentTimeZoneArray as $currentTimeZone) {
				// Sommerzeiten ignorieren
				if($currentTimeZone['dst'] || empty($currentTimeZone['timezone_id'])) continue;
			
				$key = $currentTimeZone['timezone_id'];
				$value = new Duration($currentTimeZone['offset']);
				
				// Dem Array hinzufügen
				$array[$key] = $value;	
			}
		}
		
		// Array nach Zeit sortieren
		uasort($array, function($a, $b) {
			$a = $a->toInt() * ($a->isNegative() ? -1 : 1);
			$b = $b->toInt() * ($b->isNegative() ? -1 : 1);
			
			if($a == $b) return 0;
			
			return ($a < $b) ? -1 : 1;
		});
		
		// Im Cache speichern
		self::$abbreviationsCache = $array;

		return $array;
	}
}
?>