<?php
/**
* Eine angepasste Version der DateTime-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Time;

class Date extends \DateTime {
	/**
	* Der Constructor lädt sich automatisch die richtige Zeitzone
	*
	* @param string $string - Die Zeit [optional]
	**/
	public function __construct($string = 'now') {
	 	parent::__construct($string, \Core\i::Main()->getTimeZone());
	}
}
?>