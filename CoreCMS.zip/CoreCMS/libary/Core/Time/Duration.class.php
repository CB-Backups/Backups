<?php
/**
* Psyeudo Datentyp für eine Zeitdauer.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-02
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Time;

class Duration extends \Object {
	protected $time, $negative = false;
	
	/**
	* Neue Zeit
	*
	* @param int $time - Zeit in Sekunden [optional]
	**/
	public function __construct($time=0) {
		// Wenn negativ, muss das 
		if($time < 0) {
			$this->negative = true;
			$time *= -1;
		}
	
		$this->time = $time;
	}	
	
	/**
   	* Gibt die Stunden dieser Zeit zurück
   	*
   	* @return string
   	**/
   	public function getHours() {
   		$hours = floor($this->time / 60 / 60);
   		
   		return sprintf('%02d', $hours);
   	}
   	
   	/**
   	* Gibt die Minuten dieser Zeit zurück
   	*
   	* @return string
   	**/
   	public function getMinutes() {
   		$minutes = floor($this->time / 60);
   		$minutes -= $this->getHours()*60;
   		
   		return sprintf('%02d', $minutes);
   	}
   	
   	/**
   	* Gibt die Sekunden dieser Zeit zurück
   	*
   	* @return string
   	**/
   	public function getSeconds() {
   		$seconds = $this->time % 60;
   	
   		return sprintf('%02d', $seconds);
   	}
   	
   	/**
   	* Gibt zurück, ob es sich um eine negative Dauer handelt.
   	*
   	* @return bool
   	**/
   	public function isNegative() {
	   	return $this->negative;
   	}
   	
   /**
	* Gibt die Zeit als formatierten String zurück.
	*
	* @param bool $withSeconds [optional]
	* @param bool $showPositive [optional]
	* @return string
	**/
   	public function toString($withSeconds=false, $showPositive=false) {
   		$addition = '';
   		$additionAfter = '';

   		if($this->isNegative()) $addition .= '-';
   		else if($showPositive) $addition .= '+';
   		
   		if($withSeconds) $additionAfter .= ':'.$this->getSeconds();
   		
   		return $addition.$this->getHours().':'.$this->getMinutes().$additionAfter;
   	}
	
   	/**
	* Magische Methode zur String-Umwandlung
	*
	* @return string
	**/
	public function __toString() {
		return $this->toString();	
	}
   	
   	/**
   	* Gibt die Zeit als Integer-Wert zurück.
   	*
   	* @return int
   	**/
   	public function toInt() {
	   	return $this->time;
   	}
 
   	
   	/**
   	* Neue Zeit durch Angabe von Minuten und Sekunden
   	*
   	* @param int $minutes
   	* @param int $seconds
   	**/
   	public static function withHoursAndMinutes($hours,$minutes) {
   		// Mehr als 59 Minuten? Ungültige Zeit.
   		if($minutes > 59)
   			throw new \Exception('Ungültige Zeit angegeben: Minuten dürfen nicht größer als 59 sein, sind aber „'.$minutes.'“.', 1190);
   		
   		// Sekunden errechnen
   		$minutes = $hours*60 + $minutes;
   		$seconds = $minutes*60;
   		
   		// Object zurückgeben
	   	return new self($seconds);
   	}
}
?>