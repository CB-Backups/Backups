<?php
/**
* Eine Instanz dieser Klasse wird als Resourcen-Ersatz bei jeder Query zurückgegeben.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-11-30
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\MySQL;

class Query extends \Object implements \Countable, \IteratorAggregate, \ArrayAccess {
	use \Core\MainArray;

	protected $mysqlInstance, $pdoStatement, $lastID;
	protected $fetchAllCache;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('lastID', true);
	}
	
	/**
	* Öffnet eine neue Instanz von \Core\MySQL\Query
	*
	* @param \Core\MySQL $mysqlInstance - Die MySQL-Instanz
	* @param PDOStatement $pdoStatement - Die Query-Resource
	**/
	public function __construct(\Core\MySQL $mysqlInstance, \PDOStatement $pdoStatement) {
		// Klassenvariablen setzen
		$this->mysqlInstance = $mysqlInstance;
		$this->pdoStatement = $pdoStatement;
		$this->lastID = $this->mysqlInstance->getPDOInstance()->lastInsertID();
	}
	
	/**
	* Gibt das nächste Element dieser Anfrage zurück.
	* 
	* @return array
	**/
	public function fetch() {
		return $this->pdoStatement->fetch();
	}
	
	/**
	* Gibt alle Elemente dieser Anfrage zurück.
	*
	* @return array
	**/
	public function fetchAll() {
		if(is_null($this->fetchAllCache))
			$this->fetchAllCache = $this->pdoStatement->fetchAll();
	
		return $this->fetchAllCache;
	}
	
	/**
	* Gibt die Query als Array zurück. (FetchAll mit Cache.)
	*
	* @return array
	**/
	public function toArray() {
		return $this->fetchAll();
	}
}