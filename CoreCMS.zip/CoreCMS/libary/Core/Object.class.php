<?php
/**
* Überklasse für alle Klassen, vom Core zur Verfügung gestellt.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-30
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

abstract class Object implements \Serializable {
	private static $objectCaches = [];
	
	/**
	* Gibt den Cache der Klasse zurück.
	*
	* @param \Core\Object\Cache
	**/
	final private static function getObjectCache() {
		// Name der Klasse
		$className = get_called_class();
	
		// Noch kein Objekt-Cache vorhanden?
		if(!isset(self::$objectCaches[$className])) {
			// Neues Cache-Objekt erstellen
			self::$objectCaches[$className] = new Object\Cache();
		}
			
		// Cache zurückgeben
		return self::$objectCaches[$className];
	}
	
	/**
	* Registriert eine Eigenschafft und setzt eventuell Setter und Getter
	*
	* @param string $varName - Name der Eigenschaft
	* @param bool $getter - Soll eine Getter-Methode gesetzt werden?
	* @param bool $setter - Soll eine Setter-Methode gesetzt werden? [optional]
	* @param Classname $instanceOf - Der Setter soll nur Objekte der Klasse x annehmen? [optional]
	**/
	final protected static function registerProperty($varName, $getter, $setter = false, Classname $instanceOf = NULL) {
		// Eigenschaft reflektieren
		$reflection = new \ReflectionProperty(get_called_class(), $varName);
		
		// Statische oder dynamische Eigenschaft?
		self::getObjectCache()->registeredProperties[$varName] = $reflection->isStatic();
		
		// Inhalt setzen
		self::getObjectCache()->registeredGetter[$varName] = $getter;
		self::getObjectCache()->registeredSetter[$varName] = $setter;
		self::getObjectCache()->registeredTypes[$varName] = $instanceOf;		
	}
	
	/**
	* Registriert mehrere Eigenschafft und setzt eventuell Setter und Getter
	*
	* @param array $varNames - Name der Eigenschaften
	* @param bool $getter - Soll eine Getter-Methode gesetzt werden?
	* @param bool $setter - Soll eine Setter-Methode gesetzt werden? [optional]
	**/
	final protected static function registerProperties(array $varNames, $getter, $setter = false) {
		foreach($varNames as $currentName)
			self::registerProperty($currentName, $getter, $setter);
	}
		
	/**
	* Gibt einen Variablen-Namen aus dem Namen einer Getter- oder Setter-Methode zurück.
	*
	* @param string $methodeName
	* @param bool $static - Statische Variable?
	* @return string
	**/
	final private static function getVarFromMethodeName($methodName, $static) {
		// Methodenzusatz entfernen
		$count = 0;	
		foreach(['/^set/', '/^is/', '/^get/'] as $current) {
			$methodName = preg_replace($current, '', $methodName, -1, $count);
			
			if($count > 0) break;
		}
		
		// Welche Groß-/Kleinschreibung ist richtig?
		foreach(array_keys(self::getObjectCache()->registeredProperties) as $propertyName) {
			// Übereinstimmung gefunden? Dann diese zurückgeben
			if(strtolower($methodName) == strtolower($propertyName) && self::getObjectCache()->registeredProperties[$propertyName] == $static)
				return $propertyName;
		}
						
		throw new \Exception('Diese Methode kann kein Setter oder Getter eine registrierten Klassen-Eigenschaft sein.', 1204);
	}
	
	/**
	* Setzt Eigenschaft-Werte.
	*
	* @param string $methodName - Name der Methode
	* @param mixed $value - Neuer Wert
	* @param object $this - Dynamische Eigenschaft? [optional]
	**/
	final private static function setProperty($var, $value, $thisInstance = NULL) {
		// Type überprüfen?
		if(self::getObjectCache()->registeredTypes[$var] !== NULL && $value !== NULL) { 
			$expectedObject = (string) self::getObjectCache()->registeredTypes[$var];
					
			if(!$value instanceof $expectedObject) {
				// Welchen Typ haben wir stattdesen bekommen? Für die Fehlermeldung.
				$unexpectedType = gettype($value);	
				// Type ist ein Objekt. Welches?
				if($unexpectedType == 'object') $unexpectedType = get_class($value);
						
				// Exception werfen
				throw new \Exception('Die Eigenschaft '.get_called_class().'::$'.$var.' erwartet eine Instanz der Klasse '.$this->registeredTypes[$varName].', „'.$unexpectedType.'“ bekommen.', 1202);		
			}
		}
				
		// Neuer Inhalt speichern
		if($thisInstance != NULL) $thisInstance->$var = $value;
		else static::$var = $value;
	}

	/**
	* Methoden-Überladung für dynamische Methoden-Aufrufe übernehmen.
	* 	(Automatisches Setter- und Getter-Methoden zur Verfügung stellen.)
	*
	* @param string $name - Klassen-Name, von der wir die Haupt-Instanze möchten.
	* @param array $args - Uninteressant.
	**/
	final public function __call($name, array $args) {
		try {
			// Variablennamen herausfinden
			$varName = self::getVarFromMethodeName($name, false);
	
			if(strpos($name, 'set') === 0 && self::getObjectCache()->registeredSetter[$varName]) { // Setzen?
				// Neuen Wert setzen 
				self::setProperty($varName, (isset($args[0]) ? $args[0] : NULL), $this);
				
				// Weitere Ausführung abbrechen
				return;
			} else if((strpos($name, 'get') === 0 || strpos($name, 'is') === 0) && self::getObjectCache()->registeredGetter[$varName]) // Laden?
				return $this->$varName;
		} catch (\Exception $exception) {
			if($exception->getCode() != 1204) throw $exception;
		}
		
		// Zusätzliche Call-Methode?
		if(method_exists($this, '___call'))
			return $this->___call($name, $args);
		
		// Keine gültige Methode
		throw new \Exception('Die Methode „'.$name.'“ ist in der Klasse „'.get_called_class().'“ nicht definiert.', 1200);
	}
	
	/**
	* Methoden-Überladung für statische Methoden-Aufrufe übernehmen.
	* 	(Automatisches Setter- und Getter-Methoden zur Verfügung stellen.)
	*
	* @param string $name - Klassen-Name, von der wir die Haupt-Instanze möchten.
	* @param array $args - Uninteressant.
	**/
	final public static function __callStatic($name, array $args) {
		try {
			// Variablennamen herausfinden
			$varName = self::getVarFromMethodeName($name, true);
	
			if(strpos($name, 'set') === 0 && self::getObjectCache()->registeredSetter[$varName]) { // Setzen?
				// Neuen Wert setzen 
				self::setProperty($varName, (isset($args[0]) ? $args[0] : NULL));
				
				// Weitere Ausführung abbrechen
				return;
			} else if((strpos($name, 'get') === 0 || strpos($name, 'is') === 0) && self::getObjectCache()->registeredGetter[$varName]) // Laden?
				return static::$varName;
		} catch (\Exception $exception) {
			if($exception->getCode() != 1204) throw $exception;
		}
		
		// Zusätzliche Call-Methode?
		if(method_exists(get_called_class(), '___callStatic'))
			return static::___callStatic($name, $args);
		
		// Keine gültige Methode
		throw new \Exception('Die Methode „'.$name.'“ ist in der Klasse „'.get_called_class().'“ nicht definiert.', 1200);
	}
	
	/**
	* Gibt das Objekt serialisiert zurück.
	*
	* @return string
	**/
	final public function serialize() {
		// Leeres Array erstellen
		$dataArray = [];
		
		// Existiert eine __sleep()-Methode? Dann die Daten übernehmen!
		if(method_exists($this, '__sleep')) {
			foreach($this->__sleep() as $currentProperty) {
				if(!property_exists($this, $currentProperty))
					throw new \Exception('Die Eigenschaft '.get_called_class().'::$'.$currentProperty.' ist nicht definiert.', 1201);
					
				// Inhalt in das Array speichern
				$dataArray[$currentProperty] = $this->$currentProperty;
			}
		} else // Wenn keine existiert einfach alle Attribute speichern
			$dataArray += get_object_vars($this);
		
		// Array serialisiert zurückgeben
		return serialize($dataArray);
	}
	
	/**
	* Ließt die Daten in das Objekt ein.
	*
	* @param string $serialized
	**/
	final public function unserialize($serialized) {
		// Geht das Array durch und schreibt die Daten in das Objekt
		foreach(unserialize($serialized) as $key => $value) {
			// Nur wenn die Property noch existiert
			if(!property_exists($this, $key)) continue;
			
			// Daten setzen
			$this->$key = $value;	
		}

		// Wakeup-Methode aufrufen, falls eine vorhanden ist
		if(method_exists($this, '__wakeup'))
			$this->__wakeup();
	}

}