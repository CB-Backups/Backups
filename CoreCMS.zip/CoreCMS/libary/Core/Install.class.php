<?php
/**
* Führt eine Installation durch, sammelt dazu benötigte Daten und schreibt sie in die Konfigurations-Datei.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-10-19
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

abstract class Install extends \Object {
	const FILE = 'config.inc.php';
	const SQL_FILE = '/docs/tables.sql';
	
	const REQUIERED_MEMORY_SIZE = '32M';
	const REQUIERED_PHP_VERSION = '5.4';
	
	protected $configurations = 	[	'INSTALLED' => NULL,
										'INSTALL_TIME' => NULL,
										'DEBUG' => \Config\DEBUG,
										'DEBUG_USER' => \Config\DEBUG_USER,
										'TIME_ZONE' => \Config\TIME_ZONE,
										'Version' => 	[	'STRING' => \Config\Version\STRING,
															'LICENSE_FILE' => \Config\Version\LICENSE_FILE,
															'SITE' => \Config\Version\SITE],
										'MySQL' =>		[	'SERVER' => \Config\MySQL\SERVER,
															'USER' => \Config\MySQL\USER,
															'PASS' => \Config\MySQL\PASS,
															'DATABASE' => \Config\MySQL\DATABASE]];
		
	/**
	* Öffnet die Installationsklasse und bestimmt, ob wir am Ende ein installationsfertige
	* Konfigurationsdatei besitzen möchten
	*
	* @param bool $install - Soll es installiert werden? [optional]
	**/
	public function __construct($install = true) {
		// Soll die Version als installiert gelten?
		$this->configurations['INSTALLED'] = $install;
		// Wann wurde sie installiert?
		$this->configurations['INSTALL_TIME'] = time();
	}	

	/**
	* Überprüft die System-Konfiguration und gibt eventuell Fehler zurück
	*
	* @return  bool - Entweder true oder eine Exception
	**/
	public function systemCheck() {
		// Die Konfigurations-Datei muss beschreibbar sein.
		if(!(is_writable(ROOT_PATH) || (file_exists(ROOT_PATH.static::FILE) && !is_writable(ROOT_PATH.static::FILE))))
			throw new \HumanException('Die Konfigurationsdatei „'.self::FILE.'“ muss existieren und beschreibbar sein oder das Hauptverzeichnis muss beschreibbar sein.');
		
		// Die PHP-Version muss größergleich self::REQUIERED_PHP_VERSION sein.
		if(version_compare(System::phpVersion(),static::REQUIERED_PHP_VERSION,'<'))
			throw new \HumanException('Es wird mindestens die PHP-Version „'.static::REQUIERED_PHP_VERSION.'“ benötigt.');
		
		// MySQL muss installiert sein.
		if(!System::withMySQL())
			throw new \HumanException('Es scheint kein MySQL auf diesem Server installiert zu sein.');
		
		// Das Cache-Verzeichnis muss beschreibar sein.
		if(!(file_exists(ROOT_PATH.'/'.Cache::DIR) && is_writable(ROOT_PATH.'/'.Cache::DIR)))
			throw new \HumanException('Der Cache-Ordner „'.Cache::DIR.'“ muss existieren und beschreibbar sein.');
		
		// Die Allowed-Memory-Size muss größergleich self::REQUIERED_MEMORY_SIZE sein.
		if(System::memoryLimit() < calcBytes(static::REQUIERED_MEMORY_SIZE))
			throw new \HumanException('Das Programm braucht mindestens '.Format::size(calcBytes(static::REQUIERED_MEMORY_SIZE)).' Arbeitsspeicher.');
			
		// Die GD-Lib muss installiert sein
		if(!System::withGD())
			throw new \HumanException('Die GD-Lib muss auf dem Server installiert sein.');
		
		return true;
	}
	
	/**
	* Gibt die Zeitzonen aus.
	*
	* @return array - Alle bekannten Zeitzonen
	**/
	public function getTimeZones() {
		// Zeitzonen aus der Zeitzonen-Klasse laden
		return \Core\Time\Zone::listAbbreviations();
	}
	
	/**
	* Setzt die Zeitzone
	*
	* @param string $timezone - Ausgewählte Zeitzone
	**/
	public function setTimeZone($timezone) {
		// Die Liste an Zeitzonen laden
		$knownTimeZones = $this->getTimeZones();
		// Die Zeitzone existiert nicht? Exception werfen!
		if(!isset($knownTimeZones[$timezone]))
			throw new \HumanException('Die gewählte Zeitzone ist nicht vorhanden.', -1);
			
		// Zeitzone setzen
		i::Main()->setTimeZone(new Time\Zone($timezone));
	
		$this->configurations['TIME_ZONE'] = $timezone;
	}
	
	/**
	* Setzt Debug-Modus
	*
	* @param bool $debugMode - Ja/nein?
	**/
	public function setDebugMode($debugMode) {
		$this->configurations['DEBUG'] = (bool) $debugMode;
	}
	
	/**
	* Setzt einen Debug-User
	*
	* @param User $debugUser
	**/
	public function setDebugUser(User $debugUser = NULL) {
		if(is_null($debugUser))
			$this->configurations['DEBUG_USER'] = -1;
		else
			$this->configurations['DEBUG_USER'] = $debugUser->getUserID();
	}
	
	/**
	* Setzt die MySQL-Daten in der Konfiguration
	*
	* @param string $server - Der MySQL-Server
	* @param string $user - Der MySQL-User
	* @param string $pass - Das MySQL-User-Passwort
	* @param string $database - Die MySQL-Datenbank
	* @param bool $createDatabase - Soll die Datenbank eventuell erstellt werden? [optional]
	**/
	public function setMySQLData($server, $user, $pass, $database, $createDatabase = false) {
		// Sind bereits MySQL-Daten gesetzt?
		if(MySQL::existMainInstance())
			throw new \Exception('Es ist bereits eine MySQL-Verbindung aufgebaut. Es können keine neuen Daten gesetzt werden.', 1050);
	
		// MySQL-Verbindung testen
		try {
			$mysqlObject = new MySQL($server, $user, $pass,NULL);
		} catch (\Exception $exception) {
			throw new \HumanException('Der MySQL-Server erlaubt keinen Login mit den eingegeben Login-Daten.', -1, $exception);
		}
		
		// MySQL-Datenbank auswählen
		try {
			// Soll die Datenbank erstellt werden?
			if($createDatabase) $mysqlObject->createDatabase($database);
			// Die Datenbank auswählen
			$mysqlObject->selectDatabase($database);
		} catch (\Exception $exception) {
			if ($createDatabase) 
				throw new \HumanException('Die Datenbank konnte nicht erstellt werden. Hast du überhaupt genug Rechte?', -2, $exception);
				
			throw new \HumanException('Die angegebene Datenbank ist dem MySQL-Server nicht bekannt. Bitte erstelle sie zuerst oder erlaube mir, sie zu erstellen.', -3, $exception);
		}
			
	
		// Daten in das Array schreiben
		$this->configurations['MySQL']['SERVER'] = $server;
		$this->configurations['MySQL']['USER'] = $user;
		$this->configurations['MySQL']['PASS'] = $pass;
		$this->configurations['MySQL']['DATABASE'] = $database;
	}
	
	/**
	* Erstellt die in der SQL-Datei angegeben Tabellen ein.
	**/
	public function createMySQLTables() {
		// SQL-Befehle aus der SQL-Datei lesen
		$sql = file_get_contents(ROOT_PATH.self::SQL_FILE);
		// Anfragen an MySQL-Server senden
		i::MySQL()->queries($sql);
	}
	
	/**
	* Schreibt die Konfiguration in die Konfigurationsdatei
	**/
	final public function writeConfig() {		
		// Zeit bilden
		$dateObject = new Time\Date();
		$date = $dateObject->format(Time\Date::RFC850);
		
		// Datei-Header erzeugen
		$fileContent = <<<CONTENT
<?php
/**
*
* Konfiguration für diese Installation.
* Generiert am: {$date}
*
**/


CONTENT;

		// Namespace defininieren
		$configurations = self::createNamespaceArray($this->configurations);
		// Naemspacces durchlaufen
		foreach($configurations as $key=>$currentConfiguration) {
			// Namespace defininieren
			$fileContent .= 'namespace '.$key." {\n";
				
			// Einzelne Elemente hinzufügen
			foreach($currentConfiguration as $key=>$value) {
				// Konfigurations-Eintrag je nach Datentype
				if(is_bool($value)) {
					if ($value) $valueString = 'true';
					else $valueString = 'false';
				} else if(is_numeric($value)) $valueString = $value;
				else $valueString = "'".$value."'";
				
				// Eintrag der Datei hinzufügen
				$fileContent .= "\tconst ".$key.' = '.$valueString.";\n";	
			}
				
			// Namespace abschließen
			$fileContent .= "}\n\n";
		}
		
		// Datei abschließen
		$fileContent .="?>";
	
		// Daten in die Datei schreiben
		file_put_contents(ROOT_PATH.self::FILE, $fileContent);
	}
	
	/**
	* Gibt ein Array, sortiert nach Namespaces zurück.
	*
	* @param array $configurations
	* @return array
	**/
	final protected static function createNamespaceArray(array $configurations) {
		$namespaceArray = [];
	
		// Rekursive Funktion erstellen
		$sortFunction = function(array $configurations, $namespaceString = 'Config') use(&$sortFunction, &$namespaceArray) {
			// Alle Elemente durchlaufen
			foreach($configurations as $key => $value) {
				if(is_array($value))
					$sortFunction($value, $namespaceString.'\\'.$key);
				else
					$namespaceArray[$namespaceString][$key] = $value;
			}
		};
		// Funktion aufrufen
		$sortFunction($configurations);

		// Array zurückgeben
		return $namespaceArray;
	}
}
?>