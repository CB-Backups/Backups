<?php
/**
* Diese Klasse stellt die angeforderten Seiten da und passt das Template entsprechend an.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-21
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

final class Module extends Singleton {
	use VarCache, Singleton\Vars, Singleton\Auto;

	const MODULE_DIR = 'modules/';
	const SET_DIR = 'templates/set/';
	const INC_DIR = 'templates/inc/';
	
	const START_MODULE = 'Start';
	const INSTALL_MODULE = 'Install';
	const ERROR_MODULE = 'Error';
	
	const GET_NAME = 'module';
	const GET_OPTIONS = 'options';
	
	protected $moduleName, $moduleAliasName, $templateSet;
		
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('moduleName', true);
		self::registerProperty('moduleAliasName', true, true, new Classname('\Core\Module\Name'));
	}
	
	/**
	* Startet eine Instanz der Modul-Klasse und schaut, was geladen werden muss.
	*
	* @param bool $showErrorModule - Soll bei einem nicht vorhandenen Modul statt eine Exception das 404-Module geöffnet werden? [optional]
	* @param array $alwaysAllowed - Module, die in jeder Situation angefordert werden dürfen. Das Error- und das Install-Modul sind immer dabei.
	**/
	public function __construct($showErrorModule = true, array $alwaysAllowed = []) {
		parent::__construct();
			
		// Standard-Template-Set aktivieren
		$this->setTemplateSet('main');
	
		// Welches Modul wurde angefordert?
		$moduleNameString = isset($_GET[self::GET_NAME]) ? $_GET[self::GET_NAME] : self::START_MODULE;
		// Nicht installiert?
		if(!\Config\INSTALLED && strpos($moduleNameString, 'Install') === false && !in_array($moduleNameString, $alwaysAllowed))
			$moduleNameString = self::INSTALL_MODULE;
		
		do {
			// Ein Objekt drausmachen
			$this->moduleName = new Module\Name($moduleNameString);
			
			// Das Module existiert nicht?
			if(!$this->existModule()) {
				// Das Error-Module soll angezeigt werden und wir sind nicht bereits so weit?
				if($showErrorModule && $this->moduleName != self::ERROR_MODULE)
					$moduleNameString = self::ERROR_MODULE;
				else // Das Error-Module existiert nicht oder es soll direkt eine Exception geworfen werden?
					throw new \Exception('Das angeforderte Modul „'.$this->moduleName.'“ existiert nicht.', 1010);
			}
		} while(!$this->existModule()); // Das Module existiert nicht? Dann mach das da oben nochmal!
		
		// Alias ist das selbe Skript
		$this->moduleAliasName = $this->moduleName;
	}
	
	/**
	* Öffnet das Modul. (Lädt alle Klassen und stellt die Templates da.)
	**/
	public function open() {
		// Alle System-Variablen setzen
		$this->setSystemCacheVars();
		
		// Alle Klassen laden
		$this->loadAllClasses();
		// Alle Templates darstellen
		$this->showAllTemplates();
	}
	
	/**
	* Gibt zurück, ob es sich um ein Kind des oder um das angegebene Modul selbst handelt.
	*
	* @param string $module - Modul
	* @return bool
	**/
	public function kindOf($module) {
		return strpos((string)$this->moduleName, $module) === 0;
	}
	
	/**
	* Exisitert das angeforderte Modul überhaupt?
	*
	* @return bool
	**/
	protected function existModule() {
		// Pfad zur Hauptdatei basteln
		$moduleClassFile = ROOT_PATH.self::MODULE_DIR.$this->moduleName->getPathToFile();
		// Existiert diese Datei?
		return file_exists($moduleClassFile);
	}
	
	/**
	* Setzt das Template-Set. Standard-Set ist "main".
	* 
	* @param String $name - Name des Template-Set
	**/
	public function setTemplateSet($name) {
		if (!(file_exists(ROOT_PATH.self::SET_DIR.$name.'Head.tpl.php') && file_exists(ROOT_PATH.self::SET_DIR.$name.'Foot.tpl.php')))
			throw new \Exception('Das angeforderte Template-Set „'.$name.'“ existiert nicht oder nicht vollständig.', 1012);
			
		$this->templateSet = $name;
	}
	
	/**
	* Setzt die System-CacheVars.
	**/
	protected function setSystemCacheVars() {
		// Den aktuellen Modul-Namen setzen
		$this->addVarCache('currentModule',$this->moduleName);
		
		// Die mitgesendeten Optionen setzen
		$this->addVarCache('options',function() {
			return $this->getOptions();
		}, true);
	}
	
	/**
	* Gibt die gesetzten Optionen zurück.
	*
	* @return array
	**/
	public function getOptions() {
		return isset($_GET[self::GET_OPTIONS]) ? $_GET[self::GET_OPTIONS] : [];
	}
	
	/**
	* Gibt zurück, welche Haupt-Elemnte vorhanden sind
	*
	* @param string $type - Welcher Typ?
	* @return array
	**/
	protected function getMainArray($type) {
		// Den aktuellen Namen
		$moduleName = $this->moduleName;
		// Main-Class sammeln
		$mainElements = [];
		
		do {
			// Den Pfad zur Haupt-Klasse bilden
			$mainPath = self::MODULE_DIR.$moduleName->getPathToFile($type,true);
			// Die Klasse existiert nicht? Weiter!
			if(!file_exists(ROOT_PATH.$mainPath)) continue;
			
			// Dem Array hinzufügen
			$mainElements[] = $moduleName;
		// Den Block so lange wiederholen, bis wir am Ende angekommen sind
		} while($moduleName = $moduleName->getParentSegmentsAsObject());
		
		// Das Array umsortieren
		krsort($mainElements);
		
		return $mainElements;
	}
	
	/**
	* Lädt alle Modul-Klassen
	**/
	protected function loadAllClasses() {
		// Hier noch Haupt-Klassen einfügen
		$this->loadMainClasses();
	
		do {
			$moduleName = $this->moduleAliasName;
			// Pfad zur Klassen-Datei basteln
			$moduleClassFile = self::MODULE_DIR.$this->moduleAliasName->getPathToFile();
			// Sie einbinden
			new Module\Script($moduleClassFile);
		} while($moduleName != $this->moduleAliasName);
	}
	
	/**
	* Lädt die Hauptklassen.
	**/
	protected function loadMainClasses() {
		$mainClasses = $this->getMainArray('script');
		
		// Das Array durchgehen
		foreach($mainClasses as $currentName) {
			// Pfad zum Template
			$scriptPath = self::MODULE_DIR.$currentName->getPathToFile('script',true);
			
			// Template einbinden
			new Module\Script($scriptPath);
		}
	}
	
	/**
	* Stellt alle Templates da
	**/
	protected function showAllTemplates() {
		// Den Pfad zu dem Template basteln
		$moduleTemplateFile = self::MODULE_DIR.$this->moduleAliasName->getPathToFile('template');
		// Wenn diese Datei nicht existiert, dann hat das Module keine Templates
		if(!file_exists(ROOT_PATH.$moduleTemplateFile)) return;
	
		// Der Pfad zu dem Template-Set basteln
		$templateSetPath = self::SET_DIR.$this->templateSet;
		
		// Den Header einbinden
		new Module\Template($templateSetPath.'Head.tpl.php');
		
		// Haupt-Templates hier einfügen
		$this->showMainTemplates();
		
		// Das Modul-Template einfügen
		new Module\Template($moduleTemplateFile);
		
		// Den Footer einbinden
		new Module\Template($templateSetPath.'Foot.tpl.php');		
	}
	
	/**
	* Lädt die Hauptklassen.
	**/
	protected function showMainTemplates() {
		$mainTemplates = $this->getMainArray('template');
		
		// Das Array durchgehen
		foreach($mainTemplates as $currentName) {
			// Pfad zum Template
			$templatePath = self::MODULE_DIR.$currentName->getPathToFile('template',true);
			
			// Template einbinden
			new Module\Template($templatePath);
		}
	}
	
	/**
	* Fügt ein Template ein.
	*
	* @param string $templateName - Name des Templates
	* @param array $vars - Variablen [optional]
	**/
	public function includeTemplate($templateName, array $vars = []) {
		// Pfad fertig basteln
		$templatePath = self::INC_DIR.$templateName.'.tpl.php';
	
		// Template einfügen
		new Module\Template($templatePath, $vars);
	}
	
	/**
	* Gibt den Inhalt eines Templates zurück.
	*
	* @param string $templateName - Name des Templates
	* @param array $vars - Variablen [optional]
	**/
	public function getTemplateContent($templateName, array $vars = []) {
		ob_start();
		$this->includeTemplate($templateName, $vars);
		
		// Inhalt bekommen
		$content = ob_get_clean();
		
		// Inhalt vereinfachen
		$content = trim($content);
		$content = str_replace("\n", ' ', $content);
		
		// Output-Buffer zurückgeben
		return $content;
	}
	
	   /**
	* Gibt die User-Eingaben zurück.
	*
	* @param string $name - Name des Elements
	* @param mixed $default - Standard, falls nichts gesetzt ist. [optional]
	* @param bool $withOptions - Auch die GET-Options durchsuchen? [optional]
	* @param callable $callback - Rückruf [optional]
	* @return mixed
	**/
	public function getUserInput($name, $default = '', $withOptions = false, callable $callback = NULL) {
		// Optionen lesen
		$options = $this->getOptions();
		
		// Überprüft die Options
		$return = isset($options[$name]) && $withOptions ? $options[$name] : $default;
		// POST überprüfen
		$return = isset($_POST[$name]) ? $_POST[$name] : $return;
		
		// Trimmen, wenn String
		if(is_string($return)) $return = trim($return);
		
		// Callback fehlerhaft?
		if(!is_null($callback) && !call_user_func($callback, $return)) return $default;
		
		return $return;
	}
	
	/**
	* Leitet zu einem Modul um
	*
	* @param String $moduleName - Der Name das zu verlinkenden Moduls [optional] NULL = Startseite
	* @param Array $options - Die mitgelieferten Optionen [optional]
	* @param string $anchor - HTML-Anker [optional]
	**/
	public static function goToModule($moduleName = NULL, array $options = [], $anchor = NULL) {
		// Wenn der Modul-Name == NULL ist, dann zur Startseite weiterleiten
		if(is_null($moduleName)) $moduleName = self::START_MODULE;
	
		i::Header()->addLocation(self::createModuleLink($moduleName, $options, $anchor, false));
	}
	
	
	/**
	* Erzeugt einen Link zu einem Modul.
	*
	* @param String $moduleName - Der Name das zu verlinkenden Moduls [optional] NULL = Aktuelle Seite
	* @param Array $options - Die mitgelieferten Optionen [optional]
	* @param string $anchor - HTML-Anker [optional]
	* @param bool $encodeEntities - Später als in HTML? [optional]
	* @return String - Der Link zu dem Modul
	**/
	public static function createModuleLink($moduleName = NULL, array $options = [], $anchor = NULL, $encodeEntities = true) {
		// Wenn der angeforderte Name NULL ist, auf das eigene Verweisen
		if(is_null($moduleName)) $moduleName = i::Module()->moduleName;
	
		// Der Modul-Name die URL einfügen
		$url = 'index.php?'.self::GET_NAME.'='.$moduleName;
		
		// Die gewünschten Optionen mitschicken
		$url .= self::getMoreParamsForLink('&'.self::GET_OPTIONS,$options);
		
		// Noch ein Anker?
		$url .= ($anchor!=NULL ? '#'.$anchor : '');
		// Sollen die Entities noch maskiert werden?
		if($encodeEntities) $url = htmlentities($url);
		
		// Ergebnis zurückgeben
		return $url;
	}
	
	/**
	* Erzeugt einen Paramter-String für die Optionen
	*
	* @param string $keyString - Name der Option
	* @param string/array $value - Option
	* @return string
	**/
	protected static function getMoreParamsForLink($keyString, $value) {
		$string = '';
		if(is_array($value)) {
			foreach($value as $valueKey => $valueCurrent)
				$string .= self::getMoreParamsForLink($keyString.'['.Format::url($valueKey).']',$valueCurrent);
		} else
			$string .= $keyString.'='.Format::url($value);
		
		return $string;
	}
}
?>