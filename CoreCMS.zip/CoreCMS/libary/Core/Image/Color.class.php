<?php
/**
* Stellt eine Farbe für ein Bild dar.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-28
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Image;

class Color extends \Object {
	protected $resource;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('resource', true);
	}

	/**
	* Erstellt eine neue Farbe.
	*
	* @param \Core\Image $imageInstance - Instance der Image-Klasse.
	* @param int $red
	* @param int $green
	* @param int $blue
	**/
	public function __construct(\Core\Image $instance, $red, $green, $blue) {
		$this->resource = imagecolorallocate($instance->getResource(), $red, $green, $blue);
	}
}
?>