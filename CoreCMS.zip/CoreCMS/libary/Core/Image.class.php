<?php
/**
* Diese Klasse erstellt ein neues Bild mit der GDlib. Sehr kleiner Funktionsumfang.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-28
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Image extends \Object {
	protected $width, $height;
	protected $resource;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['resource', 'width', 'height'], true);
	}
	
	/**
	* Erstellt ein neues Bild.
	*
	* @param int $width - Breite
	* @param int $height - Höhe
	* @param resource $resource - GD-Resource [optional]
	**/
	public function __construct($width, $height, $resource = NULL) {
		$this->width = $width;
		$this->height = $height;
		
		// Genug Speicher vorhanden?
		if(!self::enoughMemory($width, $height))
			throw new \Exception('Zum Erstellen dieses Bildes steht PHP nicht mehr genug Arbeitsspeicher zur Verfügung.', 1262);
		
		$this->resource = $resource ?: imagecreatetruecolor($width, $height);
	}
	
	/**
	* Löscht das Bild.
	**/
	public function __destruct() {
		imagedestroy($this->resource);
	}
	
	/**
	* Erstellt eine neue Farbe
	*
	* @param int $red
	* @param int $green
	* @param int $blue
	* @return Image\Color
	**/
	public function createColor($red, $green, $blue) {
		return new Image\Color($this, $red, $green, $blue);
	}
	
	/**
	* Erstellt ein mit einer Farbe gefülltes Rechteck.
	*
	* @param int $x1
	* @param int $y1
	* @param int $x2
	* @param int $y2
	* @param Image\Color $color - Farbe
	**/
	public function fillRectangle($x1, $y1, $x2, $y2, Image\Color $color) {
		imagefilledrectangle($this->resource, $x1, $y1, $x2, $y2, $color->getResource());
	}
	
	/**
	* Setzt die Hintergrundfarbe des Bildes.
	*
	* @param Image\Color $color
	**/
	public function setBackgroundColor(Image\Color $color) {
		$this->fillRectangle(0, 0, $this->width, $this->height, $color);
	}
	
	/**
	* Schreibt einen Text auf das Bild.
	*
	* @param int $x
	* @param int $y
	* @param int $angle - Grad
	* @param Image\Color $color - Schriftfarbe
	* @param int $size - Schriftgröße
	* @param string $font - Pfad zur Schriftart
	* @param string $text - Text der dargestellt werden soll.
	**/
	public function writeText($x, $y, $angle, Image\Color $color, $size, $font, $text) {
		imagettftext($this->resource, $size, $angle, $x, $y, $color->getResource(), $font, $text);
	}
	
	/**
	* Gibt eine neue Instanz von dem Bild, mit veränderter Größe, zurück.
	*
	* @param int $width [optional]
	* @param int $height [optional]
	* @return self
	**/
	public function resize($width = false, $height = false) {
		if(!$width && !$height)
			throw new \Exception('Zur Größenveränderung muss Breite, Höhe oder beides angegeben werden.', 1261);
		
		// Wenn die Breite nicht angegeben wurde aus
		$newWidth = $width ?: (int) $this->width * ($height / $this->height);
		// Wenn die Höhe nicht angegeben wurden
		$newHeight = $height ?: (int) $this->height * ($width / $this->width);
		
		// Neues Bild erstellen
		$newImage = new self($newWidth, $newHeight);
		// Das veränderte Bild dort anhängen
		imagecopyresampled($newImage->getResource(), $this->resource, 0, 0, 0, 0, $newWidth, $newHeight, $this->width, $this->height);
		
		// Das Bild zurückgeben
		return $newImage;
	}
	
	/**
	* Malt das Bild und beendet das Programm,
	**/
	public function draw() {
		// Setzt den Content-Type
		i::Header()->setContentType('image/png');
		
		// Bild darstellen
		imagepng($this->resource);
		// Weiteren Programmablauf abbrechen
		exit;
	}
	
	/**
	* Schreibt das Bild in eine Datei. (Immer als PNG.)
	*
	* @param string $name - Dateiname
	**/
	public function drawInFile($name) {
		// In Datei schreiben
		imagepng($this->resource, $name);
	}
	
	/**
	* Erstellt eine Instanz dieser Klasse aus einem bereits vorhanden Bild.
	*
	* @param IO\File $image - Bilddatei
	* @return self
	**/
	public static function fromFile(IO\File $image) {	
		// Dateiendung bekommen
		$subfix = $image->getSuffix();
		// jpg durch jpeg erstetzen
		$subfix = str_replace('jpg', 'jpeg', $subfix);
		
		// Funktionsnamen bauen
		$functioname = 'imagecreatefrom'.$subfix;
		// Existiert eine passende Funktion?
		if(!function_exists($functioname))
			throw new \Exception('Dieser Bildtyp kann nicht in die GDLib eingehängt werden.', 1260);
			
		// Breite und Höhe laden
		list($width, $height) = $image->getImageSize();
		// Genug Speicher vorhanden?
		if(!self::enoughMemory($width, $height))
			throw new \Exception('Zum Laden dieses Bildes steht PHP nicht mehr genug Arbeitsspeicher zur Verfügung.', 1262);
		
		// Resource erstellen
		$resource = $functioname($image->getPath());
		// Neue Instanz zurückgeben
		return new self($width, $height, $resource);
	}
	
	/**
	* Berechnet, ob der aktuelle Rest-Arbeitsspeicher zum ladend des Bildes reicht.
	*
	* @param $width - Breite des Bildes.
	* @param $height - Höhe des Bildes.
	* @return bool
	**/
	public static function enoughMemory($width, $height) {
		// Aktuellen Arbeitsspeicherverbrauch bekommen
		$memoryUsage = memory_get_usage();
		// Arbeitsspeicher-Limit
		$memoryLimit = calcBytes(ini_get('memory_limit'));
		
		// Berechnen, wie viel das Bild benötitgt.
		$expectedUsage = $width * $height * 4.95;
		
		return $memoryUsage + $expectedUsage < $memoryLimit;
	}
}
?>