<?php
/**
* Die Klasse gibt die Main-Instanzen und ID-Instanzen der angeforderten Klasse zurück.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-02
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class MainInstance extends \Object {
	const CLASS_NAME = 'Core\Singleton';
	const ALIAS_NAME = 'i';
	
	private static $classCache = [];
	
	/**
	* Rückfrage-Funktion für die Autoload-Klasse
	*
	* @param Classname - Angforderter Klassennamen
	**/
	public static function callback(Classname $classname) {
		// Wenn Klassennamen nicht i ist, abbrechen
		if($classname->getClassname() != self::ALIAS_NAME) return;
	
		// Alias erstellen
		Alias::forClass(new Classname('\Core\MainInstance'), $classname);
	}

	/**
	* Alle Klassenmethoden-Aufrufe stellen eine Klasse da, von der wir die Haupt-Instanz mäöchten
	*
	* @param string $name - Klassen-Name, von der wir die Haupt-Instanze möchten.
	* @param array $args - Uninteressant.
	**/
	public static function ___callStatic($name, array $args) {
		// Den Klassennamen bilden, dafür brauchen wir unser eigenen Namespace
		$ownClassname = new Classname(get_called_class());
		$ownNamespace = $ownClassname->getNamespaceAsString();
		
		// Eigenen Namespace mit angefordertem Klassennamen kombinieren
		$classname = $ownNamespace.'\\'.$name;
	
		if(!class_exists($classname)) throw new \Exception('Die angeforderte Klasse „'.$classname.'“ existiert nicht.', 1020);
		
		// Nur überprüfen, wenn noch nicht überprüft.
		if(!isset(self::$classCache[$classname]))	{
			// Überprüfen ob Singleton-Klasse
			$reflection = new \ReflectionClass($classname);
			if(!$reflection->isSubclassOf(self::CLASS_NAME))
				throw new \Exception('Die angeforderte Klasse „'.$classname.'“ ist keine Tochter der '.self::CLASS_NAME.'-Klasse.', 1021);
			
			// Als überprüft markieren
			self::$classCache[$classname] = true;
		}
		
		// Eine ID angefordert?
		if(count($args)) return $classname::instanceFor($args[0]);
		
		// Main-Instanz zurückgeben.
		return $classname::mainInstance();
	}
}
?>