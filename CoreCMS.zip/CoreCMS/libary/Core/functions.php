<?php
/**
* Zusätzliche Sammlung an Funktionen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-06-27
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

/**
* Addiert den Wert eines Key in verschiedenen Arrays miteinander
*
* @param array $arrays - Beliebig viele Array
* @return array - Addiertes Array
**/
function addArrayContent(array $arrays) {
	$addArray = [];
	foreach($arrays as $currentArray) {
		foreach($currentArray as $key=>$content) {
			if(!isset($addArray[$key])) $addArray[$key] = 0;
			$addArray[$key] += $content;
		}
	}
	
	return $addArray;
}

/**
* Subtrahiert den Wert eines Key in verschiedenen Arrays miteinander
*
* @param array $startArray - Startwerte
* @param array $arrays - Beliebig viele Array
* @return array - Addiertes Array
**/
function subArrayContent(array $startArray, array $arrays) {
	foreach($arrays as $currentArray) {
		foreach($currentArray as $key=>$content) {
			if(!isset($startArray[$key])) $startArray[$key] = 0;
			$startArray[$key] -= $content;
		}
	}
	
	return $startArray;
}

/**
* Macht aus einem php.ini-Wert eine Byte-Zahl
*
* @param string $sizeString - Ein Größen-String
* @return int - Eine Größe in Byte
**/
function calcBytes($sizeString) {
	$sizeString = trim($sizeString);
	$last = strtolower($sizeString[strlen($sizeString)-1]);
	switch($last) {
		case 'g':
			$sizeString *= 1024;
		case 'm':
			$sizeString *= 1024;
		case 'k':
			$sizeString *= 1024;
	}

	return $sizeString;
}
?>