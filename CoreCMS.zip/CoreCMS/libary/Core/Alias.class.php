<?php
/**
* Alias für Sprachkonstrukte erstellen
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-20
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Alias extends \Object {
	protected static $aliasCallback = [];

	/**
	* Macht einen Alias für eine Klasse. Unterschied zu class_alias(): Er lässt sich nachvollziehen
	*
	* @param Classname $original - Eigentlicher Klassenname
	* @param Classname $alias - Alias
	**/
	public static function forClass(Classname $original, Classname $alias) {
		if(class_exists($alias->getFullClassname(), false))
			throw new \Exception('Es gibt bereits eine Klasse mit dem Namen „'.$alias->getFullClassname().'“.', 1110);
		
		
		$script = 'namespace '.$alias->getNamespaceAsString().'; class '.$alias->getClassname().' extends '.$original->getFullClassname().' {}';
		self::runScript($script);
	}
	
	/**
	* Macht einen Alias für eine Funktion
	*
	* @param callable $original - Eigentlicher Funktionsname
	* @param string $alias - Alias
	**/
	public static function forFunction(callable $original, $alias) {
		if(function_exists($alias)) throw new Exception('Es gibt bereits eine Funktion mit dem Namen „'.$alias.'“.', 1111);
		
		// Callback speichern
		self::$aliasCallback[$alias] = $original;
	
		$script = 'function '.$alias.'() { return call_user_func_array(\Core\Alias::getCallbackForAlias(\''.$alias.'\'), func_get_args()); }';
		self::runScript($script);
	}
	
	/**
	* Schreibt den Code in die tmp-Datei und führt ihn aus.
	*	Wieso kein eval()? Fehlerbehandlung!
	*
	* @param string $script - Der Code
	**/
	private static function runScript($script) {
		// Ausgaben abfgangen
		ob_start();
		// Skript ausführen
		$result = eval($script);
		// Ausgaben entgegennehmen
		$string = ob_get_clean();
		
		// Muss eine Exception geworfen werden?
		if($result === false || !empty($string)) {
			// Fehler Infos parsen
			$matches = [];
			preg_match("/^\s*Parse error\s*:(.+) in (.+) on line (\d+)\s*$/m", strip_tags($string), $matches);
			
			// Exception werfen
			throw new \AdvancedErrorException($matches[1], 0, E_PARSE, $matches[2], $matches[3]);
		}
	}
	
	/**
	* Gibt den Callback für eine Funktion zurück
	*
	* @param string $alias - Name der Funktione
	* @return callable
	**/
	public static function getCallbackForAlias($alias) {
		return self::$aliasCallback[$alias];
	}
} 	
?>