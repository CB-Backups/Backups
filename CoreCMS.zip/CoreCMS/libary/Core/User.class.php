<?php
/**
* Die Klasse verwaltet den Benutzer, lässt eine Registrierung und eine Löschung eines Users zu.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-06-27
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class User extends Singleton {
	use Singleton\Vars;

	const TABLE_NAME = 'user';
	
	const PASS_SALT = 'CORE';

	const PASS_MIN_LENGTH = 6;
	const MAIL_MATCH = '/^[a-zA-Z0-9-_.]+@[a-zA-Z0-9-_.]+\.[a-zA-Z]{2,4}$/';
	const NAME_MIN_LENGTH = 4;
	const NAME_MAX_LENGTH = 15;
	const NAME_MATCH = '/^[a-zA-Z0-9-_.]+$/';
		
	protected $dataArray, $saveInDB = [];
	protected $userID, $userName, $userPass, $userMail, $notifications = [], $lastLogin, $locked;
	protected $deleted = false;
	
	protected $tableActions;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['userID', 'userName', 'userPass', 'userMail', 'lastLogin', 'locked'], true);
	}
	
	/**
	* Öffnet eine neue User-Klasse mithilfe der userID.
	*
	* @param int $userID - User-ID
	**/
	public function __construct($userID) {
		$this->tableActions = i::MySQL()->tableActions(static::TABLE_NAME);
		$queryObject = $this->tableActions->select(['id'=>(int)$userID]);
		
		// Der User existiert gar nicht?
		if(count($queryObject) != 1)
			throw new \Exception('Ein User mit dieser ID existiert nicht.', 1031);			
		
		$this->dataArray = $queryObject[0];
		$this->userID = $this->dataArray['id'];
		$this->userName = $this->dataArray['name'];
		$this->userPass = $this->dataArray['pass'];
		$this->userMail = $this->dataArray['mail'];
		$this->lastLogin = $this->dataArray['lastLogin'];
		$this->locked = (bool) $this->dataArray['locked'];
		
		$this->notifications = unserialize($this->dataArray['notifications']);
		if(!is_array($this->notifications)) $this->notifications = [];
	}
	
	/**
	* Schließt die User-Klasse und speichert alle geänderte Werte in die Datenbank
	**/
	public function __destruct() {
		// Nur speichern, wenn der Benutzer nicht gelöscht ist.
		if(!$this->deleted) {
			// Welche Daten sollen gespeichert werden?
			$this->saveInDB['name'] = $this->userName;
			$this->saveInDB['pass'] = $this->userPass;
			$this->saveInDB['mail'] = $this->userMail;
			$this->saveInDB['lastLogin'] = $this->lastLogin;
			$this->saveInDB['notifications'] = serialize($this->notifications);
			$this->saveInDB['locked'] = $this->locked;
		
			// Daten speichern
			$this->tableActions->update($this->saveInDB,['id'=>$this->userID]);
		
			// Instanz für diese User-ID löschen
			static::unsetInstanceFor($this->userID);
		}
	}
	
	/**
	* Überprüft neue Usernamen und gibt eventuelle Fehler zurück.
	* 
	* @param string $firstPass - Passwort
	**/
	protected static function validateUserName($userName) {
		if (strlen($userName) < static::NAME_MIN_LENGTH)
			throw new \HumanException('Der ausgesuchte Benutzername ist zu kurz. Er muss mindestens '.Format::number(static::NAME_MIN_LENGTH).' Zeichen haben.', -1);
		if (strlen($userName) > static::NAME_MAX_LENGTH)
			throw new \HumanException('Der ausgesuchte Benutzername ist zu lang. Er darf maximal '.Format::number(static::NAME_MAX_LENGTH).' Zeichen haben.', -2);
		if (!preg_match(static::NAME_MATCH, $userName))
			throw new \HumanException('Der ausgesuchte Benutzername enthält Leerzeichen oder andere Sonderzeichen.', -3);
		if (static::existUserName($userName))
			throw new \HumanException('Der ausgesuchte Benutzername wird bereits von einem anderen Benutzer genutzt.', -4);
	}
	
	/**
	* Ändert den User-Namen
	*
	* @param string $name - Die E-Mail-Adresse
	**/
	public function setUserName($userName) {
		if($userName == $this->userName)
			throw new \HumanException('Das ist bereits dein aktueller Benutzername.', -1);
	
		static::validateUserName($userName);
	
		$this->userName = $userName;
	}
	
	/**
	* Überprüft neue Passwörter und gibt eventuelle Fehler zurück.
	* 
	* @param string $firstPass - Passwort
	* @param string $secondPass - Passwort-Wiederholung
	**/
	protected static function validateUserPass($firstPass, $secondPass) {
		if (strlen($firstPass) < static::PASS_MIN_LENGTH)
			throw new \HumanException('Das eingegebene Passwort ist zu kurz. Es muss mindestens '.Format::number(static::PASS_MIN_LENGTH).' Zeichen haben.', -1);
		if ($firstPass != $secondPass)
			throw new \HumanException('Die zwei eingegebenen Passwörter stimmen nicht überein.', -2);
	}
	
	/**
	* Hast das Passwort für die User
	*
	* @param $pass - Das zu hashende Passwort
	* @return String - Das gehaste Passwort
	**/
	protected static function hashUserPass($pass) {
		return sha1($pass.static::PASS_SALT);
	}
	
	/**
	* Hasht und setzt das User-Passwort
	*
	* @param String $firstPass - Passwort
	* @param String $secondPass - Passwort-Wiederholung
	**/
	public function setUserPass($firstPass, $secondPass) {
		$passHash = static::hashUserPass($firstPass);
		
		if($passHash == $this->userPass)
			throw new \HumanException('Das ist bereits dein aktuelles Passwort.', -1);
			
		static::validateUserPass($firstPass, $secondPass);
		
		$this->userPass = $passHash;
	}
	
	/**
	* Überprüft die E-Mail und gibt eventuelle Fehler zurück.
	*
	* @param String $mail - Die E-Mail-Adresse
	**/
	protected static function validateUserMail($mail) {
		if (!preg_match(static::MAIL_MATCH, $mail))
			throw new \HumanException('Die eingegebene E-Mail-Adresse ist keine gültige E-Mail-Adresse.', -1);
		if (static::existUserMail($mail))
			throw new \HumanException('Die ausgesuchte E-Mail-Adresse wird bereites von einem anderen Benutzer benutzt.', -2);
	}
	
	/**
	* Ändert die User-Mail
	*
	* @param string $mail - Die E-Mail-Adresse
	**/
	public function setUserMail($mail) {
		if($userName == $this->userName)
			throw new \HumanException('Das ist bereits deine aktuelle E-Mail-Adresse.', -1);
			
		static::validateUserMail($mail);
	
		$this->userMail = $mail;
	}
	
	/**
	* Fügt eine neue Notification dem User hinzu
	*
	* @param Notification $notification - Eine neue Notification
	**/
	public function addNotification(Notification $notification) {
		$this->notifications[] = $notification;
	}
	
	/**
	* Löscht eine Notification.
	*
	* @param int $notificationID - Die ID
	**/
	public function removeNotification($notificationID) {
		unset($this->notifications[$notificationID]);
	}
	
	/**
	* Löscht alle Notifications
	**/
	public function removeAllNotifications() {
		$this->notifications = [];
	}
	
	/**
	* Gibt die Benachrichtigungen des Users zurück
	*
	* @return array[Notification] - Array mit Benachrichitungen
	**/
	public function listNotifications() {
		return $this->notifications;
	}
	
	/**
	* Gibt zurück, ob dieser User der Debug-User ist.
	*
	* @return bool
	**/
	public function isDebugUser() {
		return $this->userID == \Config\DEBUG_USER;
	}
	
	/**
	* Setzt den Benutzer als eingelogt.
	**/
	public function setLastLogin() {
		$this->lastLogin = time();
	}
	
	/**
	* Sperrt den Benutzer
	**/
	public function lock() {
		if($this->isDebugUser())
			throw new \HumanException('Der Debug-/Hauptuser kann nicht gesperrt oder gelöscht werden.', -1);
	
		$this->locked = true;
	}
	
	/**
	* Entsperrt den Benutzer
	**/
	public function unlock() {
		$this->locked = false;
	}
	
	/**
	* Löscht den Benutzer aus der Datenbank. (Endgültig.)
	**/
	public function delete() {
		if($this->isDebugUser())
			throw new \HumanException('Der Debug-/Hauptuser kann nicht gesperrt oder gelöscht werden.', -1);
	
		// User aus der DB löschen
		$this->tableActions->delete(['id'=>$this->userID]);
	
		// User als gelöscht markieren
		$this->deleted = true;
		// Instanz für diese User-ID löschen
		static::unsetInstanceFor($this->userID);
	}
	
	/**
	* Erstellt einen neuen Nutzer
	*
	* @param String $name - Der Nutzer-Name des Nutzers
	* @param String $firstPass - Passwort
	* @param String $secondPass - Passwort-Wiederholung
	* @param String $mail - Die Mail des Nutzers
	* @param array $moreInformations - Mehr Dinge, die geschrieben werden müssen.
	* @return User - Die User-Klasse des neuen Nutzers
	**/
	public static function createNewUser($name, $firstPass, $secondPass, $mail, array $moreInformations = []) {
		// Mitgegebne Daten bestätigen
		static::validateUserName($name);
		static::validateUserPass($firstPass,$secondPass);
		static::validateUserMail($mail);
	
		$passHash = static::hashUserPass($firstPass);
		
		$contentArray = ['name'=>$name,'pass'=>$passHash,'mail'=>$mail] + $moreInformations;
		$queryObject = i::MySQL()->tableActions(static::TABLE_NAME)->insert($contentArray);
		
		return static::instanceFor($queryObject->getLastID());
	}
	
	/**
	* Überprüft, ob ein Benutzername existiert
	*
	* @param String $userName - Der zu überprüfende Benutzername
	* @return bool - true = ja / false = nein
	**/
	public static function existUserName($userName) {
		$count = i::MySQL()->tableActions(static::TABLE_NAME)->count(['name'=>$userName]);
		
		return (bool) $count;
	}
	
	/**
	* Überprüft, ob eine E-Mail registriert ist.
	*
	* @param String $userName - Die zu überprüfende Mail
	* @return bool - true = ja / false = nein
	**/
	public static function existUserMail($userMail) {
		$count = i::MySQL()->tableActions(static::TABLE_NAME)->count(['mail'=>$userMail]);
		
		return (bool) $count;
	}
	
	/**
	* Logt einen Benutzer ein, gibt entweder eine gültige User-Klassen-Instanz zurück oder ein false.
	*
	* @param String $userName - Name des Nutzers
	* @param String $userPass - Passwort des Nutzers
	* @param bool $noHash - Nicht hashen, da bereit gehasht. [optional]
	* @param bool $noLogin - Kein wirklich Login? (Login-Zeit wird nicht aktuallisiert.) [optional]
	* @return User - Entweder eine gültige User-Instanz
	**/
	public static function loginUser($userName, $userPass, $noHash = false, $noLogin = false) {
		// Muss das Passwort noch gehasht werden?
		$userPass = $noHash ? $userPass : static::hashUserPass($userPass);
		// Query bilden
		$queryObject = i::MySQL()->tableActions(static::TABLE_NAME)->select([['name'=>$userName,'mail'=>$userName],'pass'=>$userPass]);
		
		// Benutzer nicht gefunden?
		if (!count($queryObject))
			throw new \HumanException('Der Login ist fehlgeschlagen. Überprüfe auch Groß- und Kleinschreibung des Passworts.', -1);		

		// User-Objekt laden
		$userObject = static::instanceFor($queryObject[0]['id']);
		
		// Darf sich der Benutzer einloggen?
		if($userObject->isLocked())
			throw new \HumanException('Dieser Benutzer ist gesperrt und kann sich deswegen nicht einloggen.');
		
		// Login festhalten
		if(!$noLogin) $userObject->setLastLogin();
		return $userObject;
	}
	
	/**
	* Diese Methode gibt zurück, wie viele Spieler derzeit registriert sind.
	*
	* @return int - Die Anzahl der Spieler
	**/
	public static function countUser() {
		$count = i::MySQL()->tableActions(static::TABLE_NAME)->count();
		return $count;
	}
	
	/**
	* Gibt alle Benutzer, die registriert sind, zurück.
	*
	* @return array[User]
	**/
	public static function listAllUser() {
		// Query laden
		$queryObject = i::MySQL()->tableActions(static::TABLE_NAME)->select();
		// Benutzer-Array
		$user = [];
		// Instanzen sammeln
		foreach($queryObject as $currentElement)
			$user[$currentElement['id']] = static::instanceFor($currentElement['id']);
			
		return $user;
	}
}
?>