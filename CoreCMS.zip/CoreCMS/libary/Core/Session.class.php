<?php
/**
* Stellt eine Sitzung da eines Users da.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-07-03
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Session extends \Object {
	use VarCache;
	
	const ACTION_TIME = 240;
	const MAX_ACTIONS = 5;

	protected $userInstance, $userClassname;
	protected $userName, $userPass;
	protected $lastAction, $IPAddress;
	protected $actions = [], $toManyActions = false;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('userInstance', true);
	}
	
	/**
	* Öffnet eine neue User-Session-Instance
	*
	* @param User $userInstance - Die Instance des Users
	**/
	public function __construct(User $userInstance) {
		$this->userInstance = $userInstance;
		$this->userClassname = Classname::forObject($userInstance);
		
		$this->userName = $this->userInstance->getUserName();
		$this->userPass = $this->userInstance->getUserPass();
		
		// Sicherheitsrelevante Daten speichern
		$this->lastAction = time();
		$this->IPAddress = $_SERVER['REMOTE_ADDR'];
	}
	
	/**
	* Bitte keine User-Instanz mit speichern, sonst werden Änderungen einfach nicht übernommen. :(
	*
	* @return array
	**/
	public function __sleep() {
		return ['userName','userPass','userClassname','varCache','isFunction','lastAction','IPAddress', 'actions', 'toManyActions'];
	}
	
	/**
	* Holt das User-Objekt wieder zurück.
	**/
	public function __wakeup() {
		// User-Klasse herausfinden
		$className = (string) $this->userClassname;
		// „Login“ durchführen um die User-Instanz zu laden
		$this->userInstance = $className::loginUser($this->userName, $this->userPass, true, true);
	}
	
	/**
	* Überprüft, ob die Session valid ist.
	*
	* @return bool
	**/
	public function isValid() {	
		// Aktivität überprüfen
		if($this->lastAction + Session\Manager::LIFETIME*60 < time())
			throw new \Exception('Die Session war zu lange inaktiv, Session muss beendet werden.', 1170);
		$this->lastAction = time();

		// IP-Adresse überprüfen
		if($this->IPAddress != $_SERVER['REMOTE_ADDR'])
			throw new \Exception('Die IP-Adresse hat sich geändert, Session muss beendet werden.', 1171);
			
		// User-Objekt valid?
		if(!is_object($this->userInstance))
			throw new \Exception('Der Session liegt kein gültiges User-Objekt bei.', 1172);
					
		return true;
	}
	
	/**
	* Ändert das Passwort des in der Session gespeicherten User OHNE in danach rauszuwerfen.
	*
	* @param String $firstPass - Passwort
	* @param String $secondPass - Passwort-Wiederholung
	**/
	public function changeUserPass($firstPass,$secondPass) {
		$this->userInstance->setUserPass($firstPass,$secondPass);
		$this->userPass = $this->userInstance->getUserPass();
	}
	
	/**
	* Setzt eine Aktion.
	**/
	public function setAction() {
		$this->actions[] = time();
	}
	
	/**
	* Löscht alle Aktionen
	**/
	public function clearActions() {
		$this->actions = [];
		$this->toManyActions = false;
	}
	
	/**
	* Überprüft die Aktionen
	*
	* @return bool - true = Zu viele Aktionen in zu kurzer Zeit.
	**/
	public function checkActions() {
		$validActions = [];
		// Alle Aktionen durchgehen, noch gültige mitnehmen
		foreach($this->actions as $currentAction) {
			if($currentAction < time() - self::ACTION_TIME) continue;
			
			$validActions[] = $currentAction;
		}
		
		$this->actions = $validActions;
		
		if(count($validActions) > self::MAX_ACTIONS || $this->toManyActions) {
			$this->toManyActions = true;
		
			return true;
		}
		
		return false;
	}
}
?>