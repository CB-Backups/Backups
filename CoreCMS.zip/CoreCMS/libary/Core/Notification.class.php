<?php
/**
* Eine Benachrichtigung für User.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-11-14
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Notification extends \Object {
	protected $title, $text, $time;
	protected $sended = false;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['title', 'text', 'time', 'sended'], true);
	}

	/**
	* Erstellt eine neue Notification.
	*
	* @param String $title - Betreff der Benachrichtigung
	* @param String $text - Text der Benachrichtigung
	* @param int $moneyAdd - Geld, dass dadurch hinzugekommen ist. [optional]
	* @param int $moneySub - Geld, dass dadurch verloren gegangen ist. [optional]
	**/
	public function __construct($title, $text) {
		$this->title = $title;
		$this->text = $text;
		$this->time = time();
	}
	
	/**
	* Setzt die Benachrichtigung als gesendet.
	**/
	public function setSended() {
		$this->sended = true;
	}
}
?>