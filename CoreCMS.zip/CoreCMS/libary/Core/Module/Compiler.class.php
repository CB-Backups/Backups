<?php
/**
* Diese Klasse ist das Grundgerüst einer Compiler-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-27
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Module;

abstract class Compiler extends \Object {
	protected $fileName;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('fileName', true);
	}
	
	/**
	* Nimmt den Namen der zu komplimierenden Datei entgegen und führt sie aus.
	*
	* @param string $fileName - Zum ROOT_PATH relativer Pfad zur Datei
	* @param array $vars - Variablen die dem Template mitgegeben werden sollen. [optional]
	**/
	public function __construct($fileName, array $vars = []) {
		// Name der Datei zwischen speichern
		$this->fileName = $fileName;
	
		// Muss eventuell das Cache-Verzeichnis erstellt werden?
		$this->createCacheDir();
		
		// Existiert die Datei überhaupt? Wenn nicht direkt eine Ausnahme werfen!
		if(!file_exists(ROOT_PATH.$this->getFileName()))
			throw new \Exception('Die angegebene Datei „'.$this->getFileName().'“ existiert nicht.', 1120);
			
		// Muss die Datei neu kompiliert werden? Wenn ja, dann mach das auch!
		if($this->needRecompile()) $this->recompile();
	}
	
	/**
	* Erstellt den benötigten Ordner, falls dieser nicht vorhanden ist.
	*
	* @return bool - Der Ordner musste erstellt werden?
	**/
	protected function createCacheDir() {
		// Der Ordner existiert bereits? Dann müssen wir ihn auch nicht erstellen.
		if(is_dir(ROOT_PATH.static::CACHE_DIR)) return false;
		
		try {
			// Ordner erstellen
			$dir = \Core\IO\Directory::create(ROOT_PATH.static::CACHE_DIR);
			// Infos reinschreiben
			$dir->writeInfo(['description' => 'Systemcache „'.get_called_class().'“']);
		} catch(\Exception $exception) {
			throw new \Exception('Das benötigte Cache-Verzeichnis für die Datei konnte nicht erstellt werden.', 1121, $exception);
		}
		
		return true;
	}
	
	/**
	* Gibt den simplen Cache-Namen zurück.
	*
	* @return string
	**/
	protected function getCacheName() {
		// . und / ersetzen durch _
		$name = str_replace('/', '_', $this->getFileName());
		$name = str_replace('.', '_', $name);
		
		return $name;
	}
	
	/**
	* Gibt den Pfad im Cache-Verzeichnis zurück.
	*
	* @return string
	**/
	protected function getCacheFileName() {
		// Verzeichnis davor setzen
		$cacheFile = static::CACHE_DIR;		
		// „/“ durch „_“ resetzen
		$cacheFile .= $this->getCacheName();
		// Endung hinzufügen
		$cacheFile .= '.cache.php';
	
		return $cacheFile;
	}
	
	/**
	* Gibt zurück, ob die Datei neu kompiliert werden muss.
	*
	* @return bool
	**/
	protected function needRecompile() {
		// Dateinamen ermitteln.
		$cacheFile = ROOT_PATH.$this->getCacheFileName();
		$currentFile = ROOT_PATH.$this->getFileName();
	
		// Wenn kein Cache-File existiert muss auf jeden Fall eine neuer gemacht werden.
		if(!file_exists($cacheFile)) return true;
		
		// Letzte Änderungszeiten der Dateien ermitteln
		$cacheFileTime = filemtime($cacheFile);
		$currentFileTime = filemtime($currentFile);
		
		// Die Cache-Datei ist älter als das Template? Neu kompilieren!
		if($currentFileTime > $cacheFileTime) return true;
		
		return false;
	}
	
	/**
	* Eigentliche Haupt-Methode dieser Klasse. Kompiliert das Template.
	**/
	abstract protected function recompile();
}
?>