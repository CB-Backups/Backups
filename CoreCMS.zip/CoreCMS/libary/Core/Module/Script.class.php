<?php
/**
* Diese Klasse macht aus Modul-Skripten Pseuydo-Klassen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-23
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Module;

class Script extends Compiler {
	const CACHE_DIR = 'cache/scripts/';
	const SCRIPT_NAMESPACE = 'Script';
	
	/**
	* Nimmt den Namen der Skript-Datei entgegen und führt sie aus.
	*
	* @param string $filename - Zum ROOT_PATH relativer Pfad zum Template-File
	* @param array $vars - Variablen die dem Template mitgegeben werden sollen. [optional]
	**/
	public function __construct($filename, array $vars = []) {
		parent::__construct($filename, $vars);
		
		// Die Datei einbinden
		require_once ROOT_PATH.$this->getCacheFileName();
		
		// Klassen-Namen ermitteln
		$classname = '\\'.self::SCRIPT_NAMESPACE.'\\'.$this->getCacheName();
		
		if(class_exists($classname,false)) new $classname();
	}
	
	/**
	* Eigentliche Haupt-Methode dieser Klasse. Kompiliert das Template.
	**/
	protected function recompile() {
		// Inhalt der Datei laden
		$scriptContent = file_get_contents(ROOT_PATH.$this->getFileName());
		
		// Variablen vordefinieren
		$count = 0;
		$patterns = [];
		$replacements = [];
		
		// „script
		$patterns[] = '/usescript ([a-zA-Z]+)(?=([^"\']*["\'][^"\']*["\'])*[^"\']*$)/';
		$replacements[] = '\Core\i::Module()->setModuleAliasName(new \Core\Module\Name(\'\1\'))';
		
		// „script“ ersetzen
		$patterns[] = '/script(?=([^"\']*["\'][^"\']*["\'])*[^"\']*$)/';
		$replacements[] = 'namespace '.self::SCRIPT_NAMESPACE.";\n\nclass ".$this->getCacheName().' extends \Core\Module\Extender ';
		
		$scriptContent = preg_replace($patterns,$replacements,$scriptContent, -1, $count);
		
		// Dieser Befehl darf genau einmal in der Datei vorkommen
		if($count != 1) throw new \Exception('Es muss genau ein „Script“-Block in jeder Modul-Skript-Datei vorkommen.', 1140);
			
		// Inhalt in die Cache-Datei schreiben
		file_put_contents(ROOT_PATH.$this->getCacheFileName(), $scriptContent);
	}
}
?>