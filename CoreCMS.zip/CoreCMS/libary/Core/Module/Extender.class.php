<?php
/**
* Diese Klasse ist das Grundgerüst einer jeder Skript-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-28
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Module;

abstract class Extender extends \Object {
	/**
	* Ein Constructor ist Pflicht!
	**/
	abstract public function __construct();
	
	/**
	* Gibt die Modul-Haupt-Instanz zurück.
	*
	* @return \Core\Module
	**/
	protected function mi()  {
		return \Core\i::Module();
	}
	
	/**
	* Gibt die aktuelle User-Instanz zurück.
	*
	* @return \Core\User
	**/
	protected function ui() {
		return $this->si()->getUserInstance();
	}
	
	/**
	* Gibt die aktuelle Session-Instanz zurück.
	*
	* @return \Core\Session
	**/
	protected function si() {
		return \Core\Session\i::Manager()->getSessionInstance();
	}
}
?>