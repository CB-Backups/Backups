<?php
/**
* Speichert die internen Eigenschaften für jedes Objekt.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-02-06
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\Object;

class Cache {
	/**
	* In diesem Variablen werden die registrierten Eigenschaften gespeichert.
	**/
	public $registeredProperties = [], $registeredSetter = [], $registeredGetter = [], $registeredTypes = [];
}
?>