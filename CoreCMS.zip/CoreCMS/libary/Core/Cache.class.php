<?php
/**
* Eine Möglichkeit, Daten in einer Datei zu Cachen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-11-12
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Cache extends Singleton {
	use Singleton\Vars;

	const DIR = 'cache/';
	
	protected $fileName, $cache = [];
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('fileName', true);
	}

	/**
	* Öffnet eine Cache-Datei mit entsprechenden Namen. Wenn sie bereits vorhanden ist, wird der Inhalt geladen.
	*
	* @param string $fileName - Name der Datei
	**/
	public function __construct($fileName) {
		$this->fileName = $fileName;
		$this->loadFile();
	}
		
	/**
	* Beim schließen des Objekts die Daten schreiben
	**/
	public function __destruct() {
		$this->writeFile();
		
		// ID-Instanz für diesen Dateinamen löschen
		static::unsetInstanceFor($this->fileName);
	}
	
	/**
	* Setzt eine Variable in den Cache
	*
	* @param string $name - Name der Variable
	* @param mixed $content - Inhalt der Variable
	**/
	public function setVar($name, $content) {
		$this->cache[$name] = $content;
	}
	
	/**
	* Gibt die Variable aus dem Cache zurück.
	*
	* @param string $name - Name der Variable
	* @return mixed - Inhalt der Variable
	**/
	public function getVar($name) {
		if(!isset($this->cache[$name])) throw new \Exception('Die Variable „'.$name.'“ liegt nicht in diesem Cache-File.', 1041); 
		
		return $this->cache[$name];
	}
	
	/**
	* Gibt zurück, ob die Variable im Variablen-Cache liegt.
	*
	* @param string $name - Name der Variable
	* @return bool - Ist im Cache?
	**/
	public function issetVar($name) {
		return isset($this->cache[$name]);
	}
	
	/**
	* Gibt alle Daten zurück, die in diese Cache-Datei geschrieben sind.
	*
	* @return array[mixed] - Alle Cach-Daten
	**/
	public function getAll() {
		return $this->cache;
	}
	
	/**
	* Gibt den ganzen Namen der Cache-Datei aus.
	*
	* @return String - Der ganze Namen der Datei
	**/
	protected function getFullFileName() {
		return ROOT_PATH.'/'.static::DIR.$this->fileName.'.cache';
	}
	
	/**
	* Versucht eine Datei mit entsprechenden Namen zu laden.
	**/
	protected function loadFile() {
		if(!file_exists($this->getFullFileName())) return;
		
		$fileContent = file_get_contents($this->getFullFileName());
		$this->cache = unserialize($fileContent);
	}
	
	/**
	* Schreibt die Datei mit entsprechenden Namen.
	**/
	protected function writeFile() {
		// Daten serialisieren
		$fileContent = serialize($this->cache);
		// Serialisierte Daten in der Datei speichern
		file_put_contents($this->getFullFileName(), $fileContent);
		// CHMod ändern
		chmod($this->getFullFileName(), 0777);
	}
	
	/**
	* Gibt den Cache-Ordner als IO\Directory-Element zurück.
	*
	* @return IO\Directory
	**/
	public static function getDirectoryInstance() {
		return new IO\Directory(ROOT_PATH.self::DIR);
	}
}
?>