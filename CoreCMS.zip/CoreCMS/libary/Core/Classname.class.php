<?php
/**
* „Parst“ einen Klassennamen und gibt Informationen über ihn zurück.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-20
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Classname extends \Object {
	protected $classname, $namespace, $namespacePointer = -1;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['classname', 'namespace'], true);
	}
	
	/**
	* Nimmt einen Klassennamen an und parst ihn.
	*
	* @param string $classname
	**/
	public function __construct($classname) {	
		// Klassennamen aufteilen
		$classnameParts = explode('\\', $classname);
		
		// Letztes Element ist der Klassenname
		$lastElement = count($classnameParts)-1;
		$this->classname = $classnameParts[$lastElement];
		
		// Alle andere Elemente sind der Namespace
		unset($classnameParts[$lastElement]);
		$this->namespace = $classnameParts;
		
		// Den Namespace-Pointer setzen
		$this->resetNamespacePointer();
	}
	
	/**
	* Setzt den Namespace-Pointer zurück.
	**/
	public function resetNamespacePointer() {
		$this->namespacePointer = count($this->namespace);
	}
	
	/**
	* Gibt die nächste Namespace-Hierachie rückwärts zurück.
	*
	* @return string/NULL
	**/
	public function getNextNamespacePart() {
		$this->namespacePointer --;
		
		if($this->namespacePointer < 0) return NULL;
		
		return $this->namespace[$this->namespacePointer];
	}
	
	/**
	* Gibt die Klasse mit vollem Namen zurück (Inklusive Namespace)
	*
	* @return string
	**/
	public function getFullClassname() {
		return $this->getNamespaceAsString().'\\'.$this->classname;
	}
	
	/**
	* Classname als String
	*
	* @return string
	**/
	public function __toString() {
		return $this->getFullClassname();
	}
	
	/**
	* Gibt den Namespace als String zurück
	*
	* @return string
	**/
	public function getNamespaceAsString() {
		return implode('\\', $this->namespace);
	}
	
	/**
	* Gibt die Reflection-Class für diesen Klassennamen zurück.
	*
	* @return \ReflectionClass
	**/
	public function getReflectionClass() {
		return new \ReflectionClass((string)$this);
	}
	
	/**
	* Gibt eine Instanz von sich selbst für ein gegeben Objekt zurück.
	*
	* @param object $object
	* @return self
	**/
	public static function forObject($object) {
		return new self(get_class($object));
	}
}
?>