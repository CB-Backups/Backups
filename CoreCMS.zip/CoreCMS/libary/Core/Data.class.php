<?php
/**
* Daten-Klasse, von ihr erben alle Klassen, die Daten brauchen.
* (Tochter-Klassen müssen das DataVars-Trait benutzen.)
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-10-24
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

abstract class Data extends \Object {
	const DATA_DIR = 'data/';
	
	protected $id, $group, $name;
	protected $properties = [], $varProperties = [];
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['id', 'group'], true, true);
		self::registerProperties(['name', 'properties'], true);
	}
	
	/**
	* Ließt Daten aus der, zur Klasse passenden XML-Datei und erstellt daraus ein Objekt, fügt dieses der Klasse hinzu.
	**/
	public static function loadDataFromXMLFile() {
		// Klassen-Namen ermitteln
		$className = new Classname(get_called_class());
		
		// Datei-Namen-Grundgerüst
		$namespacePart = '';
		$fileNameEnding = $className->getClassname().'.xml';
		
		do {
			$fileNameEnding = $namespacePart.$fileNameEnding;
		
			// Name der XML-Datei bauen.
			$fileName = ROOT_PATH.self::DATA_DIR.$fileNameEnding;
		
			// Die Datei ist vorhanden? Abruch!
			if(file_exists($fileName)) break;
		} while($namespacePart = $className->getNextNamespacePart());
		
		// Immer noch keine gültige Datei gefunden?
		if(!file_exists($fileName)) throw new \Exception('Für diese Klasse sind keine XML-Daten vorhanden.', 1155);
		
		// SimpleXML-Objekte
		foreach(XMLElement::loadFile($fileName) as $count=>$currentObject) {
			// Das „Name“-Element muss immer vorhanden sein.
			if(!isset($currentObject->name))
				throw new \Exception('Das '.Format::number($count).'-te Element in der „'.$fileName.'“-Datei hat keinen festgelegten Namen.', 1154);
			
			// Objekt erstellen
			$object = new static((string) $currentObject->name);
			
			// Die Eigenschaften des Objekts auslesen
			$properties = $currentObject->toArray();
			// Den Namen/Die Gruppe aus den Eigenschaften rauslöschen
			unset($properties['name']);
			unset($properties['group']);
			// Daten dem Objekt hinzufügen
			$object->properties = $properties;
			
			// Objekt der Klasse hinzufügen
			static::addObject((string) $currentObject['id'], $object, (isset($currentObject['group']) ? (string) $currentObject['group'] : false));
		}
	}
	
	/**
	* Rückfrage-Funktion für die Autoload-Klasse
	*
	* @param Classname - Angforderter Klassennamen
	* @return bool - Weitere Autoload-Funktionen durchführen? true = nein
	**/
	public static function callback(Classname $classname) {
		if($classname->getReflectionClass()->isSubclassOf('Core\Data') && $classname->getClassname() != 'Data') {
			try {
				call_user_func([(string)$classname, 'loadDataFromXMLFile']);
			} catch(\Exception $exception) {
				if($exception->getCode() != 1155)
					throw $exception;
			}
		}
	}

	/**
	* Nimmt neue Objekte an und speichert sie in z.B. einem Array.
	*
	* @param int $id - Eine ID für die Daten.
	* @param self $object - Ein neues Objekt
	* @param bool $group - Die Gruppe des Objekts [optional]
	**/
	public static function addObject($id, \Object $object, $group=false) {
		if(isset(static::$objects[$id])) throw new \Exception('Ein Daten-Objekt mit dieser ID ist bereits gespeichert.', 1150);
		
		$object->setID($id);
		$object->setGroup($group);
		
		static::$objects[$id] = $object;
		if($group !== false) static::$objectGroups[$group][] = $id;
	}
	
	/**
	* Gibt ein Array mit allen Objekten zurück, die gespeichert sind
	*
	* @param bool $group - Die Gruppe des Objekts [optional]
	* @return array - Liste mit Daten
	**/
	public static function getList($group = false) {
		if($group === false) return static::$objects;
		if(!isset(static::$objectGroups[$group])) throw new \Exception('Die angeforderte Daten-Grupp ist nicht bekannt.', 1151);
		
		$array = [];
		$groupArray = static::$objectGroups[$group];
		foreach($groupArray as $currentID) $array[] = self::getObjectForID($currentID);
		
		return $array;
	}
	
	/**
	* Zählt die Elemente, die gespeichert sind.
	*
	* @return int - Anzahl der Objekte
	**/
	public static function count() {
		return count(self::getList());
	}
	
	/**
	* Gibt das Objekt, passend zur ID wieder aus. Wenn die ID nicht existiert, muss ein Fehler geworfen werden.
	*
	* @param int $id - Die gesuchte ID
	* @return Train
	**/
	public static function getObjectForID($id) {
		if(!self::existObjectForID($id)) throw new \Exception('Kein Daten-Objekt mit dieser ID vorhanden.', 1152);
		
		return static::$objects[$id];
	}
	
	/**
	* Gibt zurück, ob für die ID ein Objekt vorhanden sind.
	*
	* @param int $id - Die gesuchte ID
	* @return bool - true = Vorhanden, false = nicht vorhanden
	**/
	public static function existObjectForID($id) {
		if(isset(static::$objects[$id])) return true;
		
		return false;
	}
	
	/**
	* Erstellt ein neues Daten-Objekt
	* 
	* @param string $name - Name des Objekts [optional]
	**/
	public function __construct($name=NULL) {
		$this->name = $name;
	}
	
	/**
	* Macht aus dem Objekt die ID des Datenobjekts
	*
	* @return int - ID
	**/
	public function __toString() {
		return $this->getID().': '.$this->getName();
	}
	
	/**
	* Nur die ID und vielleicht variable Einstellungen solle beim serializieren gespeichert werden.
	*
	* @return array
	**/
	public function __sleep() {
		return ['id','varProperties'];
	}
	
	/**
	* Beim Aufwachen werden eventuell aktuallisierte Daten für das Objekt geladen.
	* Wenn kein Objekt mit dieser ID mehr existiert wird ein Fehler geworfen.
	**/
	public function __wakeup() {
		if(!static::existObjectForID($this->id)) throw new \Exception('Das angeforderte Daten-Objekt mit der ID „'.$this->id.'“ konnte nicht wiederhergestellt werden.', 1153);
		
		$newInstance = self::getObjectForID($this->id);
		$this->name = $newInstance->getName();
		$this->group = $newInstance->getGroup();
		$this->properties = $newInstance->getProperties();
	}
}
?>