<?php
/**
* File-Klasse, die das Arbeiten mit Dateien vereinfacht.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-07
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\IO;

class File extends Element {
	const FUNCTION_PREFIX = 'f';

	protected $resource, $opened = false;
	
	/**
	* Öffnet eine Datei.
	*
	* @param string $filename - Name der Datei
	**/
	public function __construct($filename) {
		if(!is_file($filename))
			throw new \Exception('Das Element „'.$filename.'“ ist entweder nicht vorhanden oder keine Datei.', 1212);
	
		// Name in der Klasse speichern
		$this->elementPath = $filename;
	}
	
	/**
	* Öffnen die Datei-Resource.
	*
	* @param string $mode - Wie soll die Datei geöffnet werden? [optional]
	**/
	public function open($mode = 'r') {
		// Funktionsname für die open-Function bauen
		$functionName = static::FUNCTION_PREFIX.'open';
		
		// Datei öffnen
		$this->resource = $functionName($this->elementPath, $mode);
		
		// Fehler beim öffnen?
		if($this->resource === false)
			throw new \Exception('Beim Öffnen der Datei „'.$this->elementPath.'“ ist ein Fehler aufgetreten.', 1210);
			
		// Als geöffnet markieren
		$this->openend = true;
	}
	
	/**
	* Schließt die Verbindung mit der Datei.
	**/
	public function __destruct() {
		parent::__destruct();
	
		// Wenn die Datei geöffnet ist, sie wieder schließen
		if($this->opened) $this->close();
	}
	
	/**
	* PHP bekannte Datei-Funktionen ausführen.
	*
	* @param string $name - Name der Methode
	* @param array $args - Argumente
	**/
	public function ___call($name, array $args) {
		// Name ergänzen
		$name = static::FUNCTION_PREFIX.$name;
		// Argumente ergänzen
		array_unshift($args, $this->resource);
		
		// Existiert diese Funktion? Aufrufen!
		if(function_exists($name))
			return call_user_func_array($name, $args);
		
		throw new \Exception('Unbekannte File-Methode „'.$name.'“ aufgerufen.', 1211);
	}
	
	/**
	* Löscht dieses Element.
	**/
	public function remove() {
		// Wenn die Datei geöffnet ist, sie wieder schließen…
		if($this->opened) {
			$this->close();
			// … und als geschlossen markieren
			$this->opened = false;
		}
	
		// Datei löschen
		unlink($this->getPath());
	}
	
	/**
	* Gibt den Typ des Elements zurück.
	*
	* @return string
	**/
	public function getType() {
		switch(strtolower($this->getSuffix())) {
			// Ein Bild
			case 'png':
			case 'jpg':
			case 'jpeg':
			case 'gif':
			case 'bmp':
				return self::TYPE_IMG;
			
			// CSS-Datei
			case 'css':
				return self::TYPE_CSS;
			
			// PDF-Datei
			case 'pdf':
				return self::TYPE_PDF;
		
			// Unbekannter Type
			default:
				return self::TYPE_UKNOWN;	
		}
	}
	
	/**
	* Gibt die Größe des Elements zurück.
	*
	* @return int
	**/
	public function getSize() {
		return filesize($this->getPath());
	}
	
	/**
	* Gibt die Größe des Bildes zurück. (Falls es ein Bild ist.)
	*
	* @return array
	**/
	public function getImageSize() {
		if($this->getType() != self::TYPE_IMG)
			throw new \Exception('Das Element ist nicht vom Type Bild.', 1213);
			
		// Bildgröße zurückgeben
		return getimagesize($this->getPath());
	}
}
?>