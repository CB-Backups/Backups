<?php
/**
* Lässt einen Ordner durchlaufen. (Verwendet die \Directory-Klasse.)
* Nicht so komplex wie DirectoryIterator und verwendet die \Core\File-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-07
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\IO;

class Directory extends Element implements \Iterator {
	const INFO_FILENAME = '.folder';
	
	const INFO_DESCRIPTION = 'description';
	const INFO_MAX_SIZE = 'maxsize';

	protected $directoryInstance, $showHidden = false, $showHiddenTMP = false;
	private $currentFile, $infoCache;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('showHidden', true, true);
	}
	
	/**
	* Öffnet einen Ornder und speichert die \Directory-Instanz in der Klasse.
	*
	* @param string $directory - Pfad zum Ordner
	**/
	public function __construct($directory) {	
		if(!is_dir($directory))
			throw new \Exception('Das Element „'.$directory.'“ ist entweder nicht vorhanden oder kein Ordner.', 1250);
	
		// Name in der Klasse speichern
		$this->elementPath = $directory;
		// Instanz erstellen
		$this->directoryInstance = dir($directory);
		
		// Pointer auf die erste Datei zeigen
		$this->rewind();
	}
	
	/**
	* Resetet den Pointer des Ordner-Handles.
	**/
	public function rewind() {
		// An Directory-Klasse senden
		$this->directoryInstance->rewind();
		
		// Nächste Datei
		$this->next();
	}
	
	/**
	* Gibt die  der aktuellen Datei zurück.
	*
	* @return Path
	**/
	public function current() {
		return self::toElement($this->key());
	}
	
	/**
	* Gibt den Namen der aktuellen Datei zurück.
	*
	* @return string
	**/
	public function key() {
		return realpath($this->elementPath.'/'.$this->currentFile);
	}
	
	/**
	* Lässt den Zeiger zur nächsten Datei springen.
	**/
	public function next() {
		$this->currentFile = $this->directoryInstance->read();
		
		// Selbstverweis und Überverweis ignorieren
		if($this->currentFile == '.' || $this->currentFile == '..') $this->next();
		// Versteckte Dateien sollen nicht angezeigt werden?
		if(!$this->showHidden && !$this->showHiddenTMP && strpos($this->currentFile, '.') === 0) $this->next();
	}
	
	/**
	* Gibt zurück, ob es sich um eine gültige Position handelt.
	*
	* @return bool
	**/
	public function valid() {
		return $this->currentFile !== false;
	}
	
	/**
	* Löscht dieses Element.
	**/
	public function remove() {
		// ALLE ELEMENTE LÖSCHEN! (Auch die verstecken!)
		$this->showHiddenTMP = true;
	
		// Alle Elemente in diesem Verzeichnis löschen
		foreach($this as $currentFile) $currentFile->remove();
		
		// Versteckte Elemente wieder ausblenden
		$this->showHiddenTMP = false;
		
		// Das Verzeichnis selbst löschen
		rmdir($this->getPath());
	}
	
	/**
	* Gibt den Typ des Elements zurück.
	*
	* @return string
	**/
	public function getType() {
		return self::TYPE_DIR;
	}
	
	/**
	* Gibt die Größe des Elements zurück.
	*
	* @return int
	**/
	public function getSize() {
		// Variable vorbereiten
		$dirSize = 0;
		
		// ALLE ELEMENTE DURCHZÄHLEN! (Auch die verstecken!)
		$this->showHiddenTMP = true;
		
		// Alle Elemente durchzählen
		foreach($this as $currentFile) $dirSize += $currentFile->getSize();
		
		// Versteckte Elemente wieder ausblenden
		$this->showHiddenTMP = false;
		
		return $dirSize;
	}
	
	/**
	* Gibt zurück, wie viel Speicher in diesem Ordner noch frei ist.
	*
	* @return int
	**/
	public function getFreeSpace() {
		// Freier Speicher in diesem Ordner durch System
		$systemFreeSpace = ceil(disk_free_space($this->getPath()));
		// Aktueller Ordner
		$currentDir = $this;
		
		do {
			// Ordner-Infos laden
			$dirInfo = $currentDir->readInfo();
			
			// Wurde ein Kontigent durch die .folder-Datei festegelt?
			if(isset($dirInfo[self::INFO_MAX_SIZE])) {
			    // Maximale Größe
			    $maxSize = \Core\CalcBytes($dirInfo[self::INFO_MAX_SIZE]);
			    // Was bereits benutzt wurde abziehen
			    $freeSpace = $maxSize - $currentDir->getSize();
			    
			    // Das System erlaubt weniger als die Konfig? Dann Systemwert
			    if($freeSpace > $systemFreeSpace) $freeSpace = $systemFreeSpace;
			    
			    // Weitere Schleife abbrechen
			    return $freeSpace;
			}
		} while($currentDir = $currentDir->getParentDirectory());
		
		return $systemFreeSpace;
	}
	
	/**
	* Gibt die prozentualle Nutzung dieses Ordners zurück.
	*
	* @param bool $relativ - Relativ vom aktullen Ornder aus?
	* @return float
	**/
	public function getPercentUsage($relativ = true) {
		// Wie viel stand insgesammt in diesem Ordner zur Verfügung?
		$fullDisk = $this->getFreeSpace();
		// Ordnerverbauch dazuzählen
		if($relativ) $fullDisk += $this->getSize();
		// Programmverbrauch dazuzählen? Funktioniert nur, wenn der Ornder im Programmordner liegt
		else $fullDisk += self::toElement(ROOT_PATH)->getSize();
		
		// Wie viel wurde davon genutzt?
		$percentUsage = $this->getSize() / $fullDisk;
		
		// Gerundet zurückgeben
		return round($percentUsage, 2);
	}
	
	/**
	* Gibt zurück, ob das gewünschte Element in diesem Ordner liegt.
	*
	* @param Element $element
	* @return bool
	**/
	public function inDir(Element $element) {
		return strpos($element->getPath(), $this->getPath()) === 0;
	}
	
	/**
	* Überprüft, ob für ein Element genug Speicher in diesem Ordner ist.
	*
	* @param Element $element
	**/
	protected function enoughSpaceFor(Element $element) {
		if($element->getSize() > $this->getFreeSpace())
			throw new \Exception('In diesem Ordner ist nicht genügend Speicher für dieses Element.', 1253);
	} 
	
	/**
	* Fügt dem Ordner ein Element hinzu.
	*
	* @param Element $element
	* @param bool $move - Soll das Objekt verschoben und nicht kopiert werden? [Optional]
	* @return Element - Das neue Element.
	**/
	public function addElement(Element $element, $move = false) {
		// Element-Name mit eigenem Pfad verbinden
		$newName = $this->getPath().'/'.$element->getName();
		
		// Bereits in diesem Ordner? Abbrechen!
		if ($element->getPath() == realpath($newName)) return;
		
		if($move) { // Element verschieben
			// Dieser Ordner ist ein Unter-Element des zu verschiebenden Ordners?
			if($element instanceof Directory && $element->inDir($this))
				throw new \Exception('Ein Ordner kann nicht in einen eigenen Unterordner verschoben werden.', 1251);
			
			// Wenn aus einem anderem Ordner -> genug Speicher?
			if(!$this->inDir($element)) $this->enoughSpaceFor($element);
			
			$element->rename($newName);
			
			// Sich selbst zurückgeben
			return $this;
		} else { // Element kopieren
			// Genug Speicher?
			$this->enoughSpaceFor($element);
		
			return $element->copy($newName);
		}
	}
	
	/**
	* Fügt einen Ordner dem Element hinzu. (Name wird geparst.)
	*
	* @param string $name
	* @return Directory - Der neue Ordner
	**/
	public function addDirectory($name) {
		// Ungültiger Ordern-Name
		if(!preg_match(static::NAME_MATCH, $name))
			throw new \Exception('Der Ordnername enthält verbotene Zeichen.', 1252);
			
		// Ordnername basteln
		$name = $this->getPath().self::getDelimiter().$name;
		// Ordner ersteleln
		return self::create($name);
	}

	/**
	* Setzt die Eigenschaften des Ordners. (Löscht damit die alten.)
	*
	* @param array $directoryInfo - Ordner-Eigenschaften
	**/
	public function writeInfo(array $directoryInfo) {
		// Infos cachen
		$this->infoCache = $directoryInfo;
	
		// Zeit bilden
		$dateObject = new \Core\Time\Date();
		$date = $dateObject->format(\Core\Time\Date::RFC850);
	
		// Header der Infodatei
		$content = "; In dieser Datei stehen die Infos für den Ordner „".$this->getPath()."“.\n";
		$content .= "; Generiert am: ".$date."\n";
		
		// Informationen dem Inhalt hinzufügen
		foreach($directoryInfo as $key => $currentInfo)
			$content .= $key.' = "'.$currentInfo."\"\n";
			
		// Infos in die Datei schreiben
		file_put_contents($this->getPath().self::getDelimiter().self::INFO_FILENAME, $content);
	}
	
	/**
	* Ließt die Ordner-Informationen aus.
	*
	* @return array
	**/
	public function readInfo() {
		if(!is_array($this->infoCache)) {
			// Name der Info-Datei
			$infoFilename = $this->getPath().self::getDelimiter().self::INFO_FILENAME;
			
			// Existiert die Datei nicht? Leere Array zurückgeben
			if(!is_file($infoFilename)) $this->infoCache = [];
			// Datei auslesen
			else $this->infoCache = parse_ini_file($infoFilename);
		}
		
		// Infos zurückgeben
		return $this->infoCache;
	}
	
	/**
	* Erstellt einen neuen Ordner und gibt eine Instanz der Directory-Klasse zurück.
	*
	* @param string $path - Pfad
	* @return self
	**/
	public static function create($path) {
		// Name schon vorhanden? Neuer!
		while(file_exists($path)) $path = self::generateReplacementName($path);
	
		// Ordner erstellen
		mkdir($path);
		// Instanz zurückgeben
		return i::Directory($path);
	}
}
?>