<?php
/**
* Symbolisiert ein Element im FileSystem.
* Beinhaltet Methoden, die sowohl für Dateien, als auch für Ordner gleich sind und abstrakte Methoden die eingefügt werden müssen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-19
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\IO;

abstract class Element extends \Core\Singleton {
	use \Core\Singleton\Vars;

	const TYPE_UKNOWN = 0;
	const TYPE_DIR = 1;
	const TYPE_IMG = 2;
	const TYPE_CSS = 3;
	const TYPE_PDF = 4;
	
	const COPY_STRING = ' (%d)';
	const COPY_MATCH = '/ \(([0-9]+)\)/';
	
	const NAME_MATCH = '/^[a-zA-Z0-9\-_\., &äöüÄÖÜß]+$/';

	protected $elementPath, $elementInfo;
	
	/**
	* Löscht die Instanz aus dem Singleton-Speicher.
	**/
	public function __destruct() {
		// Instanz löschen
		self::unsetInstanceFor($this->getPath());
	}
	
	/**
	* Setzt den Namen sicher.
	*
	* @param string $name - Name des Elements
	**/
	public function setName($name) {
		// Hat bereits diesen Namen?
		if($name == $this->getName()) return;
	
		// Ungültige Name
		if(!preg_match(static::NAME_MATCH, $name))
			throw new \Exception('Der Element-Name enthält verbotene Zeichen.', 1242);
			
		// Umbennen
		$this->rename($this->getPathWithoutName().$name);
		
		// Cache löschen
		$this->elementInfo = NULL;
	}
	
	/**
	* Ließt die Element-Informationen aus.
	**/
	private function readElementInfo() {
		$this->elementInfo = pathinfo($this->getPath());
	}

	/**
	* Gibt den Namen des Elements zurück. (Ohne Pfad.)
	*
	* @return string
	**/
	public function getName() {
		// Noch keine Daten gecacht?
		if(!is_array($this->elementInfo)) $this->readElementInfo();
			
		// Das letzte Element zurückgeben
		return $this->elementInfo['basename'];
	}
	
	/**
	* Gibt die Endung des Elements zurück.
	*
	* @param bool $withPoint - Soll der Suffix mit Punkt zurückgegeben werden [optional]
	* @return string
	**/
	public function getSuffix($withPoint = false) {
		// Noch keine Daten gecacht?
		if(!is_array($this->elementInfo)) $this->readElementInfo();
		
		// Keine Endung vorhanden?
		if(!isset($this->elementInfo['extension'])) return '';
		
		// Mit Punkt und nicht leer?
		if($withPoint) return '.'.$this->elementInfo['extension'];
		
		// Einfach nur so
		return $this->elementInfo['extension'];
	}
	
	/**
	* Gibt den Namen ohne Endung zurück.
	*
	* @return string
	**/
	public function getNameWithoutSuffix() {
		// Noch keine Daten gecacht?
		if(!is_array($this->elementInfo)) $this->readElementInfo();
	
		return $this->elementInfo['filename'];
	}
	
	/**
	* Gibt den Pfad der Datei ohne Dateiname zurück.
	*
	* @return string - Name der Datei
	**/
	public function getPathWithoutName() {
		// Noch keine Daten gecacht?
		if(!is_array($this->elementInfo)) $this->readElementInfo();
	
		return $this->elementInfo['dirname'].self::getDelimiter();
	}
	
	/**
	* Gibt den aktuellen Pfad zurück.
	*
	* @return string
	**/
	public function getPath() {
		return $this->elementPath;
	}
	
	/**
	* Gibt den relativen Pfad zu einem Überordner an.
	*
	* @param Directory $directory
	* @return string
	**/
	public function getRelativPathTo(Directory $directory) {
		// $directory muss ein Überordner sein
		if(!$directory->inDir($this))
			throw new \Exception('Der angegeben Ordner muss ein Überordner sein.', 1240);
			
		return str_replace($directory->getPath().self::getDelimiter(), '', $this->getPath());
	}

	/**
	* Nennt das Element um.
	*
	* @param string $newName.
	**/
	public function rename($newName) {
		// Alter Pfad
		$oldPath = $this->getPath();
		
		do {
			// Gesamter-Pfad als $newName angegeben?
			if(strpos($newName, self::getDelimiter()) !== false)
				// Als neuer Pfad setzen
				$this->elementPath = $newName;
			else // Nur Teilpfad angegeben? Pfad noch hinzufügen
				$this->elementPath = $this->getPathWithoutName().$newName;
			
			// „Ersatzname“ generieren
			$newName = self::generateReplacementName($newName);
		} while(file_exists($this->elementPath)); // Datei existiert? Neuer Durchlauf mit Ersatznamen
		
		// Die Datei/Das Verzeichnis umbennen
		rename($oldPath, $this->elementPath);
	}
	
	/**
	* Kopiert ein Element.
	*
	* @param string $newName
	**/
	public function copy($newName) {
		while(file_exists($newName)); // Datei existiert? Neuer Durchlauf mit Ersatznamen
			$newName = self::generateReplacementName($newName);
		
		// Datei Kopieren
		copy($this->getPath(), $newName);
		
		// Neues Element zurückgeben
		return self::toElement($newName);
	}
	
	/**
	* Löscht dieses Element.
	**/
	abstract public function remove();
	
	/**
	* Gibt den Typ des Elements zurück.
	*
	* @return string
	**/
	abstract public function getType();
	
	/**
	* Gibt die Größe des Elements zurück.
	*
	* @return int
	**/
	abstract public function getSize();
	
	/**
	* Gibt den Eltern-Ordner zurück.
	*
	* @return Directory
	**/
	public function getParentDirectory() { static $i = 0;
		// Bereits oberster Ordner?
		if($this->getPath() == realpath(ROOT_PATH)) return NULL;
	
		return Directory::instanceFor($this->elementPath.self::getDelimiter().'..'.self::getDelimiter());
	}
	
	/**
	* Vereinheitlich den Pfad-Namen.
	*
	* @param string $id - Pfad
	* @return self
	**/
	public static function instanceFor($id) {	
		// Echter Pfad, damit es nicht zu Problemen kommt!
		return parent::instanceFor(realpath($id));
	}
	
	/**
	* Gibt den richtigen Element-Type zurück.
	*
	* @param string $path
	* @return Element
	**/
	public static function toElement($path) {
		// Ordner 
		if(is_dir($path)) return Directory::instanceFor($path);
		// Datei?
		if(is_file($path)) return File::instanceFor($path);
		
		// Unbekannter Type!
		throw new \Exception('Unbekannter Pfad: existiert dort überhaupt ein Element?', 1241);
	}
	
	/**
	* Generiert ein „Ersatzname“ für eine bereits vorhandene Datei.
	*
	* @param string $name
	* @replace string
	**/
	protected static function generateReplacementName($name) {
		// Namen auseinander nehmen
		$nameElements = explode('.', $name);
		
		// Vorletztes Element nehmen
		$nameElementID = count($nameElements)-2;
		// ID negativ? ID = 0;
		if($nameElementID < 0) $nameElementID = 0;
		// Element laden
		$nameElement = $nameElements[$nameElementID];
		
		// Existiert bereits der String? Hochzählen!
		if(preg_match(self::COPY_MATCH, $nameElement))
			$nameElement = preg_replace_callback(self::COPY_MATCH, function(array $matches) {
				// Aktuelle Zahl
				$count = (int)$matches[1];
				// Eins hochzählen
				$count++;
				
				// Neuen String hochzählen
				return sprintf(self::COPY_STRING, $count);
			}, $nameElement);
		else // Anhängen
			$nameElement .= sprintf(self::COPY_STRING, 1);
			
		// Element zurückschreiben
		$nameElements[$nameElementID] = $nameElement;	
		// Name zusammen bauen
		return implode('.', $nameElements);
	}
	
	/**
	* Gibt das Hirachie-Trennzeichen zurück.
	*
	* @return string
	**/
	public static function getDelimiter() {
		// Entsprechende Konstante zurückgeben
		return DIRECTORY_SEPARATOR;
	}
}
?>