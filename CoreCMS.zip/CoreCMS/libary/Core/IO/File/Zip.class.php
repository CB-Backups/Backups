<?php
/**
* Öffnet Dateien mit der zlib. (Gezippte Dateien.)
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\IO\File;

class Zip extends File {
	const FUNCTION_PREFIX = 'gz';
	
	/**
	* Überprüft ob die gzlib installiert ist und schickt dann den Aufruf an die 
	* Eltern-Klasse weiter.
	*
	* @param string $filename - Name der Datei
	**/
	public function __construct($filename) {
		if(!function_exists('gzopen'))
			throw new \Exception('Es können keine Zlib-Funktionen verwendet werden, da die Zlib nicht installiert ist.', 1230);
	
		// An die Eltern-Klasse weiterschicken
		parent::__construct($filename);
	}
}