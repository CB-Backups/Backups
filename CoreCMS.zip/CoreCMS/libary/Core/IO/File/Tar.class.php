<?php
/**
* Erstellt Inhaltsverzeichnisse zur Tar-Archiven und kann Dateien anhand dieses Verzeichnisses
* entpacken. Verwendet bei gezippten Tars automatisc die ZipFile-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-07
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core\IO\File;

class Tar extends \Object {
	use \Core\MainArray;
	
	const TYPE_FILE = 0;
	const TYPE_DIR = 1;

	protected $fileObject, $content = [], $zipped = false;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('content', true);
		self::registerProperty('zipped', true);
	}
	
	/**
	* Diese Funktion gibt das Haupt-Array zurück.
	*
	* @return array
	**/
	public function toArray() {
		return $this->content;
	}
	
	/**
	* Öffnet ein Tar-Archiv.
	*
	* @param string $archivname - Pfad zum Archiv
	**/
	public function __construct($archivname) {
		// Passendes File-Objekt öffnen
		$this->fileObject = new \Core\IO\i::File($archivname);
		// File-Resource öffnen
		$this->fileObject->open('rb');
		
		// Gezippte Datei? Die ZipFile-Klasse verwenden
		if($this->fileObject->read(2) == "\37\213") {
			$this->fileObject = new i::Zip($archivname);
			// File-Resource öffnen
			$this->fileObject->open('rb');
			// Setzen, dass es ein geziptes Archiv ist
			$this->zipped = true;
		}
		
		// Das Archiv durchlaufen
		while (strlen($bin = $this->fileObject->read(512)) != 0) {
			// Header-Daten lesen
			$header = self::binaryToArray($bin);
			// Aktueller Offset dem Header hinzufügen (Zum schnellerem Entpacken)
			$header['offset'] = $this->fileObject->tell();
			// Ende der Datei im Archiv
			$header['dataLength'] = 512 * ceil($header['size'] / 512);
			
			// Leere Datei? Überspringen
			if($header['size'] == 0 && $header['filetype'] != self::TYPE_DIR) continue;
			
			// Header im Inhaltsverzeichnis speichern
			$this->content[] = $header;
			
			// Zu dem nächsten Header springen
			$this->fileObject->seek($header['offset'] + $header['dataLength']);
		}
	}
	
	/**
	* Extrahiert die Daten einer Datei des Archives.
	*
	* @param int $id - ID des Elements (Siehe Content-Array.)
	* @return string - Der Inhalt der Datei
	**/
	public function extract($id) {
		// Unpacktes Archiv?
		if(!isset($this->content[$id]))
			throw new \Exception('Eine Element mit der ID '.$id.' ist in diesem Archiv nicht vorhanden.', 1220);	
		
		// Header auslesen
		$headerArray = $this->content[$id];
		
		// Ornder können nicht entpackt werden
		if($headerArray['filetype'] == self::TYPE_DIR)
			throw new \Exception('Ordner können nicht entpackt werden.');
		
		// Dateizeiger an die passende Stelle setzen
		$this->fileObject->seek($headerArray['offset']);
		
		// Daten auslesen
		$content = $this->fileObject->read($headerArray['size']);;
		
		return $content;
	}
	
	/**
	* Schreibt den Inhalt einer virtuellen Datei als richtige Datei.
	*
	* @param int $id - ID des Elements
	* @param string $destination - Ziel-Name des Elements
	**/
	public function extractToFile($id, $destination) {
		// Inhalt der Datei laden
		$content = $this->extract($id);
		
		// Header auslesen
		$headerArray = $this->content[$id];
		// Dateinamen basteln
		$filename = $destination;
		
		// Datei schreiben
		file_put_contents($filename, $content);
		// Eventuell noch die Änderungszeit anpassen
		if($headerArray['mtime']) touch($filename, $headerArray['mtime']);
	}
	
	/**
	* Entpackt alle Dateien in ein Ordner.
	*
	* @param string $baseDir - Verzeichnis, in das exportiert werden soll.
	**/
	public function extractAll($baseDir) {
		// Alle Elemente durchlaufen
		foreach($this->content as $key => $currentHeader) {
			if($currentHeader['filetype'] == self::TYPE_DIR) // Ordner? Ordner selbst erzeugen!
				mkdir($baseDir.'/'.$currentHeader['filename']);
			else // Datei? Datei entpacken!
				$this->extractToFile($key, $baseDir.'/'.$currentHeader['filename']);
		}
	}
	
	/**
	* Macht aus einem 512-Byte-Binary in Daten-Array mit den Header-Informationen.
	*
	* @param string $binary - Daten
	* @return array - Header-Array
	**/
	private static function binaryToArray($binary) {
		// Header-Array initialisieren
		$headerArray = [];
		
		// Binäre Daten in ein temporäres Array unpacken
		$tmpData = unpack('a100filename/a8mode/a8uid/a8gid/a12size/a12mtime/a8checksum/a1typeflag/a100link/a6magic/a2version/a32uname/a32gname/a8devmajor/a8devminor/a155prefix', $binary);
		
		// Daten richtig formatiert in das Header-Array schreiben
		$headerArray['filename'] = trim($tmpData['filename']);
		$headerArray['mode'] = octDec(trim($tmpData['mode']));
		$headerArray['uid'] = octDec(trim($tmpData['uid']));
		$headerArray['gid'] = octDec(trim($tmpData['gid']));
		$headerArray['size'] = octDec(trim($tmpData['size']));
		$headerArray['mtime'] = octDec(trim($tmpData['mtime']));
		$headerArray['prefix'] = trim($tmpData['prefix']);
		
		// Ordner oder Datei?
		if($tmpData['typeflag'] == 5) {
			// Type setzen
			$headerArray['filetype'] = self::TYPE_DIR;
			// Ordner haben keine Größe
			$headerArray['size'] = 0;
		} else
			$headerArray['filetype'] = self::TYPE_FILE;
		
		return $headerArray;
	}
}
?>