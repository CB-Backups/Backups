<?php
/**
* Erstellt ein Captcha und speichert die ID in der Session.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-28
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

class Captcha extends \Object {
	const FONT_DIR = 'fonts/';
	const FONT_SIZE = 25;

	protected $captchaFonts = ['captcha0','captcha1','captcha2','captcha3','captcha4','captcha5','captcha6'];
	protected $image;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('image', true);
	}
	
	/**
	* Erstellt ein neues Captcha.
	**/
	public function __construct() {
		// Bild erstellen
		$this->image = new Image(155, 40);
		
		// Hintergrundfarbe setzen
		$backgroundColor = $this->image->createColor(255, 255, 255);
		$this->image->setBackgroundColor($backgroundColor);
		
		$this->writeText();
	}
	
	/**
	* Schreibt den Text auf das Captcha
	**/
	protected function writeText() {
		// Schriftfarbe erstellen
		$fontColor = $this->image->createColor(0, 0, 0);
		
		foreach(str_split($this->createText()) as $key => $string) {
			$x = 5 + (25*$key);
			$y = 25 + mt_rand(1, 10);
			$angle = mt_rand(0,10);
			$font = $this->getRandomFont();
			
			// Text auf Bild schreiben
			$this->image->writeText($x, $y, $angle, $fontColor, self::FONT_SIZE, $font, $string);
		}
	}
	
	/**
	* Erstellt einen Text und speichert ihn in der Session.
	*
	* @return string
	**/
	protected function createText() {
		// Zufallszahl generieren
		$text = mt_rand(100000, 999999);
		// Zahl speichern
		Session\i::Manager()->setCaptchaText($text);
		
		return $text;
	}
	
	/**
	* Gibt eine zufällige Schriftart zurück.
	*
	* @return string
	**/
	protected function getRandomFont() {
		// Zufalls Key ermitteln
		$randomKey = mt_rand(0,count($this->captchaFonts)-1);
		// Schriftart dazu
		$file = $this->captchaFonts[$randomKey];
		// Rückgabe mit Pfad
		return ROOT_PATH.self::FONT_DIR.$file.'.ttf';
	}
}
?>