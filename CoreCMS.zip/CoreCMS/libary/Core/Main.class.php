<?php
/**
* Diese Klasse ist die Haupt-Klasse, sie lädt immer die erforderlichen Daten nach,
* um die angeforderte Seite richtig darstellen zu können.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-06-27
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

abstract class Main extends Singleton {
	use Singleton\Vars, Singleton\Auto;
	
	protected $timeZone;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperty('timeZone', true);
	}

	/**
	* Die Konstrukt-Methode, die alles weitere ausführt.
	**/
	public function __construct() {
		parent::__construct();
		
		// Timeout entfernen
		set_time_limit(0);
		
		// Zeitzone setzen
		$this->setTimeZone(new Time\Zone(\Config\TIME_ZONE));
		
		// Setzt den Header
		new Header();
		
		// MySQL-Verbindung aufbauen (Außer das Programm ist noch nicht installiert)
		if(\Config\INSTALLED) {
			// Escape-String-Alias erstellen (Gleichzeitg wird damit die MySQL-Verbindung aufgebaut.)
			Alias::forFunction([i::MySQL(), 'quoteString'], 'quoteMySQL');
		}
	}
	
	/**
	* „Startet“ die Aufgaben dieser Klasse.
	**/
	abstract public function start();
	
	/**
	* Setzt die aktuelle Zeitzone
	*
	* @param \Core\Time\Zone $timeZone
	**/
	public function setTimeZone(Time\Zone $timeZone) {
		// Global setzen
		date_default_timezone_set($timeZone->getName());
		// Für die OOP-Funktionen setzen
		$this->timeZone = $timeZone;
	}
	
	/**
	* Berechnet die Generierungszeit.
	*	Ohh, dank awesome neuer Server-Variable in PHP 5.4 geht das jetzt viel cooler! :3
	*
	* @return string - Zeit als String
	**/
	public function getGenTime() {
		$startTime = $_SERVER['REQUEST_TIME_FLOAT'];
		$endTime = microtime(true);
	
		return Format::unit(Format::number(($endTime - $startTime) * 1000,2),'ms');
	}
	
	/**
	* Gibt den aktuellen Arbeitsspeicher-Verbrauch zurück.
	*
	* @return string - Arbeitsspeicher als String
	**/
	public function getMemoryUsage() {
		return Format::size(memory_get_usage(true));
	}
}
?>