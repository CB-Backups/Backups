<?php
/**
* Vereinheitlichung des Cachens von Haupt- und ID-Instanzen.
* Bitte auch das Singleton\Var-Trait verwenden
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-12-02
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/
namespace Core;

abstract class Singleton extends \Object {	
	// Existiert bereits eine Modul-Hauptinstanz?
	public function __construct() {
		if(self::existMainInstance()) throw new \Exception('Es existiert bereits eine „'.get_called_class().'“-Hauptinstanz.', 1002);
			
		// Die Hauptinstanz setzen
		self::setMainInstance($this);
	}

	/**
	* Gibt zurück, ob eine Instanz mit dieser ID existiert
	*
	* @param int $id - ID
	* @return bool - Existiert?
	**/
	public static function existInstanceFor($id) {
		return isset(static::$instances[$id]);
	}
	
	/**
	* Löscht eine ID-Istanz.
	*
	* @param int $id - ID
	**/
	protected static function unsetInstanceFor($id) {
		unset(static::$instances[$id]);
	}
	
	/**
	* Setzt eine Instanz für eine ID
	*
	* @param int $id - ID
	* @param Singleton $instance - Die Instanz
	**/
	protected static function setInstanceFor($id, Singleton $instance) {
		if (static::existInstanceFor($id))
			throw new \Exception('Es ist bereits eine „'.get_called_class().'“-Instanz für diese ID vorhanden.', 1003);
	
		static::$instances[$id] = $instance;
	}
	
	/**
	* Gibt eine Instanz für eine neue Klasse
	*
	* @param int $id - ID
	* @return static - Instanz die zu dieser ID passt.
	**/
	public static function instanceFor($id) {
		if(!static::existInstanceFor($id)) static::setInstanceFor($id, new static($id));

		return static::$instances[$id];
	}
	
	/**
	* Gibt zurück, ob eine Instanz als Hauptinstanz gesetzt ist.
	*
	* @return bool - Hauptinstanz vorhanden?
	**/
	public static function existMainInstance() {
		return is_object(static::$mainInstance);
	}
	
	/**
	* Gibt die Hauptinstanz zurück, falls vorhanden. Wenn nicht wird eine Exception geworfen
	*
	* @return static - Die Haupinstanz dieser Klasse
	**/
	public static function mainInstance() {
		if(!static::existMainInstance()) throw new \Exception('Die Klasse „'.get_called_class().'“ hat derzeit keine Hauptinstanz.',1000);
		
		return static::$mainInstance;
	}
	
	/**
	* Löscht die Hauptinstanz aus dem Speicher.
	**/
	protected static function unsetMainInstance() {
		static::$mainInstance = NULL;
	}
	
	/**
	* Setzt eine Hauptinstanz
	*
	* @param Singleton $mainInstance - Hauptinstanz
	**/
	protected static function setMainInstance(Singleton $mainInstance) {
		static::$mainInstance = $mainInstance;
	}
	
	/**
	* Gibt alle, für diese Klasse, vorhandenen Instanzen zurück.
	*	Sowohl die Haupt-Instanz als auch alle ID-Instanzen
	*
	* @return static
	**/
	public static function getAllInstances() {
		$instances = array_values(static::$instances);
		if(static::existMainInstance())
			$instances[] = static::mainInstance();
			
		return $instances;
	}
	
	
	/**
	* Verbote von Singleton-Klasse durchsetzen!
	**/
	protected function throwSingletonException() {
		throw new \Exception('Eine Singleton-Instanz darf in der Regel werden geklont noch serialisiert werden.', 1001);
	}
	
	/**
	* Das Klonen von Singleton-Klassen ist nicht erlaubt.
	**/
	public function __clone() {
		$this->throwSingletonException();
	}
	
	/**
	* Singleton-Klasse dürfen in der Regeln nicht eingeschläfert werden.
	**/
	public function __sleep() {
		$this->throwSingletonException();
	}
	
}