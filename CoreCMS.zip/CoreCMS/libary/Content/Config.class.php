<?php
/**
* Verwaltet die Konfiguration dieser Installation.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-29
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content;

class Config extends \Core\Singleton implements \Countable, \IteratorAggregate, \ArrayAccess {
	use \Core\Singleton\Vars, \Core\MainArray;
	
	const DIR = 'config/';
	const TABLE = 'config';
	
	private $tableActions, $mode;
	private $dataArray = [], $entries = [];
	
	/**
	* Öffnet die Klasse und lädt die vorhadenen Konfigurationen zusammen mit den geänderten Konfigurationen.
	*
	* @param string $mode - Welche Konfigurationen sollen geladen werden? [optional]
	**/
	public function __construct($mode = 'general') {
		// Modus speichern
		$this->mode = $mode;
	
		// Table-Actions laden
		$this->tableActions = \Core\i::MySQL()->tableActions(self::TABLE);
		// Daten aus der DB lesen
		$this->fetchFromDatabase();
	
		// Die entsprechende Configurations-Datei laden
		$xmlElement = \Core\XMLElement::loadFile(ROOT_PATH.self::DIR.$mode.'.xml');
		
		// Die Elemente durchlaufen und Elemente erzeugen
		foreach($xmlElement as $currentElement) {
			// Die Daten aus dem Element laden
			$type = $currentElement['type'];
			$id = (string) $currentElement->id;
			$specialID = $mode.'.'.$id;
			$name = (string) $currentElement->name;
			$default = (string) $currentElement->default;
			
			// Klassenname bilden
			$classname = 'Content\\Config\\'.ucfirst($type);
			// Exitiert die Klasse überhaupt?
			if(!class_exists($classname))
				throw new \Exception('Der Einstellungs-Type „'.$type.'“ ist unbekannt.', 2010);
			
			// Element erzeugen
			$entry = new $classname($id, $name, $default);
			
			// Bereits eine geänderte Einstellung vorhanden? Diese setzen.
			if(isset($this->dataArray[$specialID]))
				$entry->setCurrent($this->dataArray[$specialID]);
			
			// Element dem Array hinzufügen
			$this->entries[$id] = $entry;
		}
	}
	
	/**
	* Geänderte Einstellungen speichern.
	**/
	public function __destruct() {
		// Lösch-Array vorbereiten
		$deleteData = [];
	
		// Alle Einstellungen durchlaufen
		foreach($this as $id => $currentEntry) {
			// Special-ID laden
			$specialID = $this->mode.'.'.$id;
			
			 // Standard-Eintrag? Ist eventuell noch ein Eintrag in der DB?
			if($currentEntry->isDefault() && isset($this->dataArray[$specialID]))
				$deleteData['id'] = $specialID;
			// Nicht der Standard-Wert?
			else if(!$currentEntry->isDefault()) {
				// Es gibt noch keinen DB-Eintrag?
				if(!isset($this->dataArray[$specialID]))
					$this->tableActions->insert([	'content' => $currentEntry->getCurrent(),
													'id' => $specialID]);
				// Der DB-Eintrag ist falsch?
				else if($currentEntry->getCurrent() != $this->dataArray[$specialID])
					$this->tableActions->update(
						['content' => $currentEntry->getCurrent()],
						['id' => $specialID]);
			}
		}
		
		// Müssen Einträge gelöscht werden? Löschen
		if(count($deleteData)) $this->tableActions->delete([$deleteData]);
	}
	
	/**
	* Gibt das Eintrag-Array zurück.
	*
	* @return array
	**/
	public function toArray() {
		return $this->entries;
	}
	
	/**
	* Läd die Einstellungen aus der Datenbank.
	**/
	private function fetchFromDatabase() {
		// Bereitsgetätigte Einstellungen laden
		$data = $this->tableActions->select()->fetchAll();
		
		// Geht die Daten durch und setzt die ID als Array-Key
		foreach($data as $currentData)
			$this->dataArray[$currentData['id']] = $currentData['content'];
	}
}
?>