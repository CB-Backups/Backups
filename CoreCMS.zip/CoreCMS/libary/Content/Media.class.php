<?php
/**
* Verwaltet die Medien des CMS.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-18
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content;

class Media extends \Object implements \IteratorAggregate {
	const DIR = 'media/';
	const CACHE_DIR = 'cache/thumbs/';
	
	const THUMB_HEIGHT = 130;
	const THUMB_WIDTH = 230;
	
	const DUMMY_NAME = 'Unbenanntes Element';
	
	protected $allowedTypes = [\Core\IO\Element::TYPE_IMG, \Core\IO\Element::TYPE_CSS, \Core\IO\Element::TYPE_PDF];
		
	protected $directory, $directoryInstance;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['directory', 'directoryInstance'], true);
	}
	
	/**
	* Öffnet den aktuellen Medien-Ordner.
	*
	* @param $currentDir - Eventuell ein Unterordner öffnen?
	**/
	public function __construct($currentDir = NULL) {
		// Verzeichnis setzen
		$this->directory = $currentDir;
		
		// Kein Unterordner? Hauptpfad verwenden
		if(is_null($this->directory)) $this->directory = self::mainDirectory()->getPath();
		
		// Existiert der Ornder überhaupt?
		if(!is_dir($this->directory))
			throw new \Exception('Der ausgewählte Ordner existiert nicht.', 2000);
			
		// Dir-Instanz öffnen
		$this->directoryInstance = \Core\IO\i::Directory($this->directory);
		
		// Diese Instance liegt nicht im Medien-Ordner? Abbrechen, Sicherheitsfehler!
		self::validMediaElement($this->directoryInstance);
	}
	
	/**
	* Fügt ein Element dem Ordner hinzu.
	*
	* @param \Core\IO\File $file
	* @param string $name - Name des Elements
	**/
	public function addElement(\Core\IO\File $file, $name) {	
		// Datei dem aktuellen Medienverzeichnis hinzufügen
		$file = $this->getDirectoryInstance()->addElement($file);	
		
		try {
			// Umbennen zu dem alten Namen
			$file->setName($name);
		} catch(\Exception $exception) { // Beim bennen der Datei ist ein Fehler aufgetretten?
			// Dateiendung laden
			$elements = explode('.', $name);
			// Dateiendung vorhande?
			$suffix = count($elements) > 1 ? '.'.$elements[count($elements)-1] : '';
			
			// Dateiname setzen
			$file->setName(self::DUMMY_NAME.$suffix);	
		}
		
		// Das Element ist kein Erlaubter Datei-Type?
		if(!in_array($file->getType(), $this->allowedTypes)) {
			// Datei löschen
			$file->remove();
		
			// Exception werfen
			throw new \Exception('Es wird versucht ein unerlaubtes Element dem Medien-Ordner hinzuzufügen.', 2003);
		}
	}
	
	/**
	* Gibt die Iterator-Instanz zurück. (Den aktuellen Ordner
	*
	* @return \Core\Directory
	**/
	public function getIterator() {
		return $this->directoryInstance;
	}
	
	/**
	* Gibt zurück, ob es sich um den Hauptordner handelt.
	*
	* @return bool
	**/
	public function isMainDir() {
		return self::mainDirectory()->getPath() == $this->directoryInstance->getPath();
	}
	
	/**
	* Gibt die Instanz des Haupt-Medien-Ordners zurück.
	*
	* @return \Core\Directory
	**/
	public static function mainDirectory() {
		// Der Medien-Ordner existiert nicht? Ist nicht besschreibbar?
		if(!is_dir(ROOT_PATH.self::DIR) || !is_writable(ROOT_PATH.self::DIR))
			throw new \Exception('Der Medien-Ordner existiert nicht oder ist nicht beschreibbar. Es muss im Hauptverzeichnis der Ordner „'.self::DIR.'“ existieren.', 2004);
	
		return \Core\IO\i::Directory(ROOT_PATH.self::DIR);
	}
	
	/**
	* Gibt den Cache-Ordner für die Thumbs als Instanz zurück.
	*
	* @return \Core\Directory
	**/
	public static function cacheDirectory() {
		// Cache-Ordner existiert nicht?
    	if(!is_dir(ROOT_PATH.self::CACHE_DIR)) {
    		// Ordner erstellen
    		$dir = \Core\IO\Directory::create(ROOT_PATH.self::CACHE_DIR);
    		// Infos reinschreiben
    		$dir->writeInfo(['description' => 'Thumbnails für die Medienverwaltung']);
    		
    		// Ordner zurüclgeben
    		return $dir;
		} else // Vorhandenen Ordner zurückgeben
			return \Core\IO\i::Directory(ROOT_PATH.self::CACHE_DIR);
	}
	
	/**
	* Überprüft, ob das Element angefordert werden darf.
	*
	* @param \Core\IO\Element $element
	* @param bool $changeElement - Soll das Element geändert werden
	**/
	private static function validMediaElement(\Core\IO\Element $element, $changeElement = false) {
		// Rechte prüfen
		if(!\Content\Media::mainDirectory()->inDir($element))
			throw new \Exception('Das ausgewählte Element liegt nicht im Media-Verzeichnis. Das ist ein Sicherheitsverstoß!', 2011);
			
		// Der Medien-Hauptordner darf auch nicht verändert werden
		if($element->getPath() == self::mainDirectory()->getPath() && $changeElement)
			throw new \Exception('Der Haupt-Medienordner darf nicht verändert werden.', 2002);
	}
	
	/**
	* Generiert einen Namen eines Thumbs.
	*
	* @param \Core\IO\File $image - Datei
	* @return string
	**/
	private static function generateThumbName(\Core\IO\File $image) {
		return self::CACHE_DIR.str_replace(\Core\IO\Element::getDelimiter(), '_', $image->getPath()).'.png';
	}
	
	/**
	* Stellt das Thumbnail da.
	*
	* @param \Core\IO\File $image - Datei
	**/
	public static function drawThumb(\Core\IO\File $image) {
		// Darf das Element angezeigt werden
		self::validMediaElement($image);
	
		// Name des Thumbs
		$thumbFullName = ROOT_PATH.self::generateThumbName($image);
		
		// Muss das Thumb noch generiert werden?
		if(!file_exists($thumbFullName)) {
			// Cache-Ordner erstellen, falls nicht vorhanden
			self::cacheDirectory();
					
			try {
				// Image-Instanz erstellen
				$image = \Core\Image::fromFile($image);
				// Bildgröße anpassen
				$image = $image->resize(false, self::THUMB_HEIGHT);
				
				try {
					// Bild schreiben
					$image->drawInFile($thumbFullName);
				} catch(\Exception $exception) {};
			} catch(\Exception $exception) {
				// Leeres-Bild erstellen
				$image = new \Core\Image(self::THUMB_WIDTH, self::THUMB_HEIGHT);
			}
		} else
			$image = \Core\Image::fromFile(\Core\IO\i::File($thumbFullName));
		
		// Bild zeichnen
		$image->draw();
	}
	
	/**
	* Löscht ein Element aus dem Medienverzeichnis, zusammen mit eventuell vorhandenen Thumbs.
	*
	* @param \Core\IO\Element $element
	* @param bool $onlyThumb
	**/
	public static function removeElement(\Core\IO\Element $element, $onlyThumb = false) {
		// Darf das Element geändert werden
		self::validMediaElement($element, true);
	
		if($element instanceof \Core\IO\File) { // Datei? Dann sind eventuell Thumbs vorhanden
			// Thumb-Name generieren
			$thumbName = ROOT_PATH.self::generateThumbName($element);
			
			// Thumb löschen, falls vorhanden
			if(file_exists($thumbName)) unlink($thumbName);
		} else if($element instanceof \Core\IO\Directory && !$onlyThumb) { // Ordner? Da sind eventuell Dateien mit Thumbs vorhanden
			// Alle enthaltenen Element durchlaufen
			foreach($element as $currentElement)
				self::removeElement($currentElement);
		}
	
		// Datei löschen
		if(!$onlyThumb) $element->remove();
	}
	
	/**
	* Verschiebt ein Element in einen neuen Ordner, Thumbs werden gelöscht.
	*
	* @param \Core\IO\Element $element
	* @param string $targetDir
	**/
	public static function moveElement(\Core\IO\Element $element, $targetDir) {
		// Ordner name bauen
		$targetDir = ROOT_PATH.self::DIR.$targetDir;
		// Instanz bauen
		$targetDirInstance = new \Core\IO\Directory($targetDir);
		// Gültiges Zielverzeichnis?
		self::validMediaElement($targetDirInstance);
	
		// Darf das Element geändert werden
		self::validMediaElement($element, true);
		
		// Thumb löschen
		self::removeElement($element, true);
		// Element verschieben
		$targetDirInstance->addElement($element, true);
	}
	
	/**
	* Nennt ein Element um.
	*
	* @param \Core\IO\Element $element
	* @param string $name
	**/
	public static function renameElement(\Core\IO\Element $element, $name) {
		// Darf das Element geändert werden
		self::validMediaElement($element, true);
		
		// Der Name leer? Darf nicht sein!
		if(empty($name))
			throw new \HumanException('Der neue Name darf nicht leer sein.', -1);
		
		// Thumb löschen
		self::removeElement($element, true);
		// Element umbennen
		$element->setName($name.$element->getSuffix(true));
	}
	
	/**
	* Gibt den relativen Pfad zum Medienelement an.
	*
	* @param \Core\IO\Element $element
	* @return string
	**/
	public static function getRelativPath(\Core\IO\Element $element) {
		// Pfad im Medienordner
		$pathInMediaDir = $element->getRelativPathTo(self::mainDirectory());
		
		return self::DIR.$pathInMediaDir;
	}
	
	/**
	* Gibt alle Unterverzeichnisse des Medienverzeichnisses an.
	*
	* @param \Core\IO\Directory $currentDir - Aktuelles Verzeichnis [optional]
	* @return array
	**/
	public static function getMediaDirs(\Core\IO\Directory $currentDir = NULL) {
		// Kein Verzeichnis angegeben? Hauptverzeichnis
		$currentDir = $currentDir ?: self::mainDirectory();
		
		// Verzeichnis durchlaufen
		$dirs = [];
		foreach($currentDir as $dir) {
			// Nur Ordner
			if(!$dir instanceof \Core\IO\Directory) continue;
		
			// Verzeichnis hinzufügen
			$dirs[] = $dir->getRelativPathTo(self::mainDirectory());
			
			// Unterverzeichnisse hinzufügen
			foreach(self::getMediaDirs($dir) as $subDir)
				$dirs[] = $subDir;
		}

		// Zurückgeben
		return $dirs;
	}
}
?>