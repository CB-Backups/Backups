<?php
/**
* Stellt eine Seite des CMS dar.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content;

class Site extends \Object implements \Countable, \IteratorAggregate, \ArrayAccess {
	use \Core\MainArray, Site\Mixed;

	protected $name, $hits = 0, $home = false, $sortID = 0;
	protected $posts = [];
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['name', 'home', 'sortID'], true, true);
		self::registerProperties(['lastChange', 'posts', 'hits', 'hidden'], true);
	}
	
	/**
	* Beim klonen auch die Posts klonen, damit der Seiten-Manager richtig funktioniert.
	**/
	public function __clone() {
		// Alle Beiträge durchlaufen und klonen.
		foreach($this as $id => $currentPost)
			$this->posts[$id] = clone $currentPost;
	}
	
	/**
	* Gibt die Beiträge zurück.
	*
	* @return array
	**/
	public function toArray() {
		return $this->posts;
	}
	
	/**
	* Erstellt eine neue Seite.
	*
	* @param string $name
	**/
	public function __construct($name) {
		// Name setzen
		$this->name = $name;
		// Änderungsdatum setzen
		$this->setLastChange();
	}
	
	/**
	* Setzt die Anzahl der Aufrufe um eins hoch.
	**/
	public function setHits() {
		$this->hits ++;
	}
	
	/**
	* Einen neuen Post zu dieser Seite hinzufügen.
	*
	* @param Site\Post $post
	**/
	public function addPost(Site\Post $post) {
		// Ans Ende des Arrays hinzufügen
		$this->posts[] = $post;
	}
	
	/**
	* Löscht einen Post aus der Seite.
	*
	* @param int $id - ID des Posts
	**/
	public function removePost($id) {
		// ID aus dem Array löschen
		unset($this->posts[$id]);
	}
	
	/**
	* Sortiert die Seite eins nach oben.
	**/
	public function sortUp() {
		$this->sortID --;
	}
	
	/**
	* Sortiert die Seite eins nach unten.
	**/
	public function sortDown() {
		$this->sortID ++;
	}
}
?>