<?php
/**
* Anpassungen an die Installations-Klasse für das einzelne Projekt.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-10-19
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content;

class Install extends \Core\Install {
	const REQUIERED_MEMORY_SIZE = '64M';
	
	/**
	* Fügt die notwendige zusätzlich notwendigen Konfigurations-Eintränge dem Array hinzu.
	*
	* @param bool $install - Soll es installiert werden? [optional]
	**/
	public function __construct($install = true) {
		// Einträge hinzufügen
		$this->configurations['Version']['CURRENT'] = \Config\Version\CURRENT;
		
		// Hauptskript aufrufen
		parent::__construct($install);
	}
}
?>