<?php
/**
* Beinhaltet Funktionen die sowohl Seiten als auch Beträge bieten.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content\Site;

trait Mixed {
	protected $lastChange, $hidden = false;
	
	/**
	* Setzt das Datum der letzten Änderug auf jetzt.
	**/
	public function setLastChange() {
		$this->lastChange = time();
	}
	
	/**
	* Versteckt diese Seite für die Hautpseite.
	**/
	public function hide() {
		$this->hidden = true;
	}
	
	/**
	* Stellt die Seite wieder da.
	**/
	public function unhide() {
		$this->hidden = false;
	}
}