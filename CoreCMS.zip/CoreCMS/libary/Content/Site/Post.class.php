<?php
/**
* Ein Beitrag auf einer Seite.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content\Site;

class Post extends \Object {
	use Mixed;

	protected $title, $text, $postTime;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['title', 'text'], true, true);
		self::registerProperties(['postTime', 'lastChange', 'hidden'], true);
	}
	
	/**
	* Ein neuen Post erstellen.
	*
	* @param string $title - Titel des Posts [optional]
	* @param string $text - Text des Posts [optional]
	**/
	public function __construct($title='', $text='') {
		// Daten speichern
		$this->title = $title;
		$this->text = $text;
		
		// Post-Datum festlegen
		$this->postTime = time();
		// Letzte Änderung
		$this->setLastChange();
	}
}
?>