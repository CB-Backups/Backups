<?php
/**
* Manager für die Seiten-Datensätze
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-04-10
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content\Site;

class Manager extends \Core\Manager {
	use \Core\Singleton\Vars;

	const TABLE = 'sites';
	
	/**
	* Gibt das Content-Array für ein Objekt zurück
	*
	* @param object $object - Das Objekt
	* @return array - Content-Array
	**/
	protected function getContentArrayForObject($object) {
		return ['object' => serialize($object)];
	}
	
	/**
	* Sortiert die Seite neu.
	**/
	protected function sortObjects() {
		// Objekte durchlaufen
		uasort($this->objects, function(\Content\Site $a, \Content\Site $b) {
			// Array nach SortID sortieren
			return $a->getSortID() < $b->getSortID() ? -1 : 1;
		});
	}
	
	/**
	* Fügt ein neues Objekt hinzu.
	*
	* @param \Content\Site $task - Das neue Objekt
	**/
	public function addObject(\Object $object) {
		// Sort-ID setzen
		$object->setSortID(count($this->objects));
		// Objekt hinzufügen
		parent::addObject($object);
	}
	
	/**
	* Löscht ein Objekt aus der Datenbank.
	*
	* @param int $objectID - ID
	**/
	public function removeObject($objectID) {
		// Alle Objekte durchlaufen
		$afterID = false;
		foreach($this as $id => $currenObject) {
			// ID erreicht
			if($id == $objectID) $afterID = true;
			// ID no
			if(!$afterID) continue;
			
			// Sort-ID eins runterzählen
			$currenObject->sortUp();
		}
		
		// Objekt löschen
		parent::removeObject($objectID);
	}
	
	/**
	* LoadAll überschreiben und sortieren.
	**/
	public function loadAll() {
		// Hauptmethode aufrufen
		parent::loadAll();
		// Sortieren
		$this->sortObjects();
	}
	
	/**
	* Sortiert die Seite eins nach oben.
	*
	* @param int $siteID - ID der Seite
	**/
	public function sortUpObject($siteID) {
		// Alle Seite durchlaufen
		$lastObject = NULL;
		foreach($this as $id => $currentSite) {
			// Seite erreicht
			if($id == $siteID) {
				// Bereits die höchste Seite
				if(is_null($lastObject)) return;
				
				// Aktuelle hoch
				$currentSite->sortUp();
				// Letze runter
				$lastObject->sortDown();
			}
			
			// Letztes Object speichern
			$lastObject = $currentSite;
		}
		
		// Neu sortieren
		$this->sortObjects();
	}
	
	/**
	* Sortiert die Seite eins nach unten.
	*
	* @param int $siteID - ID der Seite
	**/
	public function sortDownObject($siteID) {
		// Alle Seite durchlaufen
		$lastObject = NULL;
		$after = false;
		foreach($this as $id => $currentSite) {
			// Nächste Seite
			if($after) {				
				// Aktuelle hoch
				$currentSite->sortUp();
				// Letze runter
				$lastObject->sortDown();
				
				// Schleife abrechen
				break;
			}
		
			// Seite erreicht
			if($id == $siteID) $after = true;
			
			// Letztes Object speichern
			$lastObject = $currentSite;
		}
		
		// Neu sortieren
		$this->sortObjects();
	}
	
	/**
	* Setzt die Startseite des CMS.
	*
	* @param id $siteID - ID der Seite
	**/
	public function setHome($siteID) {
		// Alle Seite durchlaufen
		foreach($this as $id => $currentSite) {
			// Die neue Startseite?
			if($siteID == $id) $currentSite->setHome(true);
			// Keine Startseite
			else $currentSite->setHome(false);
		}
	}
	
	/**
	* Gibt die Startseite als Seitenobjekt zurück.
	*
	* @return \Content\Site
	**/
	public function getHome() {
		// Alle Seiten durchlaufen
		foreach($this as $currentSite) {
			// Startseite? Dann zurückgeben
			if($currentSite->isHome()) return $currentSite;
		}
		
		// Keine Startseite gefunden? Exception!
		throw new \Exception('Es ist keine Startseite definiert.', 2020);
	}
}