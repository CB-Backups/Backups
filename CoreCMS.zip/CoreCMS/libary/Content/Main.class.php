<?php
/**
* Haupt-Klasse startet das Programm
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-07
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content;

class Main extends \Core\Main {
	private $currentVersion;

	/**
	* Startet das Programm
	**/
	public function start() {
		// Modul öffnen
		\Core\i::Module()->open();
	}
	
	/**
	* Gibt zurück, welche Version aktuell ist.
	*
	* @return string
	**/
	public function getCurrentVersion() {
		if(!is_null($this->currentVersion)) return $this->currentVersion;
		
		try {
			// Öffnet einen neue Verbindung zur Config-Datei im GIT
			$handle = fopen(\Config\Version\CURRENT, 'r');
			// Im Versions-Namespace?
			$inNamespace = false;
			// Läuft jede Zeile durch
			while($row = fgets($handle)) {
				// Im richtigen Namespace?
				if(strpos($row, 'namespace Config\Version {') !== false) $inNamespace = true;
				// In der Versions-String-Zeile?
				if(strpos($row, 'const STRING = ') === false || !$inNamespace) continue;
			
				// Array für Ergebnisse
				$matches = [];
				// Versions-Nummer auslesen
				if(preg_match('/\'(.+)\'/', $row, $matches)) {
					// Versionsnummer cachen
					$this->currentVersion = $matches[1];
					// Versionsnummer zurückgeben
					return $matches[1];	
				} else throw new \Exception('Keine Versionsnummer in der angegeben Datei gefunden.', 2031);
			}
		} catch(\ErrorException $exception) {
			throw new \Exception('Die aktuelle Version konnte nicht ermittelt werden.', 2030);
		}
	}
		
	/**
	* Überprüft, ob eine neue Version zur Verfügung steht.
	*
	* @return bool
	**/
	public function existNewVersion() {
		// Vergleich durchführen
		return version_compare(\Config\Version\STRING, $this->getCurrentVersion(), '<');
	}
}
?>