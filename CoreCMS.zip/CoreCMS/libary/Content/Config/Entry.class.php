<?php
/**
* Eine einzelne Einstellung.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-29
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/
namespace Content\Config;

abstract class Entry extends \Object {
	protected $id, $name, $default, $current;
	
	/**
	* Registriert alle gewünschten Eigenschaften, Methoden oder Callbacks.
	**/
	public static function __register() {
		parent::__register();
		
		// Properties registrieren
		self::registerProperties(['id', 'name', 'default'], true);
	}
	
	/**
	* Stellt das Element zur Verfügung.
	*
	* @param string $id - ID des Elements
	* @param string $name - Klartextname des Elements
	* @param mixed $default - Standardwert [optional]
	**/
	public function __construct($id, $name, $default = NULL) {
		// Werte setzen
		$this->id = $id;
		$this->name = $name;
		$this->default = $default;
	}
	
	/**
	* Gibt den aktuellen Wert zurück.
	*
	* @return string
	**/
	public function __toString() {
		return (string) $this->getCurrent();
	}
	
	/**
	* Gibt den aktuellen Wert zurück.
	*
	* @return mixed
	**/
	public function getCurrent() {
		return !is_null($this->current) ? $this->current : $this->default;
	}
	
	/**
	* Setzt einen neuen Wert
	*
	* @param mixed $value [optional]
	**/
	public function setCurrent($value = NULL) {
		// Ist das valid?
		$value = $this->isValid($value);
	
		if($value == $this->default) $this->current = NULL;
		else $this->current = $value;
	}
	
	/**
	* Gibt zurück, ob die Einstellung auf dem Standard-Wert ist.
	*
	* @return bool
	**/
	public function isDefault() {
		return is_null($this->current);
	}
	
	/**
	* Zum überprüfen, ob die Einstellung gültig ist.
	*
	* @param string $value
	**/
	abstract protected function isValid($value);
}