<?php
/**
* Erweiterung für PHP-Funktionen.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-25
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/

/**
* Gibt den definierten Exception-Handler zurück.
*
* @return callback
**/
function get_exception_handler() {
	// Den aktuellen abfragen
	$currentExceptionHandler = set_exception_handler(function(){});
	// Den aktuellen wieder setzen
	restore_exception_handler();
	// Exception-Handler zurückgeben
	return $currentExceptionHandler;
}
?>