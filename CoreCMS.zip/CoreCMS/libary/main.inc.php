<?php
/**
* Bindet die benötigten Klasen automatisch ein, aktiviert die Fehlerbehebung und
* führt erste Grundkonfigurationen durch.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2012-06-27
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/

/**
* PHP-Fehler sollen Exceptions werfen.
**/
set_error_handler(function($number, $string, $file, $line) {
	// Eigene Error-Klasse schon vorhanden? (Oder möglich sie zu laden.)
	if(class_exists('AdvancedErrorException'))
		throw new \AdvancedErrorException($string, 0, $number, $file, $line);

	// Eine Exception werfen.
	throw new \ErrorException($string, 0, $number, $file, $line);
}, E_ALL);

/**
* Unabgefanene Exceptions sollen hier landen.
**/
set_exception_handler(function(\Exception $exception) {
	// Alte Ausgaben rauslšschen
	while(!\Config\DEBUG && ob_get_level()) ob_end_clean();

	// Plain- oder HTML-Fehler ausgeben?
	if(class_exists('\Core\Header', false) && \Core\Header::existMainInstance() && \Core\Header::mainInstance()->getContentType() == 'text/html') {
		// Wenn nicht installiert, dann gebe eine besondere Fehlermeldung aus
		if(!\Config\INSTALLED)
			require ROOT_PATH.'templates/ExceptionInstallHTML.tpl.php';
		else
			require ROOT_PATH.'templates/ExceptionHTML.tpl.php';
	} else
		require ROOT_PATH.'templates/ExceptionPlain.tpl.php';
});

/**
* Funktionssammlungen einbinden.
**/
foreach(['', 'Core'] as $current)
	require_once ROOT_PATH.'libary/'.$current.'/functions.php';

/**
* Low-Level-Klassen einbinden
**/
foreach(['\Core\Object\Cache', '\Core\Object', '\Object', '\Core\Classname', '\Core\Autoload'] as $current) {
	// Klasse einbinden
	require_once ROOT_PATH.'libary/'.str_replace('\\', '/', $current).'.class.php';
	
	// Registrierung durchführen
	if(is_subclass_of($current, '\Object')) $current::__register();
}

/**
* Aktiviert das Autoloading von PHP.
**/
spl_autoload_register(function($classname) {
	// Klasse aufrufen
	new \Core\Autoload($classname);
});

/**
* Callbacks für's Autoloading aktivieren
**/
// Callback für Objekt-Registrierungen
\Core\Autoload::registerAfterCallback(function(\Core\Classname $classname) {
	$classnameString = (string) $classname;

	// Instanz der Hauptklasse?
	if(is_subclass_of($classnameString, '\Object')) {
		// Register-Methode aufrufen
		$classnameString::__register();
	}	
});
// Callback für die Main-Instance-Klasse setzen
\Core\Autoload::registerBeforeCallback(['Core\MainInstance', 'callback']);
// Callback für die Daten-Klassen-Erstellen
\Core\Autoload::registerAfterCallback(['Core\Data', 'callback']);
?>