<?php
/**
* Erweiterung für die ErrorException-Klasse.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-01-09
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package McF Framework
*
**/

class AdvancedErrorException extends \ErrorException {
	/**
	* Gibt die Stufe des Fehlers als String zurück.
	*
	* @return string
	**/
	public function getSeverityAsString() {
		switch($this->getSeverity()) {
			case E_ERROR:
			case E_CORE_ERROR:
			case E_COMPILE_ERROR:
			case E_RECOVERABLE_ERROR:
			case E_USER_ERROR:
				return 'Fatal Error';
			case E_PARSE:
				return 'Parse Error';
			case E_USER_WARNING:
			case E_CORE_WARNING:
			case E_COMPILE_WARNING:
			case E_WARNING:
				return 'Warning';
			case E_USER_NOTICE:
			case E_NOTICE:
				return 'Notice';
			case E_STRICT:
				return 'Strict';
			case E_DEPRECATED:
			case E_USER_DEPRECATED:
				return 'Deprecated';
			default:
				return 'Unknown Error';
		}
	}
}
?>