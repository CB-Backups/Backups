	<div class="Clear"></div>
	<div id="footer">
		&copy; 2013 Marcel Heisinger &middot;
		Version <?= \Config\Version\STRING ?> &middot;
		generiert in <?= \Core\i::Main()->getGenTime() ?> (<?= \Core\i::Main()->getMemoryUsage() ?>)
	</div>
	</body>
</html>