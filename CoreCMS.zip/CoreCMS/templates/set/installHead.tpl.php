<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="css/system.css" type="text/css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		<title>
			Packetinstallation &middot; CoreCMS
		</title>
	</head>
	<body id="installBody">	
		<h1 id="headLogo">
			<a href="<?= >>>('Admin') ?>" title="Zur Startseite des Adminbereichs zurück…"><span class="Blue">Core</span>CMS</a>
		</h1>
		<div id="headline">
			Installation von „<?= Format::string(!!!packageName!!!) ?>“…
			
			<progress <? if(???packageStatus???): ?>value="<?=!!!packageStatus!!! ?>" max="100"<? endif; ?>></progress>
		</div>
		<div class="Clear"></div>
		<hr>
		
		<?= ^^^('messages') ?>