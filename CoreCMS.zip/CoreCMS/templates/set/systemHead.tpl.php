<!DOCTYPE html>
<html lang="de">
	<head>
		<meta charset="utf-8">
		<link href="http://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet" type="text/css">
		<!-- <link href="css/normalize.css" rel="stylesheet" type="text/css"> -->
		<link href="css/system.css" type="text/css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<? if(???headerTemplate???): ?><?= ^^^(!!!headerTemplate!!!) ?><? endif; ?>
		
		<title>
			<? if(???siteTitle???): ?><?= Format::string(!!!siteTitle!!!) ?> &middot;<? endif; ?> Administration &middot; CoreCMS
		</title>
	</head>
	<body>
		<noscript>
			<div class="Warning">Um CoreCMS voll verwenden zu können muss in deinem Browser Javascript aktiviert sein.</div>
		</noscript>
		<!--[if lt IE 10]> 
			<div class="Warning">
				CoreCMS funktioniert in Internet-Explorer-Versionen kleiner 10 nicht vollständig.
				Bitte update deinen IE oder wechsel zu einem WebKit-basierten Browser.
			</div>
		<![endif]-->
		
		<h1 id="headLogo">
			<a href="<?= >>>('Admin') ?>" title="Zur Startseite des Adminbereichs zurück…"><span class="Blue">Core</span>CMS</a>
		</h1>
		