<!DOCTYPE html>
<html lang="<?= !!!lang!!! ?>">
	<head>
		<meta charset="utf-8">
		<link href="<?= !!!cssStyle!!! ?>" type="text/css" rel="stylesheet">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		<title>
			<? if(???siteTitle???): ?><?= Format::string(!!!siteTitle!!!) ?><? else: ?>CoreCMS<? endif; ?>
		</title>
	</head>
	<body>
	