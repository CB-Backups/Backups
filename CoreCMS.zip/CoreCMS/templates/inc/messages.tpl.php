<? if(???showError??? && !!!showError!!!): ?>
	<div class="Error">
		<?= Format::string(!!!errorString!!!) ?>
	</div>
<? endif; ?>

<? if(???showWarning??? && !!!showWarning!!!): ?>
	<div class="Warning">
		<?= Format::string(!!!warningString!!!) ?>
	</div>
<? endif; ?>

<? if(???showSuccess??? && !!!showSuccess!!!): ?>
	<div class="Success">
		<?= Format::string(!!!successString!!!) ?>
	</div>
<? endif; ?>