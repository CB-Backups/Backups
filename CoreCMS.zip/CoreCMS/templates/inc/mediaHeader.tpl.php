<!-- Add jQuery library -->
<script type="text/javascript" src="scripts/jquery-1.9.0.min.js"></script>

<!-- Add fancyBox main JS and CSS files -->								  
<script type="text/javascript" src="scripts/fancybox/jquery.fancybox.pack.js?v=2.1.4"></script>
<link rel="stylesheet" type="text/css" href="scripts/fancybox/jquery.fancybox.css?v=2.1.4" media="screen" />
																		  
			
<!-- Filedrop Support -->
<script type="text/javascript" src="scripts/jquery.filedrop.js"></script>
				
<script type="text/javascript">
	$(document).ready(function() {
		$('a.Fancybox').fancybox({
			'openEffect': 'fade',
			'closeEffect': 'fade',
			'autosize': true
		});
					
		$('#dropzone').filedrop({
			url: '<?= >>>('Admin_Media_Upload', ['path'=>!!!reqPath!!!], NULL, false) ?>',
			paramname: 'files',
			maxFiles: 20,
			maxfilesize: <?= !!!maxFileSize!!! ?>,
			error: function(err, file) {
				switch(err) {
					case 'BrowserNotSupported':
						alert('Der Browser musst das HTML5-fähig sein.');
						break;
					case 'TooManyFiles':
						alert('Du kannst maximal 20 Dateien auf einmal hochladen.');
						break;
					case 'FileTooLarge':
						alert('Eine einzelne Datei darf nicht größer als <?= Format::size(!!!maxFileSizeRaw!!!) ?> sein.');
						break;
					case 'FileTypeNotAllowed':
						alert('Du hast einen verbotenen Datei-Type versucht hochzuladen.');
						break;
					default:
						alert('Unbekannter Fehler aufgetreten: '+err);
						break;
				}
							
				// Element-Design anpassen
				$('#dropzone').css('background', 'lightgray');
				$('#dropzone').css('border', 'grey 1px solid');
			},
    		allowedfiletypes: [],
			dragOver: function () {
				$('#dropzone').css('background', 'rgba(49, 109, 250, 0.1)');
				$('#dropzone').css('border', '1px solid #316dfa');
			},
			dragLeave: function () {
				$('#dropzone').css('background', 'lightgray');
				$('#dropzone').css('border', 'grey 1px solid');
			},
			drop: function () {
				$('#dropzone').css('background', 'lightgray');
				$('#dropzone').css('border', 'grey 1px solid');
			},
			uploadStarted: function(i, file, response, time) { 
				$('#dropzone span').css('display', 'none');
				$('#dropzone progress').css('display', 'inline');
        	},
        	globalProgressUpdate: function(progress) {
	        	$('#dropzone progress').setAttribute('value', progress);
        	},
        	uploadFinished: function(i, file, response, time) {
        		// Fehler aufgetreten?
        		if(response != 'done') alert('Fehler beim Hochladen der Datei „'+file.name+'“:\n'+response);
       		}, 
			afterAll: function () {
				window.location.reload();
			},
		});
	});
	
	/**
	* Funktion zum Ändern eines Element-Namen
	*
	* @param int id - Die ID des Elements
	**/
	function showChangeInput(id) {
		// Änderungshinweis anzeigen
		$('#changeNameWarning').css('display', 'block');	
		// Checkbox zum Ändern markieren
		$('#elementKeyID'+id).attr('checked', 'checked');
	
		// Textspan ausblenden
		$('#elementKeyID'+id+'Span').css('display', 'none');
	
		// Inputfeldspan einblenden
		$('#elementKeyID'+id+'InputSpan').css('display', 'inline');
		// Inputfeld fokusieren
		$('#elementKeyID'+id+'Input').focus();
	}
	
	/**
	* Funktion um zum vereinfachten Kopieren von Texten.
	*
	* @param string text - Zu kopierender Text
	**/
	function copyToClipboard(text) {
		window.prompt("Zum Kopieren des Element-Links einfach [STRG]+[C] oder [CMD]+[C] drücken und anschließend [Enter] um das Fenster zu schließen.", text);
	}
</script>