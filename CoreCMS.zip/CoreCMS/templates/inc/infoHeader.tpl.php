<!-- Add jQuery library -->
<script type="text/javascript" src="scripts/jquery-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
		$.ajax({
			url: '<?= >>>('Admin_Settings_Info_AJAX') ?>',
			success: function(data) {
				// Lademeldung ausblenden
				$('#loadingSplash').css('display', 'none');	
		
				if(data == 'current') // Keine neuere Version?
					$('#noNewerVersion').css('display', 'block');
				else if(data == 'loadingError') // Fehler aufgetreten?
					$('#loadingError').css('display', 'block');
				else { // Neue Version bekannt?
					// Meldung darstellen
					$('#newerVersionExists').css('display', 'block');
					// Version eintragen
					$('#newerVersionNumber').html(data);
				}	
			}
		});
	});
</script>