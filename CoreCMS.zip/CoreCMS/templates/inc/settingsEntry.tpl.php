<? if($vars['entry'] instanceof \Content\Config\Text): ?>
	<input name="setting[<?= $vars['entry']->getID() ?>]"
		type="text" value="<?= $vars['entry']->getCurrent() ?>"
		placeholder="<?= $vars['entry']->getDefault() ?>" size="50">
<? elseif($vars['entry'] instanceof \Content\Config\Bool): ?>
	<input name="setting[<?= $vars['entry']->getID() ?>]" id="setting_<?= $vars['entry']->getID() ?>_true"
		type="radio" value="1" 
		<? if($vars['entry']->getCurrent()): ?>checked="checked"<? endif; ?>>
	<label for="setting_<?= $vars['entry']->getID() ?>_true">Ja</label>
		
	<input name="setting[<?= $vars['entry']->getID() ?>]" id="setting_<?= $vars['entry']->getID() ?>_false"
		type="radio" value="0"
		<? if(!$vars['entry']->getCurrent()): ?>checked="checked"<? endif; ?>>
	<label for="setting_<?= $vars['entry']->getID() ?>_false">Nein</label>
<? endif; ?>