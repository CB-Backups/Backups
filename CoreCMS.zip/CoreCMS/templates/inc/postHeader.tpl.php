<!-- Add jQuery library -->
<script type="text/javascript" src="scripts/jquery-1.9.0.min.js"></script>

<!-- Add ckeditor -->
<script type="text/javascript" src="scripts/ckeditor/ckeditor.js"></script>

<!-- Höhe des Editors anpassen -->
<script type="text/javascript">
	$(document).ready(function() {
		CKEDITOR.replace('postEditor', {
			language: 'de',
			height: 420
			});
	});
</script>