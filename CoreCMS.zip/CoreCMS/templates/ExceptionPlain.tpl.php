<? do { ?>
+++ Exception +++
Message: <?= method_exists($exception, 'getSeverityAsString') ? $exception->getSeverityAsString().': ' : '' ?><?= $exception->getMessage() ?> 
Code: <?= $exception->getCode() ?> 
File: <?= $exception->getFile() ?> (<?= $exception->getLine() ?>)

Stacktrace:
<?= $exception->getTraceAsString() ?>



<? } while($exception = $exception->getPrevious()); ?>