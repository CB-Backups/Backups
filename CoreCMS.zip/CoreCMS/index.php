<?php
/**
* Hauptdatei, die weitere, benötigte Bibliotheken lädt.
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-06
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

// Grund-Konstanten definieren
define("ROOT_PATH", __DIR__.'/');

// Konfigurations-Datei einbinden (Eine Dummy-Config-Datei verwenden, falls keine vorhanden ist.)
if(file_exists(ROOT_PATH.'config.inc.php')) require_once ROOT_PATH.'config.inc.php';
else require_once ROOT_PATH.'config.sample.inc.php';

// Die Bibliothek einbinden. (Oder besser gesagt, ihre Autoload-Funktion.)
require_once ROOT_PATH.'libary/main.inc.php';

// Das Spiel starten.
\Content\i::Main()->start();

// Am Ende der Ausführung angekommen
exit;
?>