<?php
/**
* Konfiguration des Projektes
*
* @copyright Copyright 2013 Marcel Heisinger
* @link https://github.com/marhei/CoreCMS
* @date 2013-03-08
* @license Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.txt)
* @author Marcel Heisinger
* @package CoreCMS
*
**/

namespace Config {
	const INSTALLED = false;
	const INSTALL_TIME = 0;
	const DEBUG = false;
	const DEBUG_USER = -1;
	const TIME_ZONE = 'Europe/Berlin';
}

namespace Config\Version {
	const STRING = '0.8.1beta';
	const LICENSE_FILE = '/docs/license.txt';
	const SITE = 'http://github.com/marhei/CoreCMS/';
	const CURRENT = 'https://raw.github.com/marhei/CoreCMS/master/config.sample.inc.php';
}

namespace Config\MySQL {
	const SERVER = 'localhost';
	const USER = NULL;
	const PASS = NULL;
	const DATABASE = NULL;
}

?>